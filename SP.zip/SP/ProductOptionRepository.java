package com.fpoly.repository;

import com.fpoly.model.ProductOption;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductOptionRepository extends JpaRepository<ProductOption, Integer> {
    List<ProductOption> findByProductIdOrderBySortOrderAsc(Integer productId);
}