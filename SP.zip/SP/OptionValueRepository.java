package com.fpoly.repository;

import com.fpoly.model.OptionValue;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OptionValueRepository extends JpaRepository<OptionValue, Integer> {
}