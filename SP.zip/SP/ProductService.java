package com.fpoly.service;

import java.math.BigDecimal;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fpoly.model.*;
import com.fpoly.repository.*;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepo;

    @Autowired
    private ProductVariantRepository variantRepo;

    @Autowired
    private ProductImageRepository imageRepo;

    @Autowired
    private ProductSpecRepository specRepo;

    @Autowired
    private ProductPromotionRepository promotionRepo;

    @Autowired
    private ProductOptionRepository optionRepo;

    @Autowired
    private OptionValueRepository optionValueRepo;

    public List<Product> findAll() {
        return productRepo.findAll();
    }

    public List<Product> findByCategory(Category category) {
        return productRepo.findByCategory(category);
    }

    public Product findById(Integer id) {
        return productRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy sản phẩm"));
    }

    public void saveProductWithPrice(
            Product product,
            BigDecimal price,
            BigDecimal originalPrice,
            Integer stock
    ) {
        try {
            saveProductWithPrice(product, price, originalPrice, stock, null, null, Map.of());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public Product saveProductWithPrice(
            Product product,
            BigDecimal price,
            BigDecimal originalPrice,
            Integer stock,
            MultipartFile mainImageFile,
            MultipartFile[] imageFiles,
            Map<String, String> params
    ) throws Exception {

        if (product.getIsActive() == null) {
            product.setIsActive(true);
        }

        if (product.getCreatedAt() == null) {
            product.setCreatedAt(LocalDateTime.now());
        }

        if (product.getCategory() == null || product.getCategory().getId() == null) {
            throw new RuntimeException("Bạn chưa chọn danh mục sản phẩm");
        }

        Product savedProduct = productRepo.save(product);

        ProductVariant variant = new ProductVariant();
        variant.setProduct(savedProduct);
        variant.setSku("SKU-" + savedProduct.getId());
        variant.setPrice(price);
        variant.setOriginalPrice(originalPrice);
        variant.setStock(stock);
        variant.setIsDefault(true);
        variantRepo.save(variant);

        saveImages(savedProduct, mainImageFile, imageFiles);
        saveSpecs(savedProduct, params);
        savePromotions(savedProduct, params);
        saveOptions(savedProduct, params);

        return savedProduct;
    }

    private void saveImages(Product product,
                            MultipartFile mainImageFile,
                            MultipartFile[] imageFiles) throws Exception {

        if (mainImageFile != null && !mainImageFile.isEmpty()) {
            ProductImage img = new ProductImage();
            img.setProduct(product);
            img.setUrl(saveFile(mainImageFile));
            img.setPrimary(true);
            img.setSortOrder(0);
            imageRepo.save(img);
        }

        if (imageFiles != null) {
            int index = 1;

            for (MultipartFile file : imageFiles) {
                if (file != null && !file.isEmpty()) {
                    ProductImage img = new ProductImage();
                    img.setProduct(product);
                    img.setUrl(saveFile(file));
                    img.setPrimary(false);
                    img.setSortOrder(index++);
                    imageRepo.save(img);
                }
            }
        }
    }

    private void saveSpecs(Product product, Map<String, String> params) {
        int i = 0;

        while (params.containsKey("specName_" + i)) {
            String name = params.get("specName_" + i);
            String value = params.get("specValue_" + i);

            if (name != null && value != null && !name.isBlank() && !value.isBlank()) {
                ProductSpec spec = new ProductSpec();
                spec.setProduct(product);
                spec.setSpecKey(name);
                spec.setSpecValue(value);
                spec.setSortOrder(i);
                specRepo.save(spec);
            }

            i++;
        }
    }

    private void savePromotions(Product product, Map<String, String> params) {
        int i = 0;

        while (params.containsKey("promotion_" + i)) {
            String content = params.get("promotion_" + i);

            if (content != null && !content.isBlank()) {
                ProductPromotion promo = new ProductPromotion();
                promo.setProduct(product);
                promo.setContent(content);
                promo.setSortOrder(i);
                promotionRepo.save(promo);
            }

            i++;
        }
    }

    private void saveOptions(Product product, Map<String, String> params) {
        int groupIndex = 0;

        while (params.containsKey("optionName_" + groupIndex)) {
            String optionName = params.get("optionName_" + groupIndex);

            if (optionName != null && !optionName.isBlank()) {
                ProductOption option = new ProductOption();
                option.setProduct(product);
                option.setOptionName(optionName);
                option.setSelectionType(params.getOrDefault("selectionType_" + groupIndex, "single"));
                option.setMinSelect(parseInt(params.get("minSelect_" + groupIndex), 0));
                option.setMaxSelect(parseInt(params.get("maxSelect_" + groupIndex), 1));
                option.setDescription(params.get("optionDescription_" + groupIndex));
                option.setRequired(params.containsKey("required_" + groupIndex));
                option.setVisible(params.containsKey("visible_" + groupIndex));
                option.setSortOrder(groupIndex);

                ProductOption savedOption = optionRepo.save(option);

                int valueIndex = 0;

                while (params.containsKey("valueName_" + groupIndex + "_" + valueIndex)) {
                    String valueName = params.get("valueName_" + groupIndex + "_" + valueIndex);

                    if (valueName != null && !valueName.isBlank()) {
                        OptionValue value = new OptionValue();
                        value.setOption(savedOption);
                        value.setValue(valueName);
                        value.setPriceExtra(parseDecimal(params.get("priceExtra_" + groupIndex + "_" + valueIndex)));
                        value.setIsDefault(params.containsKey("default_" + groupIndex + "_" + valueIndex));
                        value.setActive(params.containsKey("active_" + groupIndex + "_" + valueIndex));
                        value.setSortOrder(valueIndex);

                        optionValueRepo.save(value);
                    }

                    valueIndex++;
                }
            }

            groupIndex++;
        }
    }

    private Integer parseInt(String value, Integer defaultValue) {
        try {
            return value == null || value.isBlank() ? defaultValue : Integer.parseInt(value);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    private BigDecimal parseDecimal(String value) {
        try {
            return value == null || value.isBlank() ? BigDecimal.ZERO : new BigDecimal(value);
        } catch (Exception e) {
            return BigDecimal.ZERO;
        }
    }

    private String saveFile(MultipartFile file) throws Exception {
        String uploadDir = "uploads/products/";

        Files.createDirectories(Paths.get(uploadDir));

        String originalName = file.getOriginalFilename();

        if (originalName == null || originalName.isBlank()) {
            originalName = "image.jpg";
        }

        String safeName = originalName.replaceAll("\\s+", "_");
        String fileName = UUID.randomUUID() + "_" + safeName;

        Path path = Paths.get(uploadDir).resolve(fileName);

        Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);

        return "/uploads/products/" + fileName;
    }

    public void delete(Integer id) {
        productRepo.deleteById(id);
    }

}