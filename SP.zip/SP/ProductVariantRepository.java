package com.fpoly.repository;

import com.fpoly.model.ProductVariant;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ProductVariantRepository extends JpaRepository<ProductVariant, Integer> {
    Optional<ProductVariant> findFirstByProductIdAndIsDefaultTrue(Integer productId);
}