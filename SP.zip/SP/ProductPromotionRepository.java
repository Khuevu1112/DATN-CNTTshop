package com.fpoly.repository;

import com.fpoly.model.ProductPromotion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductPromotionRepository extends JpaRepository<ProductPromotion, Integer> {
    List<ProductPromotion> findByProductIdOrderBySortOrderAsc(Integer productId);
}