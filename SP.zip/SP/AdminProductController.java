package com.fpoly.controller.admin;

import java.math.BigDecimal;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fpoly.model.Product;
import com.fpoly.service.CategoryService;
import com.fpoly.service.ProductService;

@Controller
@RequestMapping("/admin/products")
public class AdminProductController {

    @Autowired
    private ProductService productService;

    @Autowired
    private CategoryService categoryService;

    @GetMapping
    public String list(Model model) {
        model.addAttribute("products", productService.findAll());
        return "admin/product-list";
    }

    @GetMapping("/add")
    public String addForm(Model model) {
        model.addAttribute("product", new Product());
        model.addAttribute("categories", categoryService.findAll());
        return "admin/product-form";
    }

    @PostMapping("/save")
    public String save(
            @ModelAttribute Product product,

            @RequestParam("price") BigDecimal price,
            @RequestParam(value = "originalPrice", required = false) BigDecimal originalPrice,
            @RequestParam("stock") Integer stock,

            @RequestParam(value = "mainImageFile", required = false) MultipartFile mainImageFile,
            @RequestParam(value = "imageFiles", required = false) MultipartFile[] imageFiles,

            @RequestParam Map<String, String> params,

            RedirectAttributes redirectAttributes
    ) {
        try {
            Product savedProduct = productService.saveProductWithPrice(
                    product,
                    price,
                    originalPrice,
                    stock,
                    mainImageFile,
                    imageFiles,
                    params
            );

            redirectAttributes.addFlashAttribute("success", "Lưu sản phẩm thành công");

            return "redirect:/san-pham/" + savedProduct.getId();

        } catch (Exception e) {
            e.printStackTrace();

            redirectAttributes.addFlashAttribute("error", "Lỗi khi lưu sản phẩm: " + e.getMessage());

            if (product.getId() != null) {
                return "redirect:/admin/products/edit/" + product.getId();
            }

            return "redirect:/admin/products/add";
        }
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable Integer id, Model model) {
        model.addAttribute("product", productService.findById(id));
        model.addAttribute("categories", categoryService.findAll());
        return "admin/product-form";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        productService.delete(id);
        redirectAttributes.addFlashAttribute("success", "Xóa sản phẩm thành công");
        return "redirect:/admin/products";
    }
}