package com.fpoly.model;

import jakarta.persistence.*;

@Entity
@Table(name = "PRODUCT_IMAGE")
public class ProductImage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String url;

    @Column(name = "is_primary")
    private Boolean primary = false;

    @Column(name = "sort_order")
    private Integer sortOrder = 0;

    @ManyToOne
    @JoinColumn(name = "product_id")
    private Product product;

    // ===== Getter =====

    public Integer getId() {
        return id;
    }

    public String getUrl() {
        return url;
    }

    public Boolean getPrimary() {
        return primary;
    }

    public Integer getSortOrder() {
        return sortOrder;
    }

    public Product getProduct() {
        return product;
    }

    // ===== Setter =====

    public void setId(Integer id) {
        this.id = id;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public void setPrimary(Boolean primary) {
        this.primary = primary;
    }

    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    public void setProduct(Product product) {
        this.product = product;
    }
}