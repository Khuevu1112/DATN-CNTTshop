package com.fpoly.repository;

public class ProductBundleRepository {

	public ProductBundleRepository() {
		// TODO Auto-generated constructor stub
	}

}
