package com.fpoly.repository;

import com.fpoly.model.ProductSpec;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductSpecRepository extends JpaRepository<ProductSpec, Integer> {
    List<ProductSpec> findByProductIdOrderBySortOrderAsc(Integer productId);
}