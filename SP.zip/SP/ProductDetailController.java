package com.fpoly.controller.cilent;


import com.fpoly.model.Product;
import com.fpoly.model.ProductVariant;
import com.fpoly.repository.ProductImageRepository;
import com.fpoly.repository.ProductOptionRepository;
import com.fpoly.repository.ProductPromotionRepository;
import com.fpoly.repository.ProductRepository;
import com.fpoly.repository.ProductSpecRepository;
import com.fpoly.repository.ProductVariantRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
public class ProductDetailController {

    private final ProductRepository productRepository;
    private final ProductVariantRepository variantRepository;
    private final ProductImageRepository imageRepository;
    private final ProductSpecRepository specRepository;
    private final ProductPromotionRepository promotionRepository;
    private final ProductOptionRepository optionRepository;

    @GetMapping("/san-pham/{id}")
    public String detail(@PathVariable Integer id, Model model) {
        Product product = productRepository.findById(id).orElseThrow();

        ProductVariant defaultVariant = variantRepository
                .findFirstByProductIdAndIsDefaultTrue(id)
                .orElse(null);

        model.addAttribute("product", product);
        model.addAttribute("variant", defaultVariant);
        model.addAttribute("images", imageRepository.findByProductIdOrderBySortOrderAsc(id));
        model.addAttribute("specs", specRepository.findByProductIdOrderBySortOrderAsc(id));
        model.addAttribute("promotions", promotionRepository.findByProductIdOrderBySortOrderAsc(id));
        model.addAttribute("options", optionRepository.findByProductIdOrderBySortOrderAsc(id));

        return "product/detail";
    }
}