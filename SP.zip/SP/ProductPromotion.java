package com.fpoly.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "PRODUCT_PROMOTION")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ProductPromotion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String content;

    @Column(name = "sort_order")
    private Integer sortOrder = 0;

    @ManyToOne
    @JoinColumn(name = "product_id")
    private Product product;
}