package com.fpoly.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fpoly.model.InstallmentOrder;

@Repository
public interface InstallmentOrderRepository
        extends JpaRepository<InstallmentOrder, Integer> {

    // Đếm hồ sơ theo trạng thái
    long countByStatus(String status);

    // Lấy tất cả hồ sơ, mới nhất lên đầu
    List<InstallmentOrder> findAllByOrderByCreatedAtDesc();

    // Lấy hồ sơ theo trạng thái
    List<InstallmentOrder> findByStatusOrderByCreatedAtDesc(String status);

    // Lấy 10 hồ sơ mới nhất
    List<InstallmentOrder> findTop10ByOrderByCreatedAtDesc();

    // Hồ sơ trả góp của một khách hàng, mới nhất lên đầu
    List<InstallmentOrder> findByUserIdOrderByCreatedAtDesc(Integer userId);
}