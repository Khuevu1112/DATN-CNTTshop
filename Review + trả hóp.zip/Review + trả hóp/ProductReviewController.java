package com.fpoly.controller.cilent;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fpoly.model.NguoiDung;
import com.fpoly.security.CustomUserDetails;
import com.fpoly.service.ProductReviewService;

@Controller
public class ProductReviewController {

    private final ProductReviewService reviewService;

    public ProductReviewController(ProductReviewService reviewService) {
        this.reviewService = reviewService;
    }

    @PostMapping("/san-pham/{productId}/danh-gia")
    public String saveReview(@PathVariable Integer productId,
                             @RequestParam Integer rating,
                             @RequestParam String content,
                             Authentication authentication,
                             RedirectAttributes redirectAttributes) {
        try {
            NguoiDung user = currentUser(authentication);
            reviewService.save(productId, user, rating, content);
            redirectAttributes.addFlashAttribute("reviewSuccess", "Đánh giá của bạn đã được lưu.");
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("reviewError", e.getMessage());
        }
        return "redirect:/san-pham/" + productId + "#product-reviews";
    }

    @PostMapping("/san-pham/{productId}/danh-gia/{reviewId}/xoa")
    public String deleteReview(@PathVariable Integer productId,
                               @PathVariable Integer reviewId,
                               Authentication authentication,
                               RedirectAttributes redirectAttributes) {
        try {
            NguoiDung user = currentUser(authentication);
            boolean adminOrStaff = authentication.getAuthorities().stream()
                    .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN") || a.getAuthority().equals("ROLE_STAFF"));
            reviewService.delete(reviewId, user, adminOrStaff);
            redirectAttributes.addFlashAttribute("reviewSuccess", "Đã xóa đánh giá.");
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("reviewError", e.getMessage());
        }
        return "redirect:/san-pham/" + productId + "#product-reviews";
    }

    private NguoiDung currentUser(Authentication authentication) {
        if (authentication == null || !(authentication.getPrincipal() instanceof CustomUserDetails details)) {
            throw new IllegalArgumentException("Bạn cần đăng nhập để đánh giá sản phẩm.");
        }
        return details.getNguoiDung();
    }
}
