package com.fpoly.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fpoly.model.InstallmentPlan;

@Repository
public interface InstallmentPlanRepository
        extends JpaRepository<InstallmentPlan,Integer>{

    List<InstallmentPlan> findByActiveTrueOrderByMonthsAsc();
}
