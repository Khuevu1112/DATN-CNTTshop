package com.fpoly.service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fpoly.model.NguoiDung;
import com.fpoly.model.Product;
import com.fpoly.model.ProductReview;
import com.fpoly.repository.ProductRepository;
import com.fpoly.repository.ProductReviewRepository;

@Service
@Transactional
public class ProductReviewService {

    private final ProductReviewRepository reviewRepository;
    private final ProductRepository productRepository;

    public ProductReviewService(ProductReviewRepository reviewRepository,
                                ProductRepository productRepository) {
        this.reviewRepository = reviewRepository;
        this.productRepository = productRepository;
    }

    @Transactional(readOnly = true)
    public List<ProductReview> getVisibleReviews(Integer productId) {
        return reviewRepository.findByProductIdAndVisibleTrueOrderByCreatedAtDesc(productId);
    }

    @Transactional(readOnly = true)
    public Optional<ProductReview> findUserReview(Integer productId, Integer userId) {
        return reviewRepository.findByProductIdAndUserId(productId, userId);
    }

    @Transactional(readOnly = true)
    public double getAverageRating(Integer productId) {
        Double value = reviewRepository.averageRating(productId);
        return value == null ? 0.0 : value;
    }

    @Transactional(readOnly = true)
    public long getReviewCount(Integer productId) {
        return reviewRepository.countByProductIdAndVisibleTrue(productId);
    }

    @Transactional(readOnly = true)
    public Map<Integer, Long> getRatingCounts(Integer productId) {
        Map<Integer, Long> result = new LinkedHashMap<>();
        for (int rating = 5; rating >= 1; rating--) result.put(rating, 0L);
        for (Object[] row : reviewRepository.countByRating(productId)) {
            if (row == null || row.length < 2 || row[0] == null || row[1] == null) {
                continue;
            }
            int rating = ((Number) row[0]).intValue();
            long count = ((Number) row[1]).longValue();
            if (rating >= 1 && rating <= 5) {
                result.put(rating, count);
            }
        }
        return result;
    }

    public ProductReview save(Integer productId, NguoiDung user, Integer rating, String content) {
        validate(rating, content);

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy sản phẩm."));

        ProductReview review = reviewRepository
                .findByProductIdAndUserId(productId, user.getId())
                .orElseGet(ProductReview::new);

        if (review.getId() == null) {
            review.setProduct(product);
            review.setUser(user);
        }

        review.setRating(rating);
        review.setContent(content.trim());
        review.setVisible(true);
        return reviewRepository.save(review);
    }

    public void delete(Integer reviewId, NguoiDung currentUser, boolean adminOrStaff) {
        ProductReview review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy đánh giá."));

        if (!adminOrStaff && !review.getUser().getId().equals(currentUser.getId())) {
            throw new IllegalArgumentException("Bạn không có quyền xóa đánh giá này.");
        }
        reviewRepository.delete(review);
    }

    private void validate(Integer rating, String content) {
        if (rating == null || rating < 1 || rating > 5) {
            throw new IllegalArgumentException("Số sao phải từ 1 đến 5.");
        }
        if (content == null || content.trim().length() < 10) {
            throw new IllegalArgumentException("Nội dung đánh giá phải có ít nhất 10 ký tự.");
        }
        if (content.trim().length() > 1000) {
            throw new IllegalArgumentException("Nội dung đánh giá không được vượt quá 1000 ký tự.");
        }
    }
}
