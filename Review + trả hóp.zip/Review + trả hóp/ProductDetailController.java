package com.fpoly.controller.cilent;


import com.fpoly.model.Product;
import com.fpoly.model.ProductVariant;
import com.fpoly.repository.InstallmentPlanRepository;
import com.fpoly.repository.ProductImageRepository;
import com.fpoly.repository.ProductOptionRepository;
import com.fpoly.repository.ProductPromotionRepository;
import com.fpoly.repository.ProductRepository;
import com.fpoly.repository.ProductSpecRepository;
import com.fpoly.repository.ProductVariantRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;

import com.fpoly.model.ProductReview;
import com.fpoly.security.CustomUserDetails;
import com.fpoly.service.ProductReviewService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequiredArgsConstructor
public class ProductDetailController {

    private final ProductRepository productRepository;
    private final ProductVariantRepository variantRepository;
    private final ProductImageRepository imageRepository;
    private final ProductSpecRepository specRepository;
    private final ProductPromotionRepository promotionRepository;
    private final ProductOptionRepository optionRepository;
    private final InstallmentPlanRepository installmentPlanRepository;
    private final ProductReviewService reviewService;

    @GetMapping("/san-pham/{id}")
    public String detail(@PathVariable Integer id, Model model, Authentication authentication) {
        Product product = productRepository.findById(id).orElseThrow();

        ProductVariant defaultVariant = variantRepository
                .findFirstByProductIdAndIsDefaultTrue(id)
                .orElse(null);

        model.addAttribute("product", product);
        model.addAttribute("variant", defaultVariant);
        model.addAttribute("images", imageRepository.findByProductIdOrderBySortOrderAsc(id));
        model.addAttribute("specs", specRepository.findByProductIdOrderBySortOrderAsc(id));
        model.addAttribute("promotions", promotionRepository.findByProductIdOrderBySortOrderAsc(id));
        model.addAttribute("options", optionRepository.findByProductIdOrderBySortOrderAsc(id));
        model.addAttribute("installmentPlans", installmentPlanRepository.findByActiveTrueOrderByMonthsAsc());

        List<ProductReview> reviews = reviewService.getVisibleReviews(id);
        double reviewAverage = reviewService.getAverageRating(id);
        long reviewCount = reviewService.getReviewCount(id);
        Map<Integer, Long> ratingCounts = reviewService.getRatingCounts(id);
        if (ratingCounts == null) {
            ratingCounts = new LinkedHashMap<>();
        }

        // Chuẩn hóa dữ liệu biểu đồ sao để Thymeleaf không tính toán với giá trị null.
        List<Map<String, Object>> ratingRows = new ArrayList<>();
        for (int star = 5; star >= 1; star--) {
            Long rawCount = ratingCounts.get(star);
            long count = rawCount == null ? 0L : rawCount;
            long percentage = reviewCount > 0 ? Math.round(count * 100.0 / reviewCount) : 0L;
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("star", star);
            row.put("count", count);
            row.put("percentage", percentage);
            ratingRows.add(row);
        }

        model.addAttribute("reviews", reviews);
        model.addAttribute("reviewAverage", reviewAverage);
        model.addAttribute("reviewCount", reviewCount);
        model.addAttribute("ratingCounts", ratingCounts);
        model.addAttribute("ratingRows", ratingRows);

        ProductReview currentUserReview = null;
        Integer currentUserId = null;
        if (authentication != null && authentication.getPrincipal() instanceof CustomUserDetails details) {
            currentUserId = details.getNguoiDung().getId();
            currentUserReview = reviewService.findUserReview(id, currentUserId).orElse(null);
        }
        model.addAttribute("currentUserReview", currentUserReview);
        model.addAttribute("currentUserId", currentUserId);

        return "product/detail";
    }
    
}