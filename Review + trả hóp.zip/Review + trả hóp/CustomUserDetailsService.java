package com.fpoly.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.fpoly.model.NguoiDung;
import com.fpoly.repository.NguoiDungRepository;
import com.fpoly.security.CustomUserDetails;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private NguoiDungRepository nguoiDungRepository;

    @Override
    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException {

        NguoiDung user = nguoiDungRepository.findByEmail(username)
                .or(() -> nguoiDungRepository.findBySoDienThoai(username))
                .orElseThrow(() ->
                        new UsernameNotFoundException(
                                "Không tìm thấy tài khoản: " + username
                        )
                );

        if (Boolean.FALSE.equals(user.getIsActive())) {
            throw new DisabledException(
                    "Tài khoản đã bị ngừng hoạt động. Vui lòng liên hệ admin."
            );
        }

        return new CustomUserDetails(user);
    }
}