package com.fpoly.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.repository.query.Param;

import com.fpoly.model.ProductReview;

public interface ProductReviewRepository extends JpaRepository<ProductReview, Integer> {

    @EntityGraph(attributePaths = {"user"})
    List<ProductReview> findByProductIdAndVisibleTrueOrderByCreatedAtDesc(Integer productId);

    Optional<ProductReview> findByProductIdAndUserId(Integer productId, Integer userId);

    @EntityGraph(attributePaths = {"user", "product"})
    List<ProductReview> findAllByOrderByCreatedAtDesc();

    long countByVisibleTrue();

    long countByVisibleFalse();

    long countByProductIdAndVisibleTrue(Integer productId);

    @Query("select coalesce(avg(r.rating), 0) from ProductReview r where r.product.id = :productId and r.visible = true")
    Double averageRating(@Param("productId") Integer productId);

    @Query("select r.rating, count(r) from ProductReview r where r.product.id = :productId and r.visible = true group by r.rating")
    List<Object[]> countByRating(@Param("productId") Integer productId);
}
