package com.fpoly.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fpoly.dto.InstallmentOrderRequest;
import com.fpoly.model.InstallmentOrder;
import com.fpoly.model.InstallmentPlan;
import com.fpoly.model.NguoiDung;
import com.fpoly.model.OptionValue;
import com.fpoly.model.Product;
import com.fpoly.model.ProductVariant;
import com.fpoly.repository.InstallmentOrderRepository;
import com.fpoly.repository.InstallmentPlanRepository;
import com.fpoly.repository.NguoiDungRepository;
import com.fpoly.repository.OptionValueRepository;
import com.fpoly.repository.ProductRepository;
import com.fpoly.repository.ProductVariantRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class InstallmentService {
    private final InstallmentPlanRepository planRepository;
    private final InstallmentOrderRepository orderRepository;
    private final ProductRepository productRepository;
    private final ProductVariantRepository variantRepository;
    private final OptionValueRepository optionValueRepository;
    private final NguoiDungRepository userRepository;

    @Transactional
    public InstallmentOrder createOrder(InstallmentOrderRequest request, String loginEmail) {
        validateRequest(request);

        Product product = productRepository.findById(request.getProductId())
                .orElseThrow(() -> new IllegalArgumentException("Sản phẩm không tồn tại"));

        ProductVariant variant = resolveVariant(request, product);
        InstallmentPlan plan = planRepository.findByActiveTrueOrderByMonthsAsc().stream()
                .filter(item -> item.getMonths().equals(request.getMonths()))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Kỳ hạn trả góp không hợp lệ"));

        List<OptionValue> values = request.getOptionValueIds() == null
                ? List.of()
                : optionValueRepository.findAllById(request.getOptionValueIds());

        if (values.size() != (request.getOptionValueIds() == null ? 0 : request.getOptionValueIds().size())) {
            throw new IllegalArgumentException("Tùy chọn sản phẩm không hợp lệ");
        }
        boolean invalidOption = values.stream().anyMatch(value ->
                value.getOption() == null || value.getOption().getProduct() == null
                || !value.getOption().getProduct().getId().equals(product.getId())
                || !Boolean.TRUE.equals(value.getActive()));
        if (invalidOption) throw new IllegalArgumentException("Tùy chọn không thuộc sản phẩm đang mua");

        int quantity = request.getQuantity();
        BigDecimal unitPrice = variant.getPrice();
        for (OptionValue value : values) {
            if (value.getPriceExtra() != null) unitPrice = unitPrice.add(value.getPriceExtra());
        }
        BigDecimal price = unitPrice.multiply(BigDecimal.valueOf(quantity)).setScale(2, RoundingMode.HALF_UP);
        BigDecimal downPayment = request.getDownPayment() == null ? BigDecimal.ZERO : request.getDownPayment();
        downPayment = downPayment.setScale(2, RoundingMode.HALF_UP);
        if (downPayment.signum() < 0 || downPayment.compareTo(price) >= 0) {
            throw new IllegalArgumentException("Trả trước phải từ 0 đến nhỏ hơn giá sản phẩm");
        }

        BigDecimal loanAmount = price.subtract(downPayment);
        BigDecimal totalInterest = loanAmount
                .multiply(plan.getInterestRate())
                .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
        BigDecimal financedTotal = loanAmount.add(totalInterest);
        BigDecimal monthlyPayment = financedTotal
                .divide(BigDecimal.valueOf(plan.getMonths()), 2, RoundingMode.HALF_UP);
        BigDecimal totalPayment = downPayment.add(financedTotal);

        InstallmentOrder order = new InstallmentOrder();
        if (loginEmail != null) {
            NguoiDung user = userRepository.findByEmail(loginEmail).orElse(null);
            if (user != null) order.setUserId(user.getId());
        }
        order.setProductId(product.getId());
        order.setVariantId(variant.getId());
        order.setProductName(product.getName());
        order.setSelectedOptions(values.stream().map(OptionValue::getValue).collect(Collectors.joining(" | ")));
        order.setQuantity(quantity);
        order.setMonths(plan.getMonths());
        order.setInterestRate(plan.getInterestRate());
        order.setPrice(price);
        order.setDownPayment(downPayment);
        order.setLoanAmount(loanAmount);
        order.setTotalInterest(totalInterest);
        order.setMonthlyPayment(monthlyPayment);
        order.setTotalPayment(totalPayment);
        order.setCustomerName(request.getCustomerName().trim());
        order.setCustomerPhone(request.getCustomerPhone().trim());
        order.setCustomerEmail(trimToNull(request.getCustomerEmail()));
        order.setCustomerAddress(request.getCustomerAddress().trim());
        order.setIdentityNumber(request.getIdentityNumber().trim());
        order.setStatus("PENDING");
        return orderRepository.save(order);
    }

    @Transactional(readOnly = true)
    public List<InstallmentOrder> getOrdersByLoginEmail(String loginEmail) {
        if (loginEmail == null || loginEmail.isBlank()) {
            throw new IllegalArgumentException("Bạn cần đăng nhập để xem hồ sơ trả góp");
        }

        NguoiDung user = userRepository.findByEmail(loginEmail)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy tài khoản đăng nhập"));

        return orderRepository.findByUserIdOrderByCreatedAtDesc(user.getId());
    }

    @Transactional
    public void cancelOrder(Integer orderId, String loginEmail) {
        if (orderId == null) {
            throw new IllegalArgumentException("Mã hồ sơ không hợp lệ");
        }

        NguoiDung user = userRepository.findByEmail(loginEmail)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy tài khoản đăng nhập"));

        InstallmentOrder order = orderRepository.findById(orderId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy hồ sơ trả góp"));

        if (order.getUserId() == null || !order.getUserId().equals(user.getId())) {
            throw new IllegalArgumentException("Bạn không có quyền thao tác hồ sơ này");
        }

        if (!"PENDING".equalsIgnoreCase(order.getStatus())) {
            throw new IllegalArgumentException("Chỉ hồ sơ đang chờ duyệt mới có thể hủy");
        }

        order.setStatus("CANCELLED");
        orderRepository.save(order);
    }

    private ProductVariant resolveVariant(InstallmentOrderRequest request, Product product) {
        ProductVariant variant;
        if (request.getVariantId() != null) {
            variant = variantRepository.findById(request.getVariantId())
                    .orElseThrow(() -> new IllegalArgumentException("Phiên bản sản phẩm không tồn tại"));
        } else {
            variant = variantRepository.findFirstByProductIdAndIsDefaultTrue(product.getId())
                    .orElseThrow(() -> new IllegalArgumentException("Sản phẩm chưa có phiên bản mặc định"));
        }
        if (variant.getProduct() == null || !variant.getProduct().getId().equals(product.getId())) {
            throw new IllegalArgumentException("Phiên bản không thuộc sản phẩm đang mua");
        }
        return variant;
    }

    private void validateRequest(InstallmentOrderRequest request) {
        if (request.getProductId() == null) throw new IllegalArgumentException("Thiếu sản phẩm");
        if (request.getQuantity() == null || request.getQuantity() < 1 || request.getQuantity() > 10)
            throw new IllegalArgumentException("Số lượng phải từ 1 đến 10");
        if (request.getMonths() == null) throw new IllegalArgumentException("Vui lòng chọn số tháng");
        if (isBlank(request.getCustomerName())) throw new IllegalArgumentException("Vui lòng nhập họ tên");
        if (isBlank(request.getCustomerPhone()) || !request.getCustomerPhone().matches("^(0|\\+84)[0-9]{9,10}$"))
            throw new IllegalArgumentException("Số điện thoại không hợp lệ");
        if (isBlank(request.getCustomerAddress())) throw new IllegalArgumentException("Vui lòng nhập địa chỉ");
        if (isBlank(request.getIdentityNumber()) || !request.getIdentityNumber().matches("^[0-9]{9,12}$"))
            throw new IllegalArgumentException("CCCD/CMND phải gồm 9-12 chữ số");
        if (!Boolean.TRUE.equals(request.getAcceptedTerms()))
            throw new IllegalArgumentException("Bạn cần đồng ý điều khoản trả góp");
    }

    private boolean isBlank(String value) { return value == null || value.trim().isEmpty(); }
    private String trimToNull(String value) { return isBlank(value) ? null : value.trim(); }
}
