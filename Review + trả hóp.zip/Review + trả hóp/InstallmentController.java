package com.fpoly.controller.cilent;

import java.security.Principal;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fpoly.dto.InstallmentOrderRequest;
import com.fpoly.model.InstallmentOrder;
import com.fpoly.service.InstallmentService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class InstallmentController {
    private final InstallmentService installmentService;

    @PostMapping("/tra-gop/dang-ky")
    public String create(@ModelAttribute InstallmentOrderRequest request,
                         Principal principal,
                         RedirectAttributes redirectAttributes) {
        try {
            InstallmentOrder order = installmentService.createOrder(
                    request, principal == null ? null : principal.getName());
            redirectAttributes.addFlashAttribute("installmentSuccess",
                    "Đăng ký trả góp thành công. Mã hồ sơ: TG" + order.getId()
                    + ". Nhân viên sẽ liên hệ xác nhận qua điện thoại.");
        } catch (IllegalArgumentException ex) {
            redirectAttributes.addFlashAttribute("installmentError", ex.getMessage());
        }
        return "redirect:/san-pham/" + request.getProductId();
    }

    @GetMapping("/account/installments")
    public String myInstallments(Principal principal, Model model) {
        model.addAttribute("installmentOrders",
                installmentService.getOrdersByLoginEmail(principal.getName()));
        model.addAttribute("tab", "installments");
        return "account/installments";
    }

    @PostMapping("/account/installments/{id}/cancel")
    public String cancel(@PathVariable Integer id,
                         Principal principal,
                         RedirectAttributes redirectAttributes) {
        try {
            installmentService.cancelOrder(id, principal.getName());
            redirectAttributes.addFlashAttribute("success",
                    "Đã hủy hồ sơ trả góp TG" + id + ".");
        } catch (IllegalArgumentException ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/account/installments";
    }
}
