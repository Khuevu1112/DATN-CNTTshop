package com.fpoly.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.ui.Model;
import java.security.Principal;
import com.fpoly.service.CustomerOrderService;

@Controller
public class OrderController {

    private final CustomerOrderService orderService;

    public OrderController(CustomerOrderService orderService) {
        this.orderService = orderService;
    }

    @PostMapping("/orders/buy-now")
    public String buyNow(
            @RequestParam Integer productId,
            @RequestParam(required = false) Integer variantId,
            @RequestParam Integer quantity,
            @RequestParam(required = false) String note,
            RedirectAttributes ra,
            Principal principal
    ) {
        try {
            orderService.place(principal.getName(), productId, variantId, quantity, note);
            ra.addFlashAttribute("success", "Đặt hàng thành công, tồn kho đã được trừ đúng biến thể");
        } catch (IllegalArgumentException | IllegalStateException ex) {
            ra.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/orders";
    }

    @GetMapping("/orders")
    public String orders(Model model, Principal principal) {
        model.addAttribute("orders", orderService.listForUser(principal.getName()));
        return "order/index";
    }

    @PostMapping("/orders/{id}/return")
    public String requestReturn(@PathVariable Integer id, @RequestParam(required = false) String reason,
            Principal principal, RedirectAttributes ra) {
        try {
            orderService.requestReturn(id, principal.getName(), reason);
            ra.addFlashAttribute("success", "Đã gửi yêu cầu hoàn hàng");
        } catch (IllegalArgumentException | IllegalStateException ex) {
            ra.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/orders";
    }
}
