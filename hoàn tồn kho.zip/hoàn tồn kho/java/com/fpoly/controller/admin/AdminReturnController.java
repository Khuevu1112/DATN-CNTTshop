package com.fpoly.controller.admin;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.fpoly.service.CustomerOrderService;

@Controller
@RequestMapping("/admin/returns")
public class AdminReturnController {
    private final CustomerOrderService orderService;
    public AdminReturnController(CustomerOrderService orderService) { this.orderService = orderService; }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("returns", orderService.allReturns());
        return "admin/return-list";
    }

    @PostMapping("/{id}/approve")
    public String approve(@PathVariable Integer id, RedirectAttributes ra) {
        orderService.approveReturn(id);
        ra.addFlashAttribute("success", "Đã duyệt hoàn hàng và cộng lại tồn kho");
        return "redirect:/admin/returns";
    }

    @PostMapping("/{id}/reject")
    public String reject(@PathVariable Integer id, RedirectAttributes ra) {
        orderService.rejectReturn(id);
        ra.addFlashAttribute("success", "Đã từ chối yêu cầu hoàn hàng");
        return "redirect:/admin/returns";
    }
}
