package com.fpoly.model;

import java.time.LocalDateTime;
import jakarta.persistence.*;

@Entity
@Table(name = "RETURN_REQUEST")
public class ReturnRequest {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @OneToOne(optional = false) @JoinColumn(name = "order_id", unique = true)
    private CustomerOrder order;
    @Column(nullable = false, length = 500)
    private String reason;
    @Column(nullable = false, length = 30)
    private String status = "PENDING";
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();
    @Column(name = "processed_at")
    private LocalDateTime processedAt;

    public Integer getId() { return id; }
    public CustomerOrder getOrder() { return order; }
    public void setOrder(CustomerOrder order) { this.order = order; }
    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getProcessedAt() { return processedAt; }
    public void setProcessedAt(LocalDateTime processedAt) { this.processedAt = processedAt; }
}
