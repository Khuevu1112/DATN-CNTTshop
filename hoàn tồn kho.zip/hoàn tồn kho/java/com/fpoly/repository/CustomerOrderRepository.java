package com.fpoly.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.fpoly.model.CustomerOrder;

public interface CustomerOrderRepository extends JpaRepository<CustomerOrder, Integer> {
    @EntityGraph(attributePaths = {"items", "items.variant", "items.variant.product"})
    List<CustomerOrder> findByCustomerEmailOrderByCreatedAtDesc(String email);

    @EntityGraph(attributePaths = {"items", "items.variant", "items.variant.product", "customer"})
    @Query("select o from CustomerOrder o where o.id = :id")
    Optional<CustomerOrder> findWithItemsById(@Param("id") Integer id);
}
