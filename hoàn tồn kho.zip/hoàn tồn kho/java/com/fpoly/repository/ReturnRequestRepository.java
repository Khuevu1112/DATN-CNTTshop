package com.fpoly.repository;

import java.util.List;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.fpoly.model.ReturnRequest;
import jakarta.persistence.LockModeType;

public interface ReturnRequestRepository extends JpaRepository<ReturnRequest, Integer> {
    boolean existsByOrderId(Integer orderId);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select r from ReturnRequest r where r.id = :id")
    java.util.Optional<ReturnRequest> findByIdForUpdate(@Param("id") Integer id);

    @EntityGraph(attributePaths = {"order", "order.customer"})
    List<ReturnRequest> findAllByOrderByCreatedAtDesc();
}
