package com.fpoly.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.fpoly.model.*;
import com.fpoly.repository.*;

@Service
public class CustomerOrderService {
    private final CustomerOrderRepository orderRepository;
    private final ReturnRequestRepository returnRepository;
    private final NguoiDungRepository userRepository;
    private final ProductVariantRepository variantRepository;
    private final InventoryService inventoryService;

    public CustomerOrderService(CustomerOrderRepository orderRepository,
            ReturnRequestRepository returnRepository, NguoiDungRepository userRepository,
            ProductVariantRepository variantRepository, InventoryService inventoryService) {
        this.orderRepository = orderRepository;
        this.returnRepository = returnRepository;
        this.userRepository = userRepository;
        this.variantRepository = variantRepository;
        this.inventoryService = inventoryService;
    }

    @Transactional
    public CustomerOrder place(String email, Integer productId, Integer variantId, int quantity, String note) {
        if (variantId == null) {
            variantId = variantRepository.findFirstByProductIdAndIsDefaultTrue(productId)
                    .orElseThrow(() -> new IllegalArgumentException("Sản phẩm chưa có biến thể mặc định"))
                    .getId();
        }
        ProductVariant variant = inventoryService.subtract(variantId, quantity);
        if (!variant.getProduct().getId().equals(productId))
            throw new IllegalArgumentException("Biến thể không thuộc sản phẩm đã chọn");

        CustomerOrder order = new CustomerOrder();
        order.setCustomer(userRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy người dùng")));
        CustomerOrderItem item = new CustomerOrderItem();
        item.setVariant(variant);
        item.setQuantity(quantity);
        item.setUnitPrice(variant.getPrice());
        item.setNote(note);
        order.addItem(item);
        order.setTotalAmount(variant.getPrice().multiply(BigDecimal.valueOf(quantity)));
        return orderRepository.save(order);
    }

    @Transactional(readOnly = true)
    public List<CustomerOrder> listForUser(String email) {
        return orderRepository.findByCustomerEmailOrderByCreatedAtDesc(email);
    }

    @Transactional
    public void requestReturn(Integer orderId, String email, String reason) {
        CustomerOrder order = orderRepository.findWithItemsById(orderId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy đơn hàng"));
        if (!order.getCustomer().getEmail().equalsIgnoreCase(email))
            throw new IllegalArgumentException("Bạn không có quyền thao tác đơn này");
        if (returnRepository.existsByOrderId(orderId))
            throw new IllegalStateException("Đơn hàng đã có yêu cầu hoàn");
        ReturnRequest request = new ReturnRequest();
        request.setOrder(order);
        request.setReason(reason == null || reason.isBlank() ? "Khách yêu cầu hoàn hàng" : reason.trim());
        returnRepository.save(request);
        order.setStatus("RETURN_REQUESTED");
    }

    @Transactional
    public void approveReturn(Integer requestId) {
        ReturnRequest request = returnRepository.findByIdForUpdate(requestId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy yêu cầu hoàn"));
        if (!"PENDING".equals(request.getStatus())) return;
        CustomerOrder order = orderRepository.findWithItemsById(request.getOrder().getId())
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy đơn hàng"));
        inventoryService.restore(order);
        request.setStatus("APPROVED");
        request.setProcessedAt(LocalDateTime.now());
        order.setStatus("RETURNED");
    }

    @Transactional
    public void rejectReturn(Integer requestId) {
        ReturnRequest request = returnRepository.findByIdForUpdate(requestId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy yêu cầu hoàn"));
        if (!"PENDING".equals(request.getStatus())) return;
        request.setStatus("REJECTED");
        request.setProcessedAt(LocalDateTime.now());
        request.getOrder().setStatus("PLACED");
    }

    @Transactional(readOnly = true)
    public List<ReturnRequest> allReturns() { return returnRepository.findAllByOrderByCreatedAtDesc(); }
}
