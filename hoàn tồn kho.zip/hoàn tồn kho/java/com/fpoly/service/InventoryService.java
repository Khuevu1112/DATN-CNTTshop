package com.fpoly.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.fpoly.model.CustomerOrder;
import com.fpoly.model.CustomerOrderItem;
import com.fpoly.model.ProductVariant;
import com.fpoly.repository.ProductVariantRepository;

@Service
public class InventoryService {
    private final ProductVariantRepository variantRepository;
    public InventoryService(ProductVariantRepository variantRepository) {
        this.variantRepository = variantRepository;
    }

    @Transactional
    public ProductVariant subtract(Integer variantId, int quantity) {
        if (quantity <= 0) throw new IllegalArgumentException("Số lượng phải lớn hơn 0");
        ProductVariant variant = variantRepository.findByIdForUpdate(variantId)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy biến thể"));
        int stock = variant.getStock() == null ? 0 : variant.getStock();
        if (stock < quantity) throw new IllegalStateException("Không đủ tồn kho, hiện còn " + stock);
        variant.setStock(stock - quantity);
        return variantRepository.save(variant);
    }

    @Transactional
    public void restore(CustomerOrder order) {
        for (CustomerOrderItem item : order.getItems()) {
            ProductVariant variant = variantRepository.findByIdForUpdate(item.getVariant().getId())
                    .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy biến thể"));
            variant.setStock((variant.getStock() == null ? 0 : variant.getStock()) + item.getQuantity());
            variantRepository.save(variant);
        }
    }
}
