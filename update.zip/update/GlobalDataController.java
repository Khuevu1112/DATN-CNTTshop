package com.fpoly.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.fpoly.model.Category;
import com.fpoly.model.NguoiDung;
import com.fpoly.repository.CategoryRepository;
import com.fpoly.repository.NguoiDungRepository;

@ControllerAdvice
public class GlobalDataController {

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private NguoiDungRepository nguoiDungRepository;

    @ModelAttribute("menuCategories")
    public List<Category> menuCategories() {
        return categoryRepository.findAllByOrderBySortOrderAsc();
    }

    @ModelAttribute("currentUser")
    public NguoiDung currentUser(Authentication authentication) {

        if (authentication == null || !authentication.isAuthenticated()) {
            return null;
        }

        String email = authentication.getName();

        return nguoiDungRepository.findByEmail(email).orElse(null);
    }
}