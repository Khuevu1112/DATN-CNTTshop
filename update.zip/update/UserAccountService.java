package com.fpoly.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fpoly.model.NguoiDung;
import com.fpoly.model.enums.VaiTro;
import com.fpoly.repository.NguoiDungRepository;

@Service
public class UserAccountService {

    @Autowired
    private NguoiDungRepository repo;
    
    @Autowired
    private PasswordEncoder passwordEncoder;

    public NguoiDung findByEmail(String email) {
        return repo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy tài khoản"));
    }

    public List<NguoiDung> findAll() {
        return repo.findAll();
    }

    public NguoiDung findById(Integer id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy người dùng"));
    }

    public void updateProfile(
            String email,
            String hoTen,
            String soDienThoai,
            String diaChi,
            String tinhThanh,
            MultipartFile avatarFile
    ) throws IOException {

        NguoiDung user = findByEmail(email);

        user.setHoTen(hoTen);
        user.setSoDienThoai(soDienThoai);
        user.setDiaChi(diaChi);
        user.setTinhThanh(tinhThanh);

        if (avatarFile != null && !avatarFile.isEmpty()) {

            Path uploadPath = Paths.get("uploads/avatar");

            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            String fileName =
                    System.currentTimeMillis()
                    + "_"
                    + avatarFile.getOriginalFilename();

            Files.copy(
                    avatarFile.getInputStream(),
                    uploadPath.resolve(fileName),
                    StandardCopyOption.REPLACE_EXISTING
            );

            user.setAvatar(fileName);
        }

        repo.save(user);
    }

    public void adminUpdateUser(
            Integer id,
            String hoTen,
            String soDienThoai,
            VaiTro vaiTro,
            Boolean isActive
    ) {
        NguoiDung user = findById(id);

        user.setHoTen(hoTen);
        user.setSoDienThoai(soDienThoai);
        user.setVaiTro(vaiTro);
        user.setIsActive(isActive);

        repo.save(user);
    }
    
    public String changePassword(
            String email,
            String oldPassword,
            String newPassword,
            String confirmPassword){

        NguoiDung user = findByEmail(email);

        if(!passwordEncoder.matches(oldPassword,user.getMatKhau())){
            return "Mật khẩu hiện tại không đúng";
        }

        if(!newPassword.equals(confirmPassword)){
            return "Nhập lại mật khẩu không khớp";
        }

        user.setMatKhau(
                passwordEncoder.encode(newPassword)
        );

        repo.save(user);

        return null;
    }
}