package com.fpoly.controller.cilent;

import java.io.IOException;
import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fpoly.model.NguoiDung;
import com.fpoly.service.UserAccountService;

@Controller
@RequestMapping("/account")
public class AccountController {

    @Autowired
    private UserAccountService userAccountService;

    @GetMapping("/profile")
    public String profile(Model model, Principal principal) {

        NguoiDung user = userAccountService.findByEmail(principal.getName());

        model.addAttribute("user", user);

        return "account/profile";
    }

    @PostMapping("/profile")
    public String updateProfile(
            Principal principal,
            @RequestParam String hoTen,
            @RequestParam(required = false) String soDienThoai,
            @RequestParam(required = false) String diaChi,
            @RequestParam(required = false) String tinhThanh,
            @RequestParam(required = false) MultipartFile avatarFile
    ) throws IOException {

        userAccountService.updateProfile(
                principal.getName(),
                hoTen,
                soDienThoai,
                diaChi,
                tinhThanh,
                avatarFile
        );

        return "redirect:/account/profile?success=true";
    }
    
    @GetMapping("/change-password")
    public String changePasswordForm(Model model, Principal principal) {

        NguoiDung user = userAccountService.findByEmail(principal.getName());

        model.addAttribute("user", user);
        model.addAttribute("tab", "password");

        return "account/profile";
    }

    @PostMapping("/change-password")
    public String changePassword(
            Principal principal,
            @RequestParam String oldPassword,
            @RequestParam String newPassword,
            @RequestParam String confirmPassword,
            RedirectAttributes redirect
    ){

        String error = userAccountService.changePassword(
                principal.getName(),
                oldPassword,
                newPassword,
                confirmPassword
        );

        if(error != null){
            redirect.addFlashAttribute("error", error);
            return "redirect:/account/change-password";
        }

        redirect.addFlashAttribute("success",
                "Đổi mật khẩu thành công");

        return "redirect:/account/profile";
    }
}