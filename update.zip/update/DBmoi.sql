use shopDB

ALTER TABLE [USER] ADD address NVARCHAR(255);
ALTER TABLE [USER] ADD province NVARCHAR(100);
ALTER TABLE [USER] ADD avatar NVARCHAR(500);

SELECT id, email, avatar
FROM [USER]
WHERE email = 'admin@gmail.com';