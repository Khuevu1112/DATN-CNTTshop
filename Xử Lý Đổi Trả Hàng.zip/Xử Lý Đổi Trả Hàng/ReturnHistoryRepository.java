package com.fpoly.repository;

import com.fpoly.model.ReturnHistory;
import com.fpoly.model.ReturnRequest;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import org.springframework.data.jpa.repository.Query;

public interface ReturnHistoryRepository
        extends JpaRepository<ReturnHistory,Integer>{

    List<ReturnHistory> findByRequestOrderByCreatedAtAsc(ReturnRequest request);
    @Query("""
    SELECT DISTINCT r
    FROM ReturnRequest r
    LEFT JOIN FETCH r.items i
    LEFT JOIN FETCH i.orderItem oi
    LEFT JOIN FETCH oi.variant
    LEFT JOIN FETCH oi.order
    ORDER BY r.createdAt DESC
    """)
    List<ReturnRequest> findAllWithItems();
}