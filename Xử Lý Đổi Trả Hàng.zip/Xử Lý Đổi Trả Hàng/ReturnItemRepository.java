package com.fpoly.repository;

import com.fpoly.model.ReturnItem;
import com.fpoly.model.ReturnRequest;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ReturnItemRepository extends JpaRepository<ReturnItem, Integer> {

    List<ReturnItem> findByRequest(ReturnRequest request);

}