package com.fpoly.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "RETURN_REQUEST")
public class ReturnRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "ma_yeu_cau")
    private String maYeuCau;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private NguoiDung nguoiDung;

    @ManyToOne
    @JoinColumn(name = "order_id")
    private Order order;

    @Column(name = "ma_don")
    private String maDon;

    @Column(name = "ten_san_pham")
    private String tenSanPham;

    @Column(name = "kenh_mua")
    private String kenhMua;

    @Column(name = "ly_do")
    private String lyDo;

    @Column(name = "loai_yeu_cau")
    private String loaiYeuCau;
    
    @Column(name = "noi_dung")
    private String noiDung;

    @Column(name = "video_loi")
    private String videoLoi;

    @Column(name = "video_mo_hang")
    private String videoMoHang;

    @Column(name = "anh_loi1")
    private String anhLoi1;

    @Column(name = "anh_loi2")
    private String anhLoi2;

    @Column(name = "anh_loi3")
    private String anhLoi3;

    @Column(name = "trang_thai")
    private String trangThai;

    @Column(name = "ghi_chu_cskh")
    private String ghiChuCSKH;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @OneToMany(
    mappedBy = "request",
    cascade = CascadeType.ALL,
    orphanRemoval = true
    )
    private List<ReturnItem> items = new ArrayList<>();
    
    @PrePersist
    public void prePersist() {

        createdAt = LocalDateTime.now();

        trangThai = "pending";

        maYeuCau = "RT" + System.currentTimeMillis();

    }

    @PreUpdate
    public void preUpdate() {
        updatedAt = LocalDateTime.now();
    }

    //=========================
    // Getter Setter
    //=========================

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMaYeuCau() {
        return maYeuCau;
    }

    public void setMaYeuCau(String maYeuCau) {
        this.maYeuCau = maYeuCau;
    }

    public NguoiDung getNguoiDung() {
        return nguoiDung;
    }

    public void setNguoiDung(NguoiDung nguoiDung) {
        this.nguoiDung = nguoiDung;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public String getMaDon() {
        return maDon;
    }

    public void setMaDon(String maDon) {
        this.maDon = maDon;
    }

    public String getTenSanPham() {
        return tenSanPham;
    }

    public void setTenSanPham(String tenSanPham) {
        this.tenSanPham = tenSanPham;
    }

    public String getKenhMua() {
        return kenhMua;
    }

    public void setKenhMua(String kenhMua) {
        this.kenhMua = kenhMua;
    }

    public String getLyDo() {
        return lyDo;
    }

    public void setLyDo(String lyDo) {
        this.lyDo = lyDo;
    }

    public String getLoaiYeuCau() {
    return loaiYeuCau;
    }

    public void setLoaiYeuCau(String loaiYeuCau) {
        this.loaiYeuCau = loaiYeuCau;
    }
    
    public String getNoiDung() {
        return noiDung;
    }

    public void setNoiDung(String noiDung) {
        this.noiDung = noiDung;
    }

    public String getVideoLoi() {
        return videoLoi;
    }

    public void setVideoLoi(String videoLoi) {
        this.videoLoi = videoLoi;
    }

    public String getVideoMoHang() {
        return videoMoHang;
    }

    public void setVideoMoHang(String videoMoHang) {
        this.videoMoHang = videoMoHang;
    }

    public String getAnhLoi1() {
        return anhLoi1;
    }

    public void setAnhLoi1(String anhLoi1) {
        this.anhLoi1 = anhLoi1;
    }

    public String getAnhLoi2() {
        return anhLoi2;
    }

    public void setAnhLoi2(String anhLoi2) {
        this.anhLoi2 = anhLoi2;
    }

    public String getAnhLoi3() {
        return anhLoi3;
    }

    public void setAnhLoi3(String anhLoi3) {
        this.anhLoi3 = anhLoi3;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

    public String getGhiChuCSKH() {
        return ghiChuCSKH;
    }

    public void setGhiChuCSKH(String ghiChuCSKH) {
        this.ghiChuCSKH = ghiChuCSKH;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    public List<ReturnItem> getItems() {
    return items;
    }

    public void setItems(List<ReturnItem> items) {
        this.items = items;
    }
}