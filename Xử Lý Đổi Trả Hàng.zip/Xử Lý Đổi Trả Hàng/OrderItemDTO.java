package com.fpoly.dto;

import java.math.BigDecimal;

public class OrderItemDTO {

    private Integer id;

    private String tenSanPham;

    private String thongTinPhienBan;

    private Integer soLuong;

    private BigDecimal donGia;

    public OrderItemDTO() {
    }

    public OrderItemDTO(Integer id,
                        String tenSanPham,
                        String thongTinPhienBan,
                        Integer soLuong,
                        BigDecimal donGia) {

        this.id = id;
        this.tenSanPham = tenSanPham;
        this.thongTinPhienBan = thongTinPhienBan;
        this.soLuong = soLuong;
        this.donGia = donGia;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTenSanPham() {
        return tenSanPham;
    }

    public void setTenSanPham(String tenSanPham) {
        this.tenSanPham = tenSanPham;
    }

    public String getThongTinPhienBan() {
        return thongTinPhienBan;
    }

    public void setThongTinPhienBan(String thongTinPhienBan) {
        this.thongTinPhienBan = thongTinPhienBan;
    }

    public Integer getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(Integer soLuong) {
        this.soLuong = soLuong;
    }

    public BigDecimal getDonGia() {
        return donGia;
    }

    public void setDonGia(BigDecimal donGia) {
        this.donGia = donGia;
    }
}