package com.fpoly.controller.admin;

import java.util.HashMap;
import java.util.Map;
import com.fpoly.dto.OrderItemDTO;
import com.fpoly.model.Order;
import com.fpoly.model.OrderItem;
import com.fpoly.repository.NguoiDungRepository;
import com.fpoly.repository.OrderRepository;
import com.fpoly.model.ReturnRequest;
import com.fpoly.repository.OrderItemRepository;
import com.fpoly.service.OrderService;
import com.fpoly.service.ReturnService;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin/returns")
public class ReturnController {

    @Autowired
    private ReturnService returnService;

    @Autowired
    private NguoiDungRepository nguoiDungRepo;

    @Autowired
    private OrderRepository orderRepo;
    
    @Autowired
    private OrderService orderService;

    @Autowired
    private OrderItemRepository orderItemRepo;
    
    /*
    =====================================
    API ĐỔI / TRẢ HÀNG CHO DASHBOARD
    =====================================
    */
   @GetMapping("/api")
   @ResponseBody
   public Map<String, Object> dashboardReturns() {

       List<ReturnRequest> requests = returnService.getAll();

       long pending = requests.stream()
               .filter(r -> "pending".equalsIgnoreCase(r.getTrangThai()))
               .count();

       long processing = requests.stream()
               .filter(r -> "processing".equalsIgnoreCase(r.getTrangThai()))
               .count();

       long completed = requests.stream()
               .filter(r -> "completed".equalsIgnoreCase(r.getTrangThai()))
               .count();

       long rejected = requests.stream()
               .filter(r -> "rejected".equalsIgnoreCase(r.getTrangThai()))
               .count();


       List<Map<String, Object>> data = new ArrayList<>();

       for (ReturnRequest r : requests) {

           Map<String, Object> item = new HashMap<>();

           item.put("id", r.getId());
           item.put("maYeuCau", r.getMaYeuCau());
           item.put("maDon", r.getMaDon());
           item.put("tenSanPham", r.getTenSanPham());
           item.put("loaiYeuCau", r.getLoaiYeuCau());
           item.put("lyDo", r.getLyDo());
           item.put("noiDung", r.getNoiDung());
           item.put("trangThai", r.getTrangThai());
           item.put("createdAt", r.getCreatedAt());

           /*
            * Khách hàng
            */
           if (r.getNguoiDung() != null) {
               item.put(
                       "khachHang",
                       r.getNguoiDung().getHoTen()
               );
           } else {
               item.put("khachHang", "—");
           }

           data.add(item);
       }


       Map<String, Object> result = new HashMap<>();

       result.put("total", requests.size());
       result.put("pending", pending);
       result.put("processing", processing);
       result.put("completed", completed);
       result.put("rejected", rejected);
       result.put("returns", data);

       return result;
   }
    
    /*
     =====================================
     DANH SÁCH YÊU CẦU
     =====================================
     */

    @GetMapping("/create")
    public String createForm(Model model){

        model.addAttribute("users", nguoiDungRepo.findAll());

        model.addAttribute("orders", orderRepo.findAllByOrderByCreatedAtDesc());

        return "admin/returns/create";

    }    
    
    @GetMapping
    public String list(

            @RequestParam(required = false) String status,

            Model model){

        if(status == null || status.isBlank()){

            model.addAttribute(
                    "requests",
                    returnService.getAll());

        }else{

            model.addAttribute(
                    "requests",
                    returnService.getByStatus(status));

        }

        model.addAttribute("status",status);

        return "admin/returns/list";

    }

    /*
     =====================================
     CHI TIẾT
     =====================================
     */

    @GetMapping("/{id}")
    public String detail(

            @PathVariable Integer id,

            Model model){

        model.addAttribute(
                "request",
                returnService.getById(id));

        model.addAttribute(
                "history",
                returnService.getHistory(id));

        return "admin/returns/detail";

    }

    /*
     =====================================
     CHẤP NHẬN
     =====================================
     */

    @PostMapping("/{id}/accept")
    public String accept(

            @PathVariable Integer id){

        returnService.accept(id);

        return "redirect:/admin/returns/" + id;

    }

    /*
     =====================================
     TỪ CHỐI
     =====================================
     */

    @PostMapping("/{id}/reject")
    public String reject(

            @PathVariable Integer id,

            @RequestParam String note){

        returnService.reject(id,note);

        return "redirect:/admin/returns/" + id;

    }

    /*
     =====================================
     ĐANG XỬ LÝ
     =====================================
     */

    @PostMapping("/{id}/processing")
    public String processing(

            @PathVariable Integer id){

        returnService.processing(id);

        return "redirect:/admin/returns/" + id;

    }

    /*
     =====================================
     HOÀN THÀNH
     =====================================
     */

    @PostMapping("/{id}/completed")
    public String completed(

            @PathVariable Integer id){

        returnService.completed(id);

        return "redirect:/admin/returns/" + id;

    }

    @GetMapping("/order/{id}/items")
    @ResponseBody
    public List<OrderItemDTO> getItems(@PathVariable Integer id){

        Order order = orderService.layDonById(id);

        List<OrderItemDTO> result = new ArrayList<>();

        for(OrderItem item : orderItemRepo.findByOrder(order)){

            result.add(

                    new OrderItemDTO(

                            item.getId(),

                            item.getTenSanPham(),

                            item.getThongTinPhienBan(),

                            item.getSoLuong(),

                            item.getDonGia()

                    )

            );

        }

        return result;

    }
    
    @ModelAttribute("orders")
    public List<Order> orders(){

        return orderService.layTatCaDon();

    }
    
    @PostMapping("/create")
    @ResponseBody
    public String create(

            @RequestParam Integer orderId,

            @RequestParam(required = false)
            List<Integer> orderItemIds,

            @RequestParam String loaiYeuCau,

            @RequestParam String lyDo,

            @RequestParam String noiDung,

            @RequestParam String kenhMua){

        if(orderItemIds == null || orderItemIds.isEmpty()){

            throw new RuntimeException(
                    "Hãy chọn ít nhất một sản phẩm."
            );
        }

        returnService.createRequest(
                orderId,
                orderItemIds,
                loaiYeuCau,   // THÊM
                lyDo,
                noiDung,
                kenhMua
        );

        return "success";
    }
    
    @GetMapping("/orders")
    @ResponseBody
    public List<?> getOrdersForCreate() {

        return orderService.layTatCaDon()
                .stream()
                .map(order -> java.util.Map.of(
                        "id", order.getId(),
                        "maDon", order.getMaDonHang(),
                        "khachHang",
                        order.getNguoiDung() != null
                                ? order.getNguoiDung().getHoTen()
                                : ""
                ))
                .toList();
    }
}