package com.fpoly.service;

import com.fpoly.model.NguoiDung;
import com.fpoly.model.Order;
import com.fpoly.model.OrderItem;
import com.fpoly.model.ReturnHistory;
import com.fpoly.model.ReturnItem;
import com.fpoly.model.ReturnRequest;
import com.fpoly.model.ProductVariant;
import com.fpoly.repository.ProductVariantRepository;
import com.fpoly.repository.NguoiDungRepository;
import com.fpoly.repository.OrderItemRepository;
import com.fpoly.repository.OrderRepository;
import com.fpoly.repository.ReturnHistoryRepository;
import com.fpoly.repository.ReturnItemRepository;
import com.fpoly.repository.ReturnRequestRepository;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ReturnService {

    @Autowired
    private ReturnRequestRepository requestRepo;

    @Autowired
    private ReturnHistoryRepository historyRepo;

    @Autowired
    private OrderRepository orderRepo;

    @Autowired
    private NguoiDungRepository nguoiDungRepo;

    @Autowired
    private ReturnItemRepository returnItemRepo;
    
    @Autowired
    private OrderItemRepository orderItemRepo;
    
    @Autowired
    private ProductVariantRepository variantRepo;
    /*
        ==========================
        LẤY DANH SÁCH
        ==========================
    */

    public List<ReturnRequest> getAllRequest() {

        return requestRepo.findAllByOrderByCreatedAtDesc();

    }

    public List<ReturnRequest> getByStatus(String status){

        return requestRepo.findByTrangThaiOrderByCreatedAtDesc(status);

    }

    public ReturnRequest getById(Integer id){

        return requestRepo.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Không tìm thấy yêu cầu"));

    }

    public List<ReturnRequest> getAll(){

    return requestRepo.findAllWithItems();

}
    /*
        ==========================
        ADMIN TẠO YÊU CẦU
        ==========================
    */

    @Transactional
    public ReturnRequest createRequest(
            Integer userId,
            Integer orderId,
            String tenSanPham,
            String kenhMua,
            String loaiYeuCau,
            String lyDo,
            String noiDung){

        
        NguoiDung user = nguoiDungRepo.findById(userId)
                .orElseThrow(() ->
                        new RuntimeException("Không tìm thấy khách hàng"));

        Order order = null;

        if(orderId != null){

            order = orderRepo.findById(orderId)
                    .orElseThrow(() ->
                            new RuntimeException("Không tìm thấy đơn"));

        }

        ReturnRequest request = new ReturnRequest();

        request.setNguoiDung(user);

        request.setOrder(order);

        if(order != null){

            request.setMaDon(order.getMaDonHang());

        }

        request.setTenSanPham(tenSanPham);

        request.setKenhMua(kenhMua);

        request.setLoaiYeuCau(loaiYeuCau);
        
        request.setLyDo(lyDo);

        request.setNoiDung(noiDung);

        request.setTrangThai("pending");

        requestRepo.save(request);

        ReturnHistory history = new ReturnHistory();

        history.setRequest(request);

        history.setStatus("pending");

        history.setNote("Admin tạo yêu cầu");

        historyRepo.save(history);

        return request;

    }

    /*
        ==========================
        CẬP NHẬT TRẠNG THÁI
        ==========================
    */

    @Transactional
    public void updateStatus(
            Integer requestId,
            String status,
            String note){

        ReturnRequest request = getById(requestId);

        request.setTrangThai(status);

        requestRepo.save(request);

        ReturnHistory history = new ReturnHistory();

        history.setRequest(request);

        history.setStatus(status);

        history.setNote(note);

        history.setCreatedAt(LocalDateTime.now());

        historyRepo.save(history);

    }

    /*
        ==========================
        CHẤP NHẬN
        ==========================
    */

    @Transactional
    public void accept(Integer id){

        updateStatus(
                id,
                "accepted",
                "Admin đã chấp nhận yêu cầu");

    }

    /*
        ==========================
        TỪ CHỐI
        ==========================
    */

    @Transactional
    public void reject(Integer id,String reason){

        updateStatus(
                id,
                "rejected",
                reason);

    }

    /*
        ==========================
        ĐANG XỬ LÝ
        ==========================
    */

    @Transactional
    public void processing(Integer id){

        updateStatus(
                id,
                "processing",
                "Đang xử lý");

    }

    /*
        ==========================
        HOÀN TẤT
        ==========================
    */

    @Transactional
    public void completed(Integer id){

        ReturnRequest request = getById(id);

        List<ReturnItem> items =
                returnItemRepo.findByRequest(request);

        // =====================================
        // CỘNG LẠI TỒN KHO
        // =====================================

        for(ReturnItem item : items){

            ProductVariant variant =
                    item.getOrderItem().getVariant();

            variant.setStock(
                    variant.getStock() + item.getQuantity()
            );

            variantRepo.save(variant);
        }

        // =====================================
        // CẬP NHẬT YÊU CẦU ĐỔI / TRẢ
        // =====================================

        updateStatus(
                id,
                "completed",
                "Đã hoàn tất"
        );

        // =====================================
        // CẬP NHẬT ĐƠN HÀNG
        // =====================================

        Order order = request.getOrder();

        if(order != null){

            order.setTrangThai("returned");

            orderRepo.save(order);

        }

    }

    /*
        ==========================
        LỊCH SỬ
        ==========================
    */

    public List<ReturnHistory> getHistory(Integer requestId){

        ReturnRequest request = getById(requestId);

        return historyRepo.findByRequestOrderByCreatedAtAsc(request);

    }

    @Transactional
public void createRequest(

        Integer orderId,

        List<Integer> orderItemIds,

        String loaiYeuCau,

        String lyDo,

        String noiDung,

        String kenhMua

){

    if(orderItemIds == null || orderItemIds.isEmpty()){

        throw new RuntimeException(
                "Chưa chọn sản phẩm"
        );
    }


    Order order = orderRepo.findById(orderId)
            .orElseThrow(() ->
                    new RuntimeException(
                            "Không tìm thấy đơn hàng"
                    ));


    ReturnRequest request = new ReturnRequest();

    request.setNguoiDung(order.getNguoiDung());

    request.setOrder(order);

    request.setMaDon(order.getMaDonHang());

    request.setKenhMua(kenhMua);

    request.setLoaiYeuCau(loaiYeuCau);

    request.setLyDo(lyDo);

    request.setNoiDung(noiDung);

    request.setTrangThai("pending");


    StringBuilder tenSanPham =
            new StringBuilder();


    for(Integer itemId : orderItemIds){

        OrderItem item =
                orderItemRepo.findById(itemId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Không tìm thấy sản phẩm"
                                ));


        if(!item.getOrder().getId()
                .equals(orderId)){

            throw new RuntimeException(
                    "Sản phẩm không thuộc đơn hàng này."
            );
        }


        if(tenSanPham.length() > 0){

            tenSanPham.append(", ");

        }


        tenSanPham.append(
                item.getTenSanPham()
        );
    }


    request.setTenSanPham(
            tenSanPham.toString()
    );


    requestRepo.save(request);


    // =============================
    // LƯU CHI TIẾT SẢN PHẨM
    // =============================

    for(Integer itemId : orderItemIds){

        OrderItem orderItem =
                orderItemRepo.findById(itemId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Không tìm thấy sản phẩm"
                                ));


        ReturnItem ri = new ReturnItem();

        ri.setRequest(request);

        ri.setOrderItem(orderItem);

        ri.setQuantity(
                orderItem.getSoLuong()
        );

        returnItemRepo.save(ri);
    }
}
}