package com.fpoly.service;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.math.RoundingMode;

import org.springframework.stereotype.Service;

import com.fpoly.model.Order;
import com.fpoly.model.ProductVariant;
import com.fpoly.repository.OrderItemRepository;
import com.fpoly.repository.OrderRepository;
import com.fpoly.repository.ProductRepository;
import com.fpoly.repository.ProductVariantRepository;

@Service
public class AIStatisticService {
    private static final String HELP_MESSAGE = """
    🤖 Xin chào! Tôi là AI thống kê của CNTTShop.

    Tôi có thể hỗ trợ các nội dung sau:

    📊 DOANH THU
    • Doanh thu hôm nay
    • Tổng doanh thu
    • Doanh thu tháng này
    • Doanh thu năm nay
    • Giá trị trung bình đơn hàng

    📦 ĐƠN HÀNG
    • Đơn hàng hôm nay
    • Tổng đơn hàng
    • Đơn hoàn thành
    • Đơn bị hủy
    • Tỷ lệ giao thành công

    🔥 SẢN PHẨM
    • Top sản phẩm bán chạy
    • Top 3 sản phẩm
    • Best Seller

    📦 KHO
    • Tồn kho
    • Hết hàng
    • Sắp hết hàng
    • Có cần nhập thêm hàng?

    📈 ĐÁNH GIÁ
    • Đánh giá kinh doanh
    • Shop hôm nay thế nào?
    • Hoạt động ổn không?

    🔮 DỰ ĐOÁN
    • Dự đoán doanh thu
    • Xu hướng bán hàng
    • Doanh thu ngày mai

    💡 KHUYẾN NGHỊ
    • AI khuyến nghị
    • Tôi nên làm gì?
    • Có nên nhập hàng?

    Bạn cũng có thể hỏi tự nhiên như:

    "Hôm nay shop bán được bao nhiêu?"

    "Top sản phẩm?"

    "Có đơn hủy không?"

    "Tồn kho thế nào?"

    """;
    private final NumberFormat vn =
        NumberFormat.getCurrencyInstance(new Locale("vi","VN"));
    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;
    private final OrderItemRepository orderItemRepository;
    private final ProductVariantRepository productVariantRepository;

    public AIStatisticService(OrderRepository orderRepository,
                              ProductRepository productRepository,
                              OrderItemRepository orderItemRepository,
                              ProductVariantRepository productVariantRepository) {

        this.orderRepository = orderRepository;
        this.productRepository = productRepository;
        this.orderItemRepository = orderItemRepository;
        this.productVariantRepository = productVariantRepository;
    }

    private String normalize(String q){

    q=q.toLowerCase();

    q=q.replace("?","")
       .replace(".","")
       .replace(",","")
       .replace("!","")
       .replace("ạ","")
       .replace("ơi","")
       .replace("shop","")
       .replace("cửa hàng","")
       .replace("giúp","")
       .replace("cho tôi","")
       .replace("nhé","")
       .replace("đi","")
       .trim();

    return q;

}
    
    private boolean containsAny(String q,String... keys){

    for(String s:keys){

        if(q.contains(s)){

            return true;

        }

    }

    return false;

}
    
    public List<String> analyze() {

        List<String> insights = new ArrayList<>();

        NumberFormat vn = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));

        List<Order> orders = orderRepository.findAll();

        BigDecimal revenueToday = BigDecimal.ZERO;
        BigDecimal revenueAll = BigDecimal.ZERO;

        LocalDate today = LocalDate.now();

        int delivered = 0;
        int cancelled = 0;

        // =============================
        // Phân tích doanh thu
        // =============================
        for (Order order : orders) {

            if ("cancelled".equalsIgnoreCase(order.getTrangThai())) {
                cancelled++;
                continue;
            }

            revenueAll = revenueAll.add(order.getTongTien());

            if (today.equals(order.getCreatedAt().toLocalDate())) {
                revenueToday = revenueToday.add(order.getTongTien());
            }

            if ("delivered".equalsIgnoreCase(order.getTrangThai())) {
                delivered++;
            }
        }

        insights.add("💰 Tổng doanh thu đạt " + vn.format(revenueAll));

        insights.add("📅 Doanh thu hôm nay đạt " + vn.format(revenueToday));

        insights.add("📦 Đã hoàn thành " + delivered + " đơn hàng.");

        insights.add("❌ Có " + cancelled + " đơn hàng đã bị hủy.");

        insights.add("🖥️ Hệ thống hiện có " + productRepository.count() + " sản phẩm.");

        // =============================
        // Tỷ lệ hoàn thành đơn
        // =============================

        int totalOrders = delivered + cancelled;

        if (totalOrders > 0) {

            BigDecimal rate = BigDecimal.valueOf(delivered * 100.0 / totalOrders)
                    .setScale(1, RoundingMode.HALF_UP);

            insights.add("✅ Tỷ lệ giao hàng thành công đạt "
                    + rate + "%.");

        }
        
        // =============================
        // Top sản phẩm bán chạy
        // =============================
        List<Object[]> topProducts = orderItemRepository.getTopSellingProducts();

        if (!topProducts.isEmpty()) {

            Object[] top = topProducts.get(0);

            String productName = top[0].toString();

            Long quantity = ((Number) top[1]).longValue();

            insights.add("🔥 Sản phẩm bán chạy nhất là " + productName +
                    " (" + quantity + " sản phẩm).");
        }
        
        if (topProducts.size() >= 3) {

            insights.add("🏆 Top 3 sản phẩm bán chạy:");

            for (int i = 0; i < 3; i++) {

                Object[] row = topProducts.get(i);

                insights.add(
                        "   " + (i + 1) + ". "
                                + row[0]
                                + " (" + row[1] + " sản phẩm)");

            }

        }

        // =============================
        // Tồn kho thấp
        // =============================

        List<ProductVariant> lowStocks =
                productVariantRepository.findByStockLessThanEqual(5);

        if (lowStocks.isEmpty()) {

            insights.add("✅ Không có sản phẩm nào sắp hết hàng.");

        } else {

            insights.add("📦 Có " + lowStocks.size() + " sản phẩm sắp hết hàng.");

            for (ProductVariant pv : lowStocks) {

                if (pv.getStock() == 0) {

                    insights.add("❌ "
                            + pv.getProduct().getName()
                            + " đã hết hàng.");

                } else if (pv.getStock() <= 2) {

                    insights.add("🚨 "
                            + pv.getProduct().getName()
                            + " chỉ còn "
                            + pv.getStock()
                            + " sản phẩm.");

                } else {

                    insights.add("⚠ "
                            + pv.getProduct().getName()
                            + " còn "
                            + pv.getStock()
                            + " sản phẩm.");

                }

            }

        }

        // =============================
        // Đánh giá doanh thu
        // =============================
        if (revenueToday.compareTo(BigDecimal.valueOf(50_000_000)) >= 0) {

            insights.add("📈 Doanh thu hôm nay rất tốt.");

        } else if (revenueToday.compareTo(BigDecimal.valueOf(20_000_000)) >= 0) {

            insights.add("📊 Doanh thu hôm nay ở mức ổn định.");

        } else {

            insights.add("📉 Doanh thu hôm nay còn thấp, nên cân nhắc triển khai khuyến mãi.");

        }
        
        // =============================
        // Đánh giá đơn hàng
        // =============================
        if (cancelled > delivered / 2) {

            insights.add("⚠ Tỷ lệ hủy đơn khá cao, nên kiểm tra lại quy trình bán hàng.");

        }

        
        if (!orders.isEmpty()) {

            BigDecimal avgRevenue =
                    revenueAll.divide(
                            BigDecimal.valueOf(orders.size()),
                            0,
                            RoundingMode.HALF_UP);

            insights.add("💳 Giá trị trung bình mỗi đơn là "
                    + vn.format(avgRevenue));

        }
        
        // =============================
        // AI Recommendation
        // =============================

        // Khuyến nghị doanh thu
        if (revenueToday.compareTo(BigDecimal.valueOf(10_000_000)) < 0) {

            insights.add("💡 AI khuyến nghị triển khai Flash Sale hoặc mã giảm giá để kích cầu.");

        } else if (revenueToday.compareTo(BigDecimal.valueOf(30_000_000)) >= 0) {

            insights.add("💡 AI khuyến nghị tiếp tục duy trì các chương trình bán hàng hiện tại.");

        }

        // Khuyến nghị tồn kho
        if (!lowStocks.isEmpty()) {

            insights.add("💡 AI khuyến nghị nhập thêm hàng cho "
                    + lowStocks.size()
                    + " sản phẩm sắp hết kho.");

        }

        // Chất lượng đơn hàng
        if (cancelled == 0) {

            insights.add("🎉 AI đánh giá quy trình bán hàng hôm nay rất tốt, không có đơn bị hủy.");

        } else if (cancelled >= 5) {

            insights.add("⚠ AI phát hiện số lượng đơn hủy khá cao, nên kiểm tra lại vận chuyển hoặc chăm sóc khách hàng.");

        }


        // =============================
        // AI Forecast
        // =============================

        // Dự báo tồn kho
        if (lowStocks.size() >= 5) {

            insights.add("📦 AI dự đoán trong 3-5 ngày tới sẽ thiếu hàng ở nhiều sản phẩm nếu không nhập thêm.");

        } else if (lowStocks.size() > 0) {

            insights.add("📦 AI dự đoán sẽ cần bổ sung hàng cho một số sản phẩm trong vài ngày tới.");

        }


        // Dự báo xu hướng bán hàng
        if (delivered >= 20) {

            insights.add("📈 AI dự đoán xu hướng bán hàng sẽ tiếp tục tăng.");

        } else if (delivered >= 10) {

            insights.add("📊 AI dự đoán doanh số sẽ giữ ổn định.");

        } else {

            insights.add("📉 AI dự đoán doanh số có xu hướng giảm nếu không triển khai chương trình khuyến mãi.");

        }


        // Dự báo doanh thu ngày mai
        BigDecimal forecastRevenue;

        if (revenueToday.compareTo(BigDecimal.ZERO) == 0) {

            forecastRevenue = BigDecimal.valueOf(5_000_000);

        } else if (delivered >= 20) {

            // tăng khoảng 15%
            forecastRevenue = revenueToday.multiply(BigDecimal.valueOf(1.15));

        } else if (delivered >= 10) {

            // tăng khoảng 5%
            forecastRevenue = revenueToday.multiply(BigDecimal.valueOf(1.05));

        } else {

            // giảm khoảng 5%
            forecastRevenue = revenueToday.multiply(BigDecimal.valueOf(0.95));

        }

        forecastRevenue = forecastRevenue.setScale(0, RoundingMode.HALF_UP);

        insights.add("🔮 AI dự đoán doanh thu ngày mai khoảng "
                + vn.format(forecastRevenue) + ".");


        // Đánh giá sức khỏe kinh doanh
        if (delivered >= 20 && cancelled == 0 && lowStocks.size() <= 2) {

            insights.add("🟢 AI đánh giá tình hình kinh doanh đang ở mức RẤT TỐT.");

        } else if (delivered >= 10) {

            insights.add("🟡 AI đánh giá tình hình kinh doanh ở mức ỔN ĐỊNH.");

        } else {

            insights.add("🔴 AI đánh giá hoạt động kinh doanh cần được cải thiện.");

        }

        return insights;
    }
    
    public String answer(String question){

    if(question==null||question.isBlank()){

        return "Vui lòng nhập câu hỏi.";

    }

    String q=normalize(question);

    //=====================
    // Chào hỏi
    //=====================

    if(containsAny(q,

            "hello","hi","alo","xin chào","chào")){

        return HELP_MESSAGE;

    }

    if(containsAny(q,

            "cảm ơn","thanks","thank")){

        return "😊 Không có gì. Rất vui được hỗ trợ bạn.";

    }

    if(containsAny(q,

            "bye","tạm biệt","hẹn gặp")){

        return "👋 Hẹn gặp lại.";

    }

    //=====================
    // Intent Scoring
    //=====================

    int revenueToday=score(q,

            "doanh thu hôm nay",
            "hôm nay bán",
            "hôm nay kiếm",
            "doanh số hôm nay",
            "hôm nay thu");

    int revenueAll=score(q,

            "tổng doanh thu",
            "doanh thu",
            "doanh số",
            "tổng tiền");

    int orderToday=score(q,

            "đơn hôm nay",
            "đơn hàng hôm nay",
            "hôm nay có bao nhiêu đơn");

    int order=score(q,

            "đơn hàng",
            "order",
            "bao nhiêu đơn",
            "thống kê đơn");

    int product=score(q,

            "top",
            "bán chạy",
            "best seller",
            "sản phẩm",
            "laptop",
            "pc",
            "cpu",
            "ram",
            "ssd",
            "main",
            "vga");

    int stock=score(q,

            "kho",
            "tồn kho",
            "stock",
            "hết hàng",
            "sắp hết",
            "thiếu hàng");

    int recommend=score(q,

            "khuyến nghị",
            "gợi ý",
            "nên",
            "cải thiện");

    int forecast=score(q,

            "dự đoán",
            "forecast",
            "mai",
            "ngày mai",
            "tương lai",
            "xu hướng");

    int business=score(q,

            "đánh giá",
            "kinh doanh",
            "ổn không",
            "tình hình");

    int dashboard=score(q,

            "dashboard",
            "tổng quan",
            "báo cáo",
            "toàn bộ");

    int warning=score(q,

            "cảnh báo",
            "rủi ro",
            "vấn đề",
            "nguy hiểm");

    //=====================
    // Xử lý đặc biệt
    //=====================

    if(containsAny(q,

            "top 3",
            "top3",
            "ba sản phẩm",
            "3 sản phẩm")){

        return getTop3ProductAI();

    }

    if(containsAny(q,

            "đơn hủy",
            "hủy đơn")){

        return getCancelOrderAI();

    }

    if(containsAny(q,

            "đơn hoàn thành",
            "đã giao",
            "giao thành công")){

        return getDeliveredOrderAI();

    }

    if(containsAny(q,

            "tỷ lệ giao",
            "tỷ lệ thành công")){

        return getSuccessRateAI();

    }

    if(containsAny(q,

            "giá trị trung bình",
            "đơn trung bình")){

        return getAverageRevenueAI();

    }

    if(containsAny(q,

            "doanh thu tháng")){

        return getRevenueMonthAI();

    }

    if(containsAny(q,

            "doanh thu năm")){

        return getRevenueYearAI();

    }

    //=====================
    // Intent lớn nhất
    //=====================

    int max=Math.max(
            Math.max(revenueToday,revenueAll),
            Math.max(
                    Math.max(orderToday,order),
                    Math.max(
                            Math.max(product,stock),
                            Math.max(
                                    Math.max(recommend,forecast),
                                    Math.max(business,
                                            Math.max(dashboard,warning))
                            )
                    )
            )
    );

    if(max==0){

        return HELP_MESSAGE;

    }

    if(max==dashboard){

        return getDashboardAI();

    }

    if(max==warning){

        return getWarningAI();

    }

    if(max==revenueToday){

        return getRevenueTodayAI();

    }

    if(max==revenueAll){

        return getRevenueAllAI();

    }

    if(max==orderToday){

        return getOrderTodayAI();

    }

    if(max==order){

        return getOrderStatisticAI();

    }

    if(max==product){

        return getBestSellerAI();

    }

    if(max==stock){

        return getStockAI();

    }

    if(max==recommend){

        return getRecommendationAI();

    }

    if(max==forecast){

        return getForecastAI();

    }

    return getBusinessAI();

}

    private String getRevenueTodayAI(){

        BigDecimal revenue = BigDecimal.ZERO;

        int orders = 0;

        LocalDate today = LocalDate.now();

        for(Order o : orderRepository.findAll()){

            if("cancelled".equalsIgnoreCase(o.getTrangThai()))
                continue;

            if(today.equals(
                o.getCreatedAt().toLocalDate()
            )){
                revenue =
                revenue.add(o.getTongTien());
                orders++;
            }
        }
        return """
        📅 Báo cáo hôm nay:

        💰 Doanh thu: %s

        📦 Số đơn hàng: %d đơn

        AI nhận xét:
        %s
        """
        .formatted(
            vn.format(revenue),
            orders,
            revenue.compareTo(
                BigDecimal.valueOf(20000000)
            )>=0
            ?
            "Doanh thu đang tốt."
            :
            "Doanh thu còn thấp, nên chạy khuyến mãi."
        );
    }
    private String getRevenueAllAI(){

    BigDecimal revenue = BigDecimal.ZERO;
    for(Order o : orderRepository.findAll()){

        if("cancelled".equalsIgnoreCase(o.getTrangThai()))
            continue;
        revenue = revenue.add(o.getTongTien());

    }
    return "💰 Tổng doanh thu hiện tại là "
            + vn.format(revenue);

    }
    private String getOrderStatisticAI(){
    int done = 0;
    int cancel = 0;
    for(Order o:orderRepository.findAll()){


        if("delivered"
        .equalsIgnoreCase(o.getTrangThai()))
            done++;


        if("cancelled"
        .equalsIgnoreCase(o.getTrangThai()))
            cancel++;

    }
    return """
    📦 Thống kê đơn hàng:

    ✅ Hoàn thành: %d đơn

    ❌ Đã hủy: %d đơn

    AI đánh giá:
    %s
    """
    .formatted(
        done,
        cancel,
        cancel > done/2
        ?
        "Tỷ lệ hủy cao, cần kiểm tra vận chuyển."
        :
        "Quy trình bán hàng ổn định."
    );
}
    private String getBestSellerAI(){
    List<Object[]> list =
            orderItemRepository.getTopSellingProducts();
    if(list.isEmpty()){
        return "Chưa có dữ liệu sản phẩm.";
    }
    Object[] top = list.get(0);
    return "🔥 Sản phẩm bán chạy nhất: "
            + top[0]
            + " (" 
            + top[1]
            + " sản phẩm)";
}
    private String getStockAI(){
    List<ProductVariant> list =
            productVariantRepository
            .findByStockLessThanEqual(5);
    if(list.isEmpty()){
        return "✅ Hiện không có sản phẩm sắp hết.";
    }
    StringBuilder sb =
            new StringBuilder();
    sb.append("📦 Sản phẩm sắp hết:\n");
    for(ProductVariant pv:list){
        sb.append("- ")
          .append(pv.getProduct().getName())
          .append(": ")
          .append(pv.getStock())
          .append(" sản phẩm\n");
    }
    return sb.toString();
}
    private String getForecastAI(){
    BigDecimal revenue =
            BigDecimal.ZERO;
    int delivered = 0;
    for(Order o:orderRepository.findAll()){
        if("delivered".equalsIgnoreCase(o.getTrangThai())){
            delivered++;
        }
        if(!"cancelled".equalsIgnoreCase(o.getTrangThai())){
            revenue =
            revenue.add(o.getTongTien());
        }
    }
    BigDecimal forecast;
    if(delivered > 20){
        forecast =
        revenue.multiply(
        BigDecimal.valueOf(1.15));
    }else{
        forecast =
        revenue.multiply(
        BigDecimal.valueOf(1.05));
    }
    return "🔮 AI dự đoán doanh thu tiếp theo khoảng "
            + vn.format(forecast);
}
    private String getBusinessAI(){
    int done = 0;
    int cancel = 0;
    for(Order o:orderRepository.findAll()){
        if("delivered"
        .equalsIgnoreCase(o.getTrangThai()))
            done++;
        if("cancelled"
        .equalsIgnoreCase(o.getTrangThai()))
            cancel++;
    }
    if(done >=20 && cancel==0){
        return """
        🟢 AI đánh giá:

        Kinh doanh rất tốt.
        Đơn hàng ổn định.
        Không có đơn hủy.
        """;
    }
    if(done>=10){
        return """
        🟡 AI đánh giá:
        Hoạt động kinh doanh ổn định.
        """;
    }
    return """
    🔴 AI đánh giá:
    Doanh số thấp.
    Nên chạy khuyến mãi hoặc quảng cáo.
    """;
}
    private String getOrderTodayAI(){

    int total = 0;
    int delivered = 0;
    int cancelled = 0;

    LocalDate today = LocalDate.now();


    for(Order o : orderRepository.findAll()){

        if(o.getCreatedAt() == null)
            continue;


        if(today.equals(o.getCreatedAt().toLocalDate())){

            total++;


            if("delivered".equalsIgnoreCase(o.getTrangThai())){
                delivered++;
            }


            if("cancelled".equalsIgnoreCase(o.getTrangThai())){
                cancelled++;
            }

        }
    }


    return """
    📅 Thống kê đơn hàng hôm nay:

    📦 Tổng số đơn: %d

    ✅ Đã hoàn thành: %d đơn

    ❌ Đã hủy: %d đơn

    AI đánh giá:
    %s
    """
    .formatted(
            total,
            delivered,
            cancelled,
            cancelled > delivered / 2
            ?
            "Tỷ lệ hủy đơn hôm nay khá cao, nên kiểm tra lại quy trình xử lý."
            :
            "Đơn hàng hôm nay đang hoạt động ổn định."
    );
}
    
    private String getTop3ProductAI(){

    List<Object[]> list=
            orderItemRepository.getTopSellingProducts();

    if(list.isEmpty()){

        return "Chưa có dữ liệu.";

    }

    StringBuilder sb=new StringBuilder();

    sb.append("🏆 Top 3 sản phẩm bán chạy:\n\n");

    int size=Math.min(3,list.size());

    for(int i=0;i<size;i++){

        Object[] row=list.get(i);

        sb.append(i+1)
          .append(". ")
          .append(row[0])
          .append(" (")
          .append(row[1])
          .append(" sản phẩm)\n");

    }

    return sb.toString();

}
    
    private String getCancelOrderAI(){

    int total=0;

    for(Order o:orderRepository.findAll()){

        if("cancelled".equalsIgnoreCase(o.getTrangThai())){

            total++;

        }

    }

    return """
❌ Đơn hàng bị hủy

Số lượng: %d đơn
"""
.formatted(total);

}
    
    private String getDeliveredOrderAI(){

    int total=0;

    for(Order o:orderRepository.findAll()){

        if("delivered".equalsIgnoreCase(o.getTrangThai())){

            total++;

        }

    }

    return """
✅ Đơn hoàn thành

Tổng cộng: %d đơn
"""
.formatted(total);

}
    
    private String getSuccessRateAI(){

    int done=0;
    int cancel=0;

    for(Order o:orderRepository.findAll()){

        if("delivered".equalsIgnoreCase(o.getTrangThai()))
            done++;

        if("cancelled".equalsIgnoreCase(o.getTrangThai()))
            cancel++;

    }

    int total=done+cancel;

    if(total==0){

        return "Chưa có dữ liệu.";

    }

    BigDecimal rate=
            BigDecimal.valueOf(done*100.0/total)
            .setScale(1,RoundingMode.HALF_UP);

    return "📈 Tỷ lệ giao thành công: "+rate+"%";

}
    
    private String getAverageRevenueAI(){

    List<Order> orders=orderRepository.findAll();

    if(orders.isEmpty()){

        return "Chưa có đơn hàng.";

    }

    BigDecimal revenue=BigDecimal.ZERO;

    int count=0;

    for(Order o:orders){

        if("cancelled".equalsIgnoreCase(o.getTrangThai()))
            continue;

        revenue=revenue.add(o.getTongTien());

        count++;

    }

    if(count==0){

        return "Không có dữ liệu.";

    }

    BigDecimal avg=
            revenue.divide(
                    BigDecimal.valueOf(count),
                    0,
                    RoundingMode.HALF_UP);

    return "💰 Giá trị trung bình mỗi đơn: "
            +vn.format(avg);

}
    
    private String getRevenueMonthAI(){

    BigDecimal revenue=BigDecimal.ZERO;

    LocalDate now=LocalDate.now();

    for(Order o:orderRepository.findAll()){

        if("cancelled".equalsIgnoreCase(o.getTrangThai()))
            continue;

        LocalDate d=o.getCreatedAt().toLocalDate();

        if(d.getMonth()==now.getMonth()
                && d.getYear()==now.getYear()){

            revenue=revenue.add(o.getTongTien());

        }

    }

    return "📅 Doanh thu tháng này: "
            +vn.format(revenue);

}
    
    private String getRevenueYearAI(){

    BigDecimal revenue=BigDecimal.ZERO;

    int year=LocalDate.now().getYear();

    for(Order o:orderRepository.findAll()){

        if("cancelled".equalsIgnoreCase(o.getTrangThai()))
            continue;

        if(o.getCreatedAt().getYear()==year){

            revenue=revenue.add(o.getTongTien());

        }

    }

    return "📆 Doanh thu năm nay: "
            +vn.format(revenue);

}
    
    private String getOutOfStockAI(){

    StringBuilder sb=new StringBuilder();

    int total=0;

    for(ProductVariant pv:productVariantRepository.findAll()){

        if(pv.getStock()==0){

            total++;

            sb.append("- ")
              .append(pv.getProduct().getName())
              .append("\n");

        }

    }

    if(total==0){

        return "✅ Hiện chưa có sản phẩm hết hàng.";

    }

    return """
❌ Sản phẩm hết hàng:

%s
"""
.formatted(sb);

}
    
    private String getDashboardAI(){

    BigDecimal revenue = BigDecimal.ZERO;

    int orders = 0;
    int delivered = 0;
    int cancelled = 0;

    for(Order o : orderRepository.findAll()){

        if(!"cancelled".equalsIgnoreCase(o.getTrangThai())){
            revenue = revenue.add(o.getTongTien());
        }

        orders++;

        if("delivered".equalsIgnoreCase(o.getTrangThai()))
            delivered++;

        if("cancelled".equalsIgnoreCase(o.getTrangThai()))
            cancelled++;

    }

    return """
📊 TỔNG QUAN CỬA HÀNG

💰 Tổng doanh thu: %s

📦 Tổng đơn hàng: %d

✅ Hoàn thành: %d

❌ Hủy: %d

🖥️ Sản phẩm: %d
"""
.formatted(
        vn.format(revenue),
        orders,
        delivered,
        cancelled,
        productRepository.count()
);
}
    
    private String getStockAnalysisAI(){

    List<ProductVariant> list =
            productVariantRepository.findByStockLessThanEqual(5);

    if(list.isEmpty()){

        return """
📦 Kho hàng

Tất cả sản phẩm đều còn đủ hàng.

AI đánh giá:

🟢 Kho đang ở trạng thái tốt.
""";

    }

    if(list.size()<=3){

        return """
📦 Kho hàng

Có %d sản phẩm sắp hết.

🟡 Nên nhập thêm trong vài ngày tới.
"""
.formatted(list.size());

    }

    return """
📦 Kho hàng

Có %d sản phẩm sắp hết.

🔴 Nên nhập hàng ngay.
"""
.formatted(list.size());

}
    
    private String getWarningAI(){

    int cancel=0;

    for(Order o:orderRepository.findAll()){

        if("cancelled".equalsIgnoreCase(o.getTrangThai())){

            cancel++;

        }

    }

    List<ProductVariant> low =
            productVariantRepository.findByStockLessThanEqual(5);

    StringBuilder sb=new StringBuilder();

    sb.append("🚨 CẢNH BÁO\n\n");

    if(cancel>=5){

        sb.append("• Đơn hủy đang cao.\n");

    }

    if(low.size()>=3){

        sb.append("• Kho sắp hết nhiều sản phẩm.\n");

    }

    if(cancel<5 && low.size()<3){

        sb.append("Không có cảnh báo nào.\n");

    }

    return sb.toString();

}
    
    private String getRecommendationAI(){

        int cancel=0;
        int delivered=0;

        for(Order o:orderRepository.findAll()){

            if("cancelled".equalsIgnoreCase(o.getTrangThai()))
                cancel++;

            if("delivered".equalsIgnoreCase(o.getTrangThai()))
                delivered++;

        }

        List<ProductVariant> low =
                productVariantRepository.findByStockLessThanEqual(5);

        StringBuilder sb=new StringBuilder();

        sb.append("💡 AI KHUYẾN NGHỊ\n\n");

        if(cancel>=5){

            sb.append("• Kiểm tra quy trình giao hàng.\n");

            sb.append("• Gọi xác nhận khách trước khi giao.\n\n");

        }

        if(low.size()>0){

            sb.append("• Nhập thêm hàng cho ")
                    .append(low.size())
                    .append(" sản phẩm.\n\n");

        }

        if(delivered<10){

            sb.append("• Chạy Flash Sale.\n");

            sb.append("• Tạo Voucher giảm giá.\n");

            sb.append("• Quảng cáo Facebook/TikTok.\n");

        }else{

            sb.append("• Tiếp tục duy trì chiến lược hiện tại.\n");

            sb.append("• Đẩy mạnh sản phẩm bán chạy.\n");

        }

        return sb.toString();

    }    

    private int score(String text,String...keys){

        int score=0;

        for(String key:keys){

            if(text.contains(key.toLowerCase())){

                score++;

            }

        }

        return score;

    }
}