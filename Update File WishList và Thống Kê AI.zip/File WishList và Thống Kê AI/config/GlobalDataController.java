package com.fpoly.config;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.fpoly.model.Category;
import com.fpoly.model.NguoiDung;
import com.fpoly.model.Notification;
import com.fpoly.repository.CategoryRepository;
import com.fpoly.repository.NguoiDungRepository;
import com.fpoly.repository.NotificationRepository;
import com.fpoly.service.CartService;
import com.fpoly.service.NotificationService;

@ControllerAdvice
public class GlobalDataController {

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private CartService cartService;
    
    @Autowired
    private NotificationRepository notificationRepo;

    @Autowired
    private NguoiDungRepository nguoiDungRepo;

    @ModelAttribute("menuCategories")
    public List<Category> menuCategories() {
        return categoryRepository.findAllByOrderBySortOrderAsc();
    }

    // Nhật - Quản lý giỏ hàng: đưa số lượng món trong giỏ ra mọi trang (hiện badge ở header)
    @ModelAttribute("cartItemCount")
    public int cartItemCount(Principal principal) {
        if (principal == null) {
            return 0;
        }
        try {
            return cartService.demSoLuongItem(principal.getName());
        } catch (RuntimeException e) {
            return 0;
        }
    }
@ModelAttribute("notifications")
public List<Notification> notifications(Principal principal){

    if(principal == null){
        return List.of();
    }

NguoiDung user =
        nguoiDungRepo.findByEmail(principal.getName())
                .orElse(null);

    if(user == null){
        return List.of();
    }

    return notificationRepo
            .findTop10ByNguoiDungOrderByCreatedAtDesc(user);
}
@ModelAttribute("notificationCount")
public long notificationCount(Principal principal){

    if(principal == null){
        return 0;
    }

NguoiDung user =
        nguoiDungRepo.findByEmail(principal.getName())
                .orElse(null);

    if(user == null){
        return 0;
    }

    return notificationRepo
            .countByNguoiDungAndIsReadFalse(user);
}
}
