package com.fpoly.controller;

import com.fpoly.model.Product;
import com.fpoly.repository.ProductRepository;
import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.fpoly.service.WishlistService;

@Controller
@RequestMapping("/wishlist")
public class WishlistController {

    @Autowired
    private WishlistService wishlistService;
    @Autowired
    private ProductRepository productRepo;
    
    // Hiển thị danh sách yêu thích
    @GetMapping
    public String index(
            Principal principal,
            Model model) {

        if (principal == null) {
            return "redirect:/login";
        }

        model.addAttribute(
                "list",
                wishlistService.getWishlist(principal.getName()));

        model.addAttribute(
                "title",
                "Danh sách yêu thích");

        model.addAttribute(
                "content",
                "wishlist/index");

        return "layout/Base";
    }

    // Thêm vào yêu thích
    @PostMapping("/toggle/{id}")
    public String toggle(
            @PathVariable Integer id,
            Principal principal){

        if(principal == null){
            return "redirect:/login";
        }

        wishlistService.toggle(
                principal.getName(),
                id);

        Product product = productRepo.findById(id)
                .orElseThrow();

        return "redirect:/product/" + product.getSlug();
    }

    // Xóa khỏi yêu thích
    @PostMapping("/remove/{id}")
    public String remove(
            @PathVariable Integer id,
            Principal principal) {

        if (principal == null) {
            return "redirect:/login";
        }

        wishlistService.remove(
                principal.getName(),
                id);

        return "redirect:/wishlist";
    }

}