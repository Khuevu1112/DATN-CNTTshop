package com.fpoly.controller;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.fpoly.service.AIStatisticService;

@RestController
@RequestMapping("/api/ai")
@CrossOrigin("*")
public class AIController {


    private final AIStatisticService aiStatisticService;


    public AIController(AIStatisticService aiStatisticService) {
        this.aiStatisticService = aiStatisticService;
    }



    // ===============================
    // AI CHAT HỎI ĐÁP
    // ===============================
    @PostMapping("/ask")
    public ResponseEntity<?> ask(
            @RequestBody Map<String,String> request
    ){

        String question = request.get("question");


        if(question == null || question.trim().isEmpty()){

            return ResponseEntity.badRequest()
                    .body(
                        Map.of(
                            "answer",
                            "Vui lòng nhập câu hỏi."
                        )
                    );
        }



        String answer =
                aiStatisticService.answer(question);



        return ResponseEntity.ok(
                Map.of(
                    "question", question,
                    "answer", answer
                )
        );

    }




    // ===============================
    // AI PHÂN TÍCH DASHBOARD
    // ===============================
    @GetMapping("/analysis")
    public ResponseEntity<?> analysis(){

        return ResponseEntity.ok(
                aiStatisticService.analyze()
        );

    }


}