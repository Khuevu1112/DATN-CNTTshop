package com.fpoly.controller;

import com.fpoly.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/notification")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @GetMapping("/read/{id}")
    public String read(@PathVariable Integer id){

        notificationService.read(id);

        return "redirect:/";

    }

}