package com.fpoly.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "WISHLIST")
public class Wishlist {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private NguoiDung nguoiDung;

    @ManyToOne
    @JoinColumn(name = "product_id")
    private Product product;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "low_stock_notified")
    private Boolean lowStockNotified = false;
    
    @Column(name = "discount_notified")
    private Boolean discountNotified = false;
    
    @Column(name="back_in_stock_notified")
    private Boolean backInStockNotified = false;
    
    @Column(name="receive_email")
    private Boolean receiveEmail = true;
    
    @PrePersist
    public void prePersist() {

        createdAt = LocalDateTime.now();

        if (discountNotified == null) {
            discountNotified = false;
        }

        if (lowStockNotified == null) {
            lowStockNotified = false;
        }

        if (backInStockNotified == null) {
            backInStockNotified = false;
        }

        if (receiveEmail == null) {
            receiveEmail = true;
        }
    }

    public Wishlist() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public NguoiDung getNguoiDung() {
        return nguoiDung;
    }

    public void setNguoiDung(NguoiDung nguoiDung) {
        this.nguoiDung = nguoiDung;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public Boolean getLowStockNotified() {
    return lowStockNotified;
    }

    public void setLowStockNotified(Boolean lowStockNotified) {
        this.lowStockNotified = lowStockNotified;
    }
    
    public Boolean getDiscountNotified() {
    return discountNotified;
    }

    public void setDiscountNotified(Boolean discountNotified) {
        this.discountNotified = discountNotified;
    }

    public Boolean getBackInStockNotified() {
        return backInStockNotified;
    }

    public void setBackInStockNotified(Boolean backInStockNotified) {
        this.backInStockNotified = backInStockNotified;
    }

    public Boolean getReceiveEmail() {
        return receiveEmail;
    }

    public void setReceiveEmail(Boolean receiveEmail) {
        this.receiveEmail = receiveEmail;
    } 
}