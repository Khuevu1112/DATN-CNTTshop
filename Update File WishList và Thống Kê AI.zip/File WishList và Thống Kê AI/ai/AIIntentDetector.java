package com.fpoly.ai;

import org.springframework.stereotype.Component;

import java.text.Normalizer;
import java.util.*;

@Component
    public class AIIntentDetector {private String normalize(String text){

        text=text.toLowerCase();

        text=Normalizer.normalize(text,Normalizer.Form.NFD);

        text=text.replaceAll("\\p{M}","");

        text=text.replaceAll("[^a-z0-9 ]"," ");

        text=text.replaceAll("\\s+"," ");

        return text.trim();

    }
    
    private int score(String q,List<String> keywords){

    int score=0;

    for(String key:keywords){

        if(q.contains(key)){

            score++;

        }

    }

    return score;

}
    
    private boolean match(String q,List<String> keywords){

        for(String k:keywords){

            if(q.contains(k))

                return true;

        }

        return false;

    }
    private final List<String> revenueToday=Arrays.asList(

    "doanh thu hom nay",

    "hom nay ban duoc",

    "hom nay thu duoc",

    "hom nay bao nhieu tien",

    "ban duoc bao nhieu",

    "today revenue"

    );
    private final List<String> revenueAll=Arrays.asList(

    "tong doanh thu",

    "tong tien",

    "tong thu",

    "doanh thu",

    "tong ban"

    );
    private final List<String> bestSeller=Arrays.asList(

    "ban chay nhat",

    "best seller",

    "san pham ban chay",

    "mat hang ban chay"

    );
    private final List<String> topProducts=Arrays.asList(

    "top",

    "top san pham",

    "top ban chay",

    "xep hang"

    );
    private final List<String> stock=Arrays.asList(

    "ton kho",

    "sap het",

    "het hang",

    "con it",

    "it hang"

    );
    private final List<String> forecast=Arrays.asList(

    "du doan",

    "ngay mai",

    "forecast",

    "tuong lai"

    );
    private final List<String> business=Arrays.asList(

    "danh gia",

    "kinh doanh",

    "tinh hinh",

    "suc khoe"

    );
    private final List<String> greeting=Arrays.asList(

    "xin chao",

    "hello",

    "hi",

    "alo",

    "chao"

    );
    private final List<String> thanks=Arrays.asList(

    "cam on",

    "thank",

    "thanks"

    );
    public AIIntent detect(String question){

        String q=normalize(question);

        if(match(q,greeting))
            return AIIntent.GREETING;

        if(match(q,thanks))
            return AIIntent.THANKS;

        if(q.contains("ban la ai"))
            return AIIntent.WHO_ARE_YOU;

        if(match(q,revenueToday))
            return AIIntent.REVENUE_TODAY;

        if(match(q,revenueAll))
            return AIIntent.REVENUE_ALL;

        if(match(q,bestSeller))
            return AIIntent.BEST_SELLER;

        if(match(q,topProducts))
            return AIIntent.TOP_PRODUCTS;

        if(match(q,stock))
            return AIIntent.LOW_STOCK;

        if(q.contains("don huy"))
            return AIIntent.CANCELLED;

        if(q.contains("don hang"))
            return AIIntent.DELIVERED;

        if(match(q,forecast))
            return AIIntent.FORECAST;

        if(match(q,business))
            return AIIntent.BUSINESS;

        return AIIntent.UNKNOWN;

    }
    
    public List<AIResult> detectAll(String question){

    String q=normalize(question);

    List<AIResult> results=new ArrayList<>();

    add(results,AIIntent.REVENUE_TODAY,
            score(q,revenueToday));

    add(results,AIIntent.REVENUE_ALL,
            score(q,revenueAll));

    add(results,AIIntent.BEST_SELLER,
            score(q,bestSeller));

    add(results,AIIntent.TOP_PRODUCTS,
            score(q,topProducts));

    add(results,AIIntent.LOW_STOCK,
            score(q,stock));

    add(results,AIIntent.FORECAST,
            score(q,forecast));

    add(results,AIIntent.BUSINESS,
            score(q,business));

    add(results,AIIntent.GREETING,
            score(q,greeting));

    add(results,AIIntent.THANKS,
            score(q,thanks));

    results.sort((a,b)->

            Integer.compare(
                    b.getScore(),
                    a.getScore()));

    return results;

}
    private void add(List<AIResult> list,
                 AIIntent intent,
                 int score){

    if(score>0){

        list.add(new AIResult(intent,score));

    }

}
}