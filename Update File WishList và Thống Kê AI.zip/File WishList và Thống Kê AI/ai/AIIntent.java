package com.fpoly.ai;

public enum AIIntent {

    GREETING,

    THANKS,

    WHO_ARE_YOU,

    REVENUE_TODAY,

    REVENUE_ALL,

    BEST_SELLER,

    TOP_PRODUCTS,

    LOW_STOCK,

    DELIVERED,

    CANCELLED,

    FORECAST,

    BUSINESS,

    HELP,

    UNKNOWN

}