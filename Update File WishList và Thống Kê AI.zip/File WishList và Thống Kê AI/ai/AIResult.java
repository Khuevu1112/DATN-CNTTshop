package com.fpoly.ai;

public class AIResult {

    private AIIntent intent;

    private int score;

    public AIResult(AIIntent intent, int score) {
        this.intent = intent;
        this.score = score;
    }

    public AIIntent getIntent() {
        return intent;
    }

    public int getScore() {
        return score;
    }
}