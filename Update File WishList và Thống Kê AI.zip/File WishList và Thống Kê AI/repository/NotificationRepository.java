package com.fpoly.repository;

import com.fpoly.model.NguoiDung;
import com.fpoly.model.Notification;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NotificationRepository
        extends JpaRepository<Notification,Integer>{

    List<Notification> findTop10ByNguoiDungOrderByCreatedAtDesc(
            NguoiDung nguoiDung);

    List<Notification> findByNguoiDungAndIsReadFalseOrderByCreatedAtDesc(
            NguoiDung nguoiDung);

    long countByNguoiDungAndIsReadFalse(
            NguoiDung nguoiDung);
}