package com.fpoly.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.fpoly.model.Order;
import com.fpoly.model.OrderItem;

public interface OrderItemRepository extends JpaRepository<OrderItem, Integer> {
    List<OrderItem> findByOrder(Order order);
    @Query("""
    SELECT oi.tenSanPham,
           SUM(oi.soLuong)
    FROM OrderItem oi
    GROUP BY oi.tenSanPham
    ORDER BY SUM(oi.soLuong) DESC
    """)
    List<Object[]> getTopSellingProducts();
}