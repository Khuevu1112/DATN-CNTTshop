package com.fpoly.repository;

import com.fpoly.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import com.fpoly.model.ProductVariant;

public interface ProductVariantRepository extends JpaRepository<ProductVariant, Integer> {
    // Các sản phẩm sắp hết hàng
    List<ProductVariant> findByStockLessThanEqual(Integer stock);
    ProductVariant findByProduct(Product product);
}