package com.fpoly.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;
import com.fpoly.model.NguoiDung;
import com.fpoly.model.Order;
import java.math.BigDecimal;
    
public interface OrderRepository extends JpaRepository<Order, Integer> {
    List<Order> findByNguoiDungOrderByCreatedAtDesc(NguoiDung nguoiDung);

    List<Order> findByTrangThaiOrderByCreatedAtDesc(String trangThai);

    List<Order> findAllByOrderByCreatedAtDesc();

    Optional<Order> findByMaDonHang(String maDonHang);
    

@Query("""
    SELECT COALESCE(SUM(o.tongTien),0)
    FROM Order o
    WHERE o.trangThai='delivered'
""")
BigDecimal getTotalRevenue();

@Query("""
    SELECT COUNT(o)
    FROM Order o
    WHERE o.trangThai='delivered'
""")
Long getTotalDeliveredOrder();
}