package com.fpoly.service;

import com.fpoly.model.NguoiDung;
import com.fpoly.model.Product;
import com.fpoly.model.Wishlist;
import com.fpoly.repository.NguoiDungRepository;
import com.fpoly.repository.ProductRepository;
import com.fpoly.repository.WishlistRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class WishlistService {

    @Autowired
    private WishlistRepository wishlistRepo;

    @Autowired
    private NguoiDungRepository nguoiDungRepo;

    @Autowired
    private ProductRepository productRepo;

    // Lấy danh sách yêu thích của user
    public List<Wishlist> getWishlist(String email) {

        NguoiDung user = nguoiDungRepo.findByEmail(email)
                .orElseThrow(() ->
                        new RuntimeException("Không tìm thấy người dùng"));

        return wishlistRepo.findByNguoiDungOrderByCreatedAtDesc(user);
    }

    // Thêm vào wishlist
    public void add(String email, Integer productId) {

        NguoiDung user = nguoiDungRepo.findByEmail(email)
                .orElseThrow(() ->
                        new RuntimeException("Không tìm thấy người dùng"));

        Product product = productRepo.findById(productId)
                .orElseThrow(() ->
                        new RuntimeException("Không tìm thấy sản phẩm"));

        if (wishlistRepo.existsByNguoiDungAndProduct(user, product)) {
            return;
        }

        Wishlist wishlist = new Wishlist();

        wishlist.setNguoiDung(user);

        wishlist.setProduct(product);

        wishlistRepo.save(wishlist);
    }

    // Xóa khỏi wishlist
    public void remove(String email, Integer productId) {

        NguoiDung user = nguoiDungRepo.findByEmail(email)
                .orElseThrow(() ->
                        new RuntimeException("Không tìm thấy người dùng"));

        Product product = productRepo.findById(productId)
                .orElseThrow(() ->
                        new RuntimeException("Không tìm thấy sản phẩm"));

        wishlistRepo.deleteByNguoiDungAndProduct(user, product);
    }

    // Kiểm tra sản phẩm đã yêu thích chưa
    public boolean isFavorite(String email, Integer productId) {

        NguoiDung user = nguoiDungRepo.findByEmail(email)
                .orElseThrow(() ->
                        new RuntimeException("Không tìm thấy người dùng"));

        Product product = productRepo.findById(productId)
                .orElseThrow(() ->
                        new RuntimeException("Không tìm thấy sản phẩm"));

        return wishlistRepo.existsByNguoiDungAndProduct(user, product);
    }
    
    public void toggle(String email, Integer productId){

        NguoiDung user = nguoiDungRepo.findByEmail(email)
                .orElseThrow();

        Product product = productRepo.findById(productId)
                .orElseThrow();

        Optional<Wishlist> wishlist =
                wishlistRepo.findByNguoiDungAndProduct(user, product);

        if (wishlist.isPresent()) {

            wishlistRepo.delete(wishlist.get());

        } else {

            Wishlist w = new Wishlist();

            w.setNguoiDung(user);

            w.setProduct(product);

            wishlistRepo.save(w);
        }
    }

}