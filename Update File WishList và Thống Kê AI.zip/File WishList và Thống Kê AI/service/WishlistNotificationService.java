package com.fpoly.service;

import com.fpoly.model.Product;
import com.fpoly.model.Wishlist;
import com.fpoly.repository.NotificationRepository;
import com.fpoly.repository.WishlistRepository;
import com.fpoly.service.MailService.EmailService;
import java.math.BigDecimal;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WishlistNotificationService {

    @Autowired
    private WishlistRepository wishlistRepo;

    @Autowired
    private EmailService emailService;

    @Autowired
    private NotificationService notificationService;
    
    @Autowired
    private NotificationRepository notificationRepo;
    
    public void notifyDiscount(
            Product product,
            BigDecimal oldPrice,
            BigDecimal newPrice){

        List<Wishlist> list =
                wishlistRepo.findByProduct(product);

        for(Wishlist w : list){

            // Đã gửi rồi
            if(Boolean.TRUE.equals(w.getDiscountNotified())){
                continue;
            }

            if (!Boolean.TRUE.equals(w.getReceiveEmail())) {
                continue;
            }
            try{

                emailService.sendWishlistDiscountEmail(
                        w.getNguoiDung().getEmail(),
                        product,
                        oldPrice,
                        newPrice
                );

                notificationService.create(

                        w.getNguoiDung(),

                        product,

                        "🔥 Sản phẩm giảm giá",

                        product.getName() + " vừa giảm từ "
                                + oldPrice + " xuống "
                                + newPrice + " VNĐ.",

                        "DISCOUNT"

                );
                
                w.setDiscountNotified(true);

                wishlistRepo.save(w);

            }catch(Exception ex){

                ex.printStackTrace();

            }

        }

    }
    
    public void notifyLowStock(Product product, Integer stock){

        List<Wishlist> list = wishlistRepo.findByProduct(product);

        for(Wishlist w : list){

            // Đã gửi rồi thì bỏ qua
            if(Boolean.TRUE.equals(w.getLowStockNotified())){
                continue;
            }

            if (!Boolean.TRUE.equals(w.getReceiveEmail())) {
                continue;
            }
            try{

                emailService.sendLowStockEmail(
                        w.getNguoiDung().getEmail(),
                        product,
                        stock
                );

                notificationService.create(

                        w.getNguoiDung(),

                        product,

                        "⚠️ Sắp hết hàng",

                        product.getName()
                                + " chỉ còn "
                                + stock
                                + " sản phẩm.",

                        "LOW_STOCK"

                );
                // đánh dấu đã gửi
                w.setLowStockNotified(true);

                wishlistRepo.save(w);

            }catch(Exception ex){

                ex.printStackTrace();

            }
        }
    }
    
    public void notifyBackInStock(Product product){

    List<Wishlist> list = wishlistRepo.findByProduct(product);

    for(Wishlist w : list){

        if(Boolean.TRUE.equals(w.getBackInStockNotified())){
            continue;
        }

        if(!Boolean.TRUE.equals(w.getReceiveEmail())){
            continue;
        }

        try{

            emailService.sendBackInStockEmail(
                    w.getNguoiDung().getEmail(),
                    product
            );

            notificationService.create(

                    w.getNguoiDung(),

                    product,

                    "📦 Đã có hàng trở lại",

                    product.getName()
                            + " đã được nhập hàng trở lại.",

                    "BACK_IN_STOCK"

            );
            w.setBackInStockNotified(true);

            wishlistRepo.save(w);

        }catch(Exception ex){

            ex.printStackTrace();

        }

    }
}
}