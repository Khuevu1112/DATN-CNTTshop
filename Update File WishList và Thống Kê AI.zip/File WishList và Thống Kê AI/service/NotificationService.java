package com.fpoly.service;

import com.fpoly.model.*;
import com.fpoly.repository.NguoiDungRepository;
import com.fpoly.repository.NotificationRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepo;

    @Autowired
    private NguoiDungRepository nguoiDungRepo;

    public List<Notification> findUnread(String email){

        NguoiDung user =
                nguoiDungRepo.findByEmail(email)
                        .orElseThrow();

        return notificationRepo
                .findByNguoiDungAndIsReadFalseOrderByCreatedAtDesc(user);

    }

    public long countUnread(String email){

        NguoiDung user =
                nguoiDungRepo.findByEmail(email)
                        .orElseThrow();

        return notificationRepo.countByNguoiDungAndIsReadFalse(user);
    }

    public void read(Integer id){

        Notification n =
                notificationRepo.findById(id)
                        .orElseThrow();

        n.setIsRead(true);

        notificationRepo.save(n);

    }

    public void create(
        NguoiDung nguoiDung,
        Product product,
        String title,
        String message,
        String type) {

    Notification n = new Notification();

    n.setNguoiDung(nguoiDung);
    n.setProduct(product);
    n.setTitle(title);
    n.setContent(message);
    n.setType(type);
    n.setIsRead(false);

    notificationRepo.save(n);
}
}