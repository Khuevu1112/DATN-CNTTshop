package com.fpoly.service;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.math.RoundingMode;

import org.springframework.stereotype.Service;

import com.fpoly.model.Order;
import com.fpoly.model.ProductVariant;
import com.fpoly.repository.OrderItemRepository;
import com.fpoly.repository.OrderRepository;
import com.fpoly.repository.ProductRepository;
import com.fpoly.repository.ProductVariantRepository;

@Service
public class AIStatisticService {
                
    private final NumberFormat vn =
        NumberFormat.getCurrencyInstance(new Locale("vi","VN"));
    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;
    private final OrderItemRepository orderItemRepository;
    private final ProductVariantRepository productVariantRepository;

    public AIStatisticService(OrderRepository orderRepository,
                              ProductRepository productRepository,
                              OrderItemRepository orderItemRepository,
                              ProductVariantRepository productVariantRepository) {

        this.orderRepository = orderRepository;
        this.productRepository = productRepository;
        this.orderItemRepository = orderItemRepository;
        this.productVariantRepository = productVariantRepository;
    }

    public List<String> analyze() {

        List<String> insights = new ArrayList<>();

        NumberFormat vn = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));

        List<Order> orders = orderRepository.findAll();

        BigDecimal revenueToday = BigDecimal.ZERO;
        BigDecimal revenueAll = BigDecimal.ZERO;

        LocalDate today = LocalDate.now();

        int delivered = 0;
        int cancelled = 0;

        // =============================
        // Phân tích doanh thu
        // =============================
        for (Order order : orders) {

            if ("cancelled".equalsIgnoreCase(order.getTrangThai())) {
                cancelled++;
                continue;
            }

            revenueAll = revenueAll.add(order.getTongTien());

            if (today.equals(order.getCreatedAt().toLocalDate())) {
                revenueToday = revenueToday.add(order.getTongTien());
            }

            if ("delivered".equalsIgnoreCase(order.getTrangThai())) {
                delivered++;
            }
        }

        insights.add("💰 Tổng doanh thu đạt " + vn.format(revenueAll));

        insights.add("📅 Doanh thu hôm nay đạt " + vn.format(revenueToday));

        insights.add("📦 Đã hoàn thành " + delivered + " đơn hàng.");

        insights.add("❌ Có " + cancelled + " đơn hàng đã bị hủy.");

        insights.add("🖥️ Hệ thống hiện có " + productRepository.count() + " sản phẩm.");

        // =============================
        // Tỷ lệ hoàn thành đơn
        // =============================

        int totalOrders = delivered + cancelled;

        if (totalOrders > 0) {

            BigDecimal rate = BigDecimal.valueOf(delivered * 100.0 / totalOrders)
                    .setScale(1, RoundingMode.HALF_UP);

            insights.add("✅ Tỷ lệ giao hàng thành công đạt "
                    + rate + "%.");

        }
        
        // =============================
        // Top sản phẩm bán chạy
        // =============================
        List<Object[]> topProducts = orderItemRepository.getTopSellingProducts();

        if (!topProducts.isEmpty()) {

            Object[] top = topProducts.get(0);

            String productName = top[0].toString();

            Long quantity = ((Number) top[1]).longValue();

            insights.add("🔥 Sản phẩm bán chạy nhất là " + productName +
                    " (" + quantity + " sản phẩm).");
        }
        
        if (topProducts.size() >= 3) {

            insights.add("🏆 Top 3 sản phẩm bán chạy:");

            for (int i = 0; i < 3; i++) {

                Object[] row = topProducts.get(i);

                insights.add(
                        "   " + (i + 1) + ". "
                                + row[0]
                                + " (" + row[1] + " sản phẩm)");

            }

        }

        // =============================
        // Tồn kho thấp
        // =============================

        List<ProductVariant> lowStocks =
                productVariantRepository.findByStockLessThanEqual(5);

        if (lowStocks.isEmpty()) {

            insights.add("✅ Không có sản phẩm nào sắp hết hàng.");

        } else {

            insights.add("📦 Có " + lowStocks.size() + " sản phẩm sắp hết hàng.");

            for (ProductVariant pv : lowStocks) {

                if (pv.getStock() == 0) {

                    insights.add("❌ "
                            + pv.getProduct().getName()
                            + " đã hết hàng.");

                } else if (pv.getStock() <= 2) {

                    insights.add("🚨 "
                            + pv.getProduct().getName()
                            + " chỉ còn "
                            + pv.getStock()
                            + " sản phẩm.");

                } else {

                    insights.add("⚠ "
                            + pv.getProduct().getName()
                            + " còn "
                            + pv.getStock()
                            + " sản phẩm.");

                }

            }

        }

        // =============================
        // Đánh giá doanh thu
        // =============================
        if (revenueToday.compareTo(BigDecimal.valueOf(50_000_000)) >= 0) {

            insights.add("📈 Doanh thu hôm nay rất tốt.");

        } else if (revenueToday.compareTo(BigDecimal.valueOf(20_000_000)) >= 0) {

            insights.add("📊 Doanh thu hôm nay ở mức ổn định.");

        } else {

            insights.add("📉 Doanh thu hôm nay còn thấp, nên cân nhắc triển khai khuyến mãi.");

        }
        
        // =============================
        // Đánh giá đơn hàng
        // =============================
        if (cancelled > delivered / 2) {

            insights.add("⚠ Tỷ lệ hủy đơn khá cao, nên kiểm tra lại quy trình bán hàng.");

        }

        
        if (!orders.isEmpty()) {

            BigDecimal avgRevenue =
                    revenueAll.divide(
                            BigDecimal.valueOf(orders.size()),
                            0,
                            RoundingMode.HALF_UP);

            insights.add("💳 Giá trị trung bình mỗi đơn là "
                    + vn.format(avgRevenue));

        }
        
        // =============================
        // AI Recommendation
        // =============================

        // Khuyến nghị doanh thu
        if (revenueToday.compareTo(BigDecimal.valueOf(10_000_000)) < 0) {

            insights.add("💡 AI khuyến nghị triển khai Flash Sale hoặc mã giảm giá để kích cầu.");

        } else if (revenueToday.compareTo(BigDecimal.valueOf(30_000_000)) >= 0) {

            insights.add("💡 AI khuyến nghị tiếp tục duy trì các chương trình bán hàng hiện tại.");

        }

        // Khuyến nghị tồn kho
        if (!lowStocks.isEmpty()) {

            insights.add("💡 AI khuyến nghị nhập thêm hàng cho "
                    + lowStocks.size()
                    + " sản phẩm sắp hết kho.");

        }

        // Chất lượng đơn hàng
        if (cancelled == 0) {

            insights.add("🎉 AI đánh giá quy trình bán hàng hôm nay rất tốt, không có đơn bị hủy.");

        } else if (cancelled >= 5) {

            insights.add("⚠ AI phát hiện số lượng đơn hủy khá cao, nên kiểm tra lại vận chuyển hoặc chăm sóc khách hàng.");

        }


        // =============================
        // AI Forecast
        // =============================

        // Dự báo tồn kho
        if (lowStocks.size() >= 5) {

            insights.add("📦 AI dự đoán trong 3-5 ngày tới sẽ thiếu hàng ở nhiều sản phẩm nếu không nhập thêm.");

        } else if (lowStocks.size() > 0) {

            insights.add("📦 AI dự đoán sẽ cần bổ sung hàng cho một số sản phẩm trong vài ngày tới.");

        }


        // Dự báo xu hướng bán hàng
        if (delivered >= 20) {

            insights.add("📈 AI dự đoán xu hướng bán hàng sẽ tiếp tục tăng.");

        } else if (delivered >= 10) {

            insights.add("📊 AI dự đoán doanh số sẽ giữ ổn định.");

        } else {

            insights.add("📉 AI dự đoán doanh số có xu hướng giảm nếu không triển khai chương trình khuyến mãi.");

        }


        // Dự báo doanh thu ngày mai
        BigDecimal forecastRevenue;

        if (revenueToday.compareTo(BigDecimal.ZERO) == 0) {

            forecastRevenue = BigDecimal.valueOf(5_000_000);

        } else if (delivered >= 20) {

            // tăng khoảng 15%
            forecastRevenue = revenueToday.multiply(BigDecimal.valueOf(1.15));

        } else if (delivered >= 10) {

            // tăng khoảng 5%
            forecastRevenue = revenueToday.multiply(BigDecimal.valueOf(1.05));

        } else {

            // giảm khoảng 5%
            forecastRevenue = revenueToday.multiply(BigDecimal.valueOf(0.95));

        }

        forecastRevenue = forecastRevenue.setScale(0, RoundingMode.HALF_UP);

        insights.add("🔮 AI dự đoán doanh thu ngày mai khoảng "
                + vn.format(forecastRevenue) + ".");


        // Đánh giá sức khỏe kinh doanh
        if (delivered >= 20 && cancelled == 0 && lowStocks.size() <= 2) {

            insights.add("🟢 AI đánh giá tình hình kinh doanh đang ở mức RẤT TỐT.");

        } else if (delivered >= 10) {

            insights.add("🟡 AI đánh giá tình hình kinh doanh ở mức ỔN ĐỊNH.");

        } else {

            insights.add("🔴 AI đánh giá hoạt động kinh doanh cần được cải thiện.");

        }

        return insights;
    }
    
    public String answer(String question){

        if(question == null || question.isBlank()){
            return "Vui lòng nhập câu hỏi.";
        }


        String q = question.toLowerCase();



        // Chào hỏi
        if(q.contains("hello")
                || q.contains("xin chào")
                || q.contains("chào"))
        {
            return """
            👋 Xin chào!

            Tôi là AI thống kê của CNTTShop.

            Tôi có thể hỗ trợ:

            - Doanh thu
            - Đơn hàng
            - Sản phẩm bán chạy
            - Tồn kho
            - Dự đoán doanh thu
            - Đánh giá kinh doanh
            """;
        }



        // Doanh thu hôm nay
        if(q.contains("doanh thu hôm nay")
                || q.contains("hôm nay bán")
                || q.contains("bán được bao nhiêu hôm nay"))
        {
            return getRevenueTodayAI();
        }



        // Tổng doanh thu
        if(q.contains("tổng doanh thu")
                || q.contains("doanh thu"))
        {
            return getRevenueAllAI();
        }



        // Đơn hàng hôm nay
        if(q.contains("đơn hôm nay")
                || q.contains("đơn hàng hôm nay")
                || q.contains("bao nhiêu đơn hôm nay"))
        {
            return getOrderTodayAI();
        }



        // Đơn hàng
        if(q.contains("đơn hàng")
                || q.contains("bao nhiêu đơn")
                || q.contains("thống kê đơn"))
        {
            return getOrderStatisticAI();
        }



        // Top sản phẩm
        if(q.contains("top")
                || q.contains("bán chạy")
                || q.contains("best seller")
                || q.contains("sản phẩm nổi bật"))
        {
            return getBestSellerAI();
        }



        // Tồn kho
        if(q.contains("tồn kho")
                || q.contains("hết hàng")
                || q.contains("sắp hết"))
        {
            return getStockAI();
        }



        // Khuyến nghị
        if(q.contains("khuyến nghị")
                || q.contains("gợi ý")
                || q.contains("nên làm gì"))
        {
            return getRecommendationAI();
        }



        // Dự đoán
        if(q.contains("dự đoán")
                || q.contains("xu hướng")
                || q.contains("ngày mai")
                || q.contains("tương lai"))
        {
            return getForecastAI();
        }



        // Đánh giá
        if(q.contains("đánh giá")
                || q.contains("tình hình")
                || q.contains("kinh doanh")
                || q.contains("sức khỏe"))
        {
            return getBusinessAI();
        }



        return """
        Tôi chưa tìm thấy thông tin phù hợp với câu hỏi này.
        Bạn có thể hỏi tôi các vấn đề sau:

        📊 DOANH THU:
        - Doanh thu hôm nay
        - Tổng doanh thu hiện tại
        - Hôm nay bán được bao nhiêu tiền?
        - Doanh thu có tốt không?

        📦 ĐƠN HÀNG:
        - Có bao nhiêu đơn hàng?
        - Thống kê đơn hàng
        - Đơn hàng hôm nay
        - Có bao nhiêu đơn hoàn thành?
        - Có bao nhiêu đơn bị hủy?

        🔥 SẢN PHẨM:
        - Sản phẩm bán chạy nhất
        - Top sản phẩm bán chạy
        - Sản phẩm nổi bật
        - Best seller hiện tại

        📦 KHO HÀNG:
        - Tồn kho
        - Sản phẩm sắp hết hàng
        - Sản phẩm nào cần nhập thêm?
        - Kiểm tra hàng tồn

        🔮 DỰ ĐOÁN:
        - Dự đoán doanh thu
        - Dự đoán doanh số
        - Xu hướng bán hàng
        - Doanh thu ngày mai

        📈 ĐÁNH GIÁ KINH DOANH:
        - Đánh giá kinh doanh
        - Tình hình kinh doanh
        - Sức khỏe cửa hàng
        - Hoạt động bán hàng có tốt không?

        💡 KHUYẾN NGHỊ:
        - AI khuyến nghị
        - Nên làm gì để tăng doanh thu?
        - Gợi ý cải thiện kinh doanh
        - Có nên nhập thêm hàng không?

        Bạn cũng có thể hỏi tự nhiên như:
        "Shop hôm nay thế nào?"
        "Sản phẩm nào đang bán tốt?"
        "Có cần nhập thêm hàng không?"
        """;

    }

    private String getRevenueTodayAI(){

        BigDecimal revenue = BigDecimal.ZERO;

        int orders = 0;

        LocalDate today = LocalDate.now();

        for(Order o : orderRepository.findAll()){

            if("cancelled".equalsIgnoreCase(o.getTrangThai()))
                continue;

            if(today.equals(
                o.getCreatedAt().toLocalDate()
            )){
                revenue =
                revenue.add(o.getTongTien());
                orders++;
            }
        }
        return """
        📅 Báo cáo hôm nay:

        💰 Doanh thu: %s

        📦 Số đơn hàng: %d đơn

        AI nhận xét:
        %s
        """
        .formatted(
            vn.format(revenue),
            orders,
            revenue.compareTo(
                BigDecimal.valueOf(20000000)
            )>=0
            ?
            "Doanh thu đang tốt."
            :
            "Doanh thu còn thấp, nên chạy khuyến mãi."
        );
    }
    private String getRevenueAllAI(){

    BigDecimal revenue = BigDecimal.ZERO;
    for(Order o : orderRepository.findAll()){

        if("cancelled".equalsIgnoreCase(o.getTrangThai()))
            continue;
        revenue = revenue.add(o.getTongTien());

    }
    return "💰 Tổng doanh thu hiện tại là "
            + vn.format(revenue);

    }
    private String getOrderStatisticAI(){
    int done = 0;
    int cancel = 0;
    for(Order o:orderRepository.findAll()){


        if("delivered"
        .equalsIgnoreCase(o.getTrangThai()))
            done++;


        if("cancelled"
        .equalsIgnoreCase(o.getTrangThai()))
            cancel++;

    }
    return """
    📦 Thống kê đơn hàng:

    ✅ Hoàn thành: %d đơn

    ❌ Đã hủy: %d đơn

    AI đánh giá:
    %s
    """
    .formatted(
        done,
        cancel,
        cancel > done/2
        ?
        "Tỷ lệ hủy cao, cần kiểm tra vận chuyển."
        :
        "Quy trình bán hàng ổn định."
    );
}
    private String getBestSellerAI(){
    List<Object[]> list =
            orderItemRepository.getTopSellingProducts();
    if(list.isEmpty()){
        return "Chưa có dữ liệu sản phẩm.";
    }
    Object[] top = list.get(0);
    return "🔥 Sản phẩm bán chạy nhất: "
            + top[0]
            + " (" 
            + top[1]
            + " sản phẩm)";
}
    private String getStockAI(){
    List<ProductVariant> list =
            productVariantRepository
            .findByStockLessThanEqual(5);
    if(list.isEmpty()){
        return "✅ Hiện không có sản phẩm sắp hết.";
    }
    StringBuilder sb =
            new StringBuilder();
    sb.append("📦 Sản phẩm sắp hết:\n");
    for(ProductVariant pv:list){
        sb.append("- ")
          .append(pv.getProduct().getName())
          .append(": ")
          .append(pv.getStock())
          .append(" sản phẩm\n");
    }
    return sb.toString();
}
    private String getForecastAI(){
    BigDecimal revenue =
            BigDecimal.ZERO;
    int delivered = 0;
    for(Order o:orderRepository.findAll()){
        if("delivered".equalsIgnoreCase(o.getTrangThai())){
            delivered++;
        }
        if(!"cancelled".equalsIgnoreCase(o.getTrangThai())){
            revenue =
            revenue.add(o.getTongTien());
        }
    }
    BigDecimal forecast;
    if(delivered > 20){
        forecast =
        revenue.multiply(
        BigDecimal.valueOf(1.15));
    }else{
        forecast =
        revenue.multiply(
        BigDecimal.valueOf(1.05));
    }
    return "🔮 AI dự đoán doanh thu tiếp theo khoảng "
            + vn.format(forecast);
}
    private String getBusinessAI(){
    int done = 0;
    int cancel = 0;
    for(Order o:orderRepository.findAll()){
        if("delivered"
        .equalsIgnoreCase(o.getTrangThai()))
            done++;
        if("cancelled"
        .equalsIgnoreCase(o.getTrangThai()))
            cancel++;
    }
    if(done >=20 && cancel==0){
        return """
        🟢 AI đánh giá:

        Kinh doanh rất tốt.
        Đơn hàng ổn định.
        Không có đơn hủy.
        """;
    }
    if(done>=10){
        return """
        🟡 AI đánh giá:
        Hoạt động kinh doanh ổn định.
        """;
    }
    return """
    🔴 AI đánh giá:
    Doanh số thấp.
    Nên chạy khuyến mãi hoặc quảng cáo.
    """;
}
    private String getOrderTodayAI(){

    int total = 0;
    int delivered = 0;
    int cancelled = 0;

    LocalDate today = LocalDate.now();


    for(Order o : orderRepository.findAll()){

        if(o.getCreatedAt() == null)
            continue;


        if(today.equals(o.getCreatedAt().toLocalDate())){

            total++;


            if("delivered".equalsIgnoreCase(o.getTrangThai())){
                delivered++;
            }


            if("cancelled".equalsIgnoreCase(o.getTrangThai())){
                cancelled++;
            }

        }
    }


    return """
    📅 Thống kê đơn hàng hôm nay:

    📦 Tổng số đơn: %d

    ✅ Đã hoàn thành: %d đơn

    ❌ Đã hủy: %d đơn

    AI đánh giá:
    %s
    """
    .formatted(
            total,
            delivered,
            cancelled,
            cancelled > delivered / 2
            ?
            "Tỷ lệ hủy đơn hôm nay khá cao, nên kiểm tra lại quy trình xử lý."
            :
            "Đơn hàng hôm nay đang hoạt động ổn định."
    );
}
    private String getRecommendationAI(){

    List<ProductVariant> lowStocks =
            productVariantRepository
            .findByStockLessThanEqual(5);


    if(!lowStocks.isEmpty()){

        return """
        💡 AI khuyến nghị:

        - Nên nhập thêm hàng cho các sản phẩm sắp hết.
        - Có thể chạy chương trình giảm giá để tăng doanh số.
        """;

    }


    return """
    💡 AI khuyến nghị:

    - Duy trì chiến lược bán hàng hiện tại.
    - Tập trung quảng bá các sản phẩm bán chạy.
    """;

}
}