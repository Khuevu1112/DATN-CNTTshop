package com.fpoly.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fpoly.model.Category;
import com.fpoly.model.Product;
import com.fpoly.model.ProductVariant;
import com.fpoly.model.Wishlist;
import com.fpoly.repository.ProductRepository;
import com.fpoly.repository.ProductVariantRepository;
import com.fpoly.repository.WishlistRepository;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProductService {

    @Autowired
    private WishlistRepository wishlistRepo;
    
    @Autowired
    private WishlistNotificationService wishlistNotificationService;
    
    @Autowired
    private ProductRepository productRepo;

    @Autowired
    private ProductVariantRepository variantRepo;

    public List<Product> findAll() {
        return productRepo.findAll();
    }

    public List<Product> findByCategory(Category category) {
        return productRepo.findByCategory(category);
    }

    public Product findById(Integer id) {
        return productRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy sản phẩm"));
    }

    public void saveProductWithPrice(
            Product product,
            BigDecimal price,
            BigDecimal originalPrice,
            Integer stock
    ) {
        if (product.getIsActive() == null) {
            product.setIsActive(true);
        }

        if (product.getCreatedAt() == null) {
            product.setCreatedAt(LocalDateTime.now());
        }

        Product savedProduct = productRepo.save(product);

        ProductVariant variant = new ProductVariant();
        variant.setProduct(savedProduct);
        variant.setSku("SKU-" + savedProduct.getId());
        variant.setPrice(price);
        variant.setOriginalPrice(originalPrice);
        variant.setStock(stock);
        variant.setIsDefault(true);

        variantRepo.save(variant);
    }

    public void delete(Integer id) {
        productRepo.deleteById(id);
    }
    
    @Transactional
    public void updateProduct(
        Product product,
        BigDecimal price,
        BigDecimal originalPrice,
        Integer stock) {

    Product db = productRepo.findById(product.getId())
            .orElseThrow();

    db.setName(product.getName());
    db.setSlug(product.getSlug());
    db.setDescription(product.getDescription());
    db.setCategory(product.getCategory());
    db.setIsActive(product.getIsActive());

    ProductVariant variant = db.getVariants().get(0);

    BigDecimal oldPrice = variant.getPrice();

    Integer oldStock = variant.getStock();
    variant.setPrice(price);
    variant.setOriginalPrice(originalPrice);
    variant.setStock(stock);

    // Nếu tăng giá lại thì cho phép gửi mail giảm giá lần sau
    if(price.compareTo(oldPrice) > 0){

        List<Wishlist> list =
                wishlistRepo.findByProduct(db);

        for(Wishlist w : list){

            w.setDiscountNotified(false);

            wishlistRepo.save(w);

        }

    }
    
    // Nếu nhập hàng trở lại (>5)
    // thì cho phép gửi cảnh báo lần sau
    if(stock > 5){

        List<Wishlist> list = wishlistRepo.findByProduct(db);

        for(Wishlist w : list){
            w.setLowStockNotified(false);
        }

        wishlistRepo.saveAll(list);

    }
    variantRepo.save(variant);
    productRepo.save(db);

    // Giảm giá
    if (price.compareTo(oldPrice) < 0) {

        wishlistNotificationService.notifyDiscount(
                db,
                oldPrice,
                price
        );

    }

    // Sắp hết hàng
    if(stock <= 5){

        wishlistNotificationService.notifyLowStock(
                db,
                stock);

    }

    // Đã nhập thêm hàng
    if(stock > 5){

        wishlistRepo.findByProduct(db)
                .forEach(w -> {
                    w.setLowStockNotified(false);
                    wishlistRepo.save(w);
                });

    }
    
    // Có hàng trở lại
    if(oldStock == 0 && stock > 0){

        wishlistNotificationService.notifyBackInStock(db);

    }
    
    if(stock == 0){

    List<Wishlist> list = wishlistRepo.findByProduct(db);

    for(Wishlist w : list){
        w.setBackInStockNotified(false);
    }

    wishlistRepo.saveAll(list);

}
}
}