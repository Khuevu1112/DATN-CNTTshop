package com.fpoly.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import com.fpoly.service.CustomUserDetailsService;

@Configuration
public class SecurityConfig {

    @Autowired
    private CustomUserDetailsService userDetailsService;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http)
            throws Exception {

        http

            // =====================================================
            // CSRF
            // =====================================================
            .csrf(csrf -> csrf.disable())


            // =====================================================
            // PHÂN QUYỀN
            // =====================================================
            .authorizeHttpRequests(auth -> auth

                // -------------------------------------------------
                // Các trang public
                // -------------------------------------------------
                .requestMatchers(
                    "/DustNovel/login",
                    "/DustNovel/register",
                    "/DustNovel/forgot-password",
                    "/DustNovel/verify-otp",
                    "/DustNovel/reset-password",

                    "/css/**",
                    "/js/**",
                    "/images/**",

                    // OAuth2
                    "/oauth2/**",
                    "/login/oauth2/**"
                )
                .permitAll()


                // -------------------------------------------------
                // QUẢN LÝ USER
                // Chỉ ADMIN
                // -------------------------------------------------
                .requestMatchers(
                    "/admin/users/**",
                    "/admin/backup/**"
                )
                .hasRole("ADMIN")


                // -------------------------------------------------
                // ĐỔI / TRẢ HÀNG
                // Chỉ ADMIN
                // -------------------------------------------------
                .requestMatchers(
                    "/admin/returns/**"
                )
                .hasRole("ADMIN")


                // -------------------------------------------------
                // QUẢN LÝ SẢN PHẨM / CATEGORY
                // ADMIN + STAFF
                // -------------------------------------------------
                .requestMatchers(
                    "/admin/products/**",
                    "/admin/categories/**"
                )
                .hasAnyRole(
                    "ADMIN",
                    "STAFF"
                )


                // -------------------------------------------------
                // ACCOUNT
                // ADMIN + STAFF + CUSTOMER
                // -------------------------------------------------
                .requestMatchers(
                    "/account/**"
                )
                .hasAnyRole(
                    "ADMIN",
                    "STAFF",
                    "CUSTOMER"
                )


                // -------------------------------------------------
                // Các URL còn lại
                // phải đăng nhập
                // -------------------------------------------------
                .anyRequest()
                .authenticated()
            )


            // =====================================================
            // USER DETAILS
            // =====================================================
            .userDetailsService(
                userDetailsService
            )


            // =====================================================
            // LOGIN THƯỜNG
            // =====================================================
            .formLogin(form -> form

                // Trang HTML login của bạn
                .loginPage(
                    "/DustNovel/login"
                )

                // Form trong login.html phải POST vào đây
                .loginProcessingUrl(
                    "/DustNovel/login"
                )

                // name của input username
                .usernameParameter(
                    "username"
                )

                // name của input password
                .passwordParameter(
                    "password"
                )

                // Đăng nhập thành công
                .defaultSuccessUrl(
                    "/",
                    true
                )

                // Đăng nhập thất bại
                .failureUrl(
                    "/DustNovel/login?error=true"
                )

                .permitAll()
            )


            // =====================================================
            // GOOGLE / FACEBOOK OAUTH2
            // =====================================================
            .oauth2Login(oauth -> oauth

                // OAuth2 cũng dùng chung trang login
                // của project
                .loginPage(
                    "/DustNovel/login"
                )

                // Thành công -> trang chủ
                .defaultSuccessUrl(
                    "/",
                    true
                )
            )


            // =====================================================
            // LOGOUT
            // =====================================================
            .logout(logout -> logout

                .logoutUrl(
                    "/logout"
                )

                .logoutSuccessUrl(
                    "/DustNovel/login?logout"
                )

                .permitAll()
            );

        return http.build();
    }
}