package com.fpoly.service;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

@Service
public class ExcelBackupService {

    private static final int EXCEL_MAX_ROWS = 1_048_576;
    private static final int MAX_COLUMNS = 16_384;
    private static final int FLUSH_ROWS = 100;

    private final JdbcTemplate jdbcTemplate;

    public ExcelBackupService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * Lấy danh sách toàn bộ bảng dữ liệu thật trong schema dbo.
     */
    public List<String> getTables() {
        return jdbcTemplate.execute((java.sql.Connection connection) -> {
            List<String> tables = new ArrayList<>();
            DatabaseMetaData meta = connection.getMetaData();
            try (ResultSet rs = meta.getTables(connection.getCatalog(), "dbo", "%", new String[]{"TABLE"})) {
                while (rs.next()) {
                    String name = rs.getString("TABLE_NAME");
                    if (name != null && !name.isBlank()) {
                        tables.add(name);
                    }
                }
            }
            tables.sort(String.CASE_INSENSITIVE_ORDER);
            return tables;
        });
    }

    /**
     * Backup các bảng được chọn thành một file Excel .xlsx.
     * Mỗi bảng là một sheet. Nếu một bảng vượt giới hạn dòng của Excel,
     * service tự động tách thành nhiều sheet.
     */
    public byte[] backup(List<String> requestedTables) throws IOException {
        List<String> availableTables = getTables();
        List<String> tables = normalizeRequestedTables(requestedTables, availableTables);

        if (tables.isEmpty()) {
            throw new IllegalArgumentException("Không có bảng nào được chọn để backup.");
        }

        try (SXSSFWorkbook workbook = new SXSSFWorkbook(FLUSH_ROWS);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {

            workbook.setCompressTempFiles(true);
            CreationHelper helper = workbook.getCreationHelper();
            CellStyle dateStyle = workbook.createCellStyle();
            dateStyle.setDataFormat(helper.createDataFormat().getFormat("yyyy-mm-dd hh:mm:ss"));

            for (String table : tables) {
                exportTable(workbook, table, dateStyle);
            }

            workbook.write(output);
            workbook.dispose();
            return output.toByteArray();
        }
    }

    private List<String> normalizeRequestedTables(List<String> requested, List<String> available) {
        if (requested == null || requested.isEmpty()) {
            return new ArrayList<>(available);
        }

        Set<String> lookup = new HashSet<>();
        for (String table : available) {
            lookup.add(table.toLowerCase(Locale.ROOT));
        }

        List<String> result = new ArrayList<>();
        Set<String> added = new HashSet<>();
        for (String item : requested) {
            if (item == null || item.isBlank()) continue;
            String clean = item.trim();
            String lower = clean.toLowerCase(Locale.ROOT);
            if (!lookup.contains(lower) || !added.add(lower)) {
                continue;
            }
            for (String actual : available) {
                if (actual.equalsIgnoreCase(clean)) {
                    result.add(actual);
                    break;
                }
            }
        }
        return result;
    }

    private void exportTable(Workbook workbook, String table, CellStyle dateStyle) {
        String sql = "SELECT * FROM [dbo].[" + escapeIdentifier(table) + "]";

        jdbcTemplate.query(sql, rs -> {
            ResultSetMetaData md = rs.getMetaData();
            int columnCount = Math.min(md.getColumnCount(), MAX_COLUMNS);

            int sheetPart = 1;
            int excelRowIndex = 0;
            Sheet sheet = createSheet(workbook, table, sheetPart);
            Row header = sheet.createRow(excelRowIndex++);
            writeHeader(header, md, columnCount);

            while (rs.next()) {
                if (excelRowIndex >= EXCEL_MAX_ROWS) {
                    sheetPart++;
                    sheet = createSheet(workbook, table, sheetPart);
                    excelRowIndex = 0;
                    header = sheet.createRow(excelRowIndex++);
                    writeHeader(header, md, columnCount);
                }

                Row row = sheet.createRow(excelRowIndex++);
                for (int c = 1; c <= columnCount; c++) {
                    Object value = rs.getObject(c);
                    Cell cell = row.createCell(c - 1);
                    writeValue(cell, value, dateStyle);
                }
            }
            return null;
        });
    }

    private Sheet createSheet(Workbook workbook, String table, int part) {
        String base = sanitizeSheetName(table);
        String suffix = part == 1 ? "" : "_" + part;
        String name = base;
        if ((base + suffix).length() > 31) {
            name = base.substring(0, Math.max(1, 31 - suffix.length())) + suffix;
        } else {
            name = base + suffix;
        }
        return workbook.createSheet(uniqueSheetName(workbook, name));
    }

    private String uniqueSheetName(Workbook workbook, String desired) {
        String name = desired;
        int i = 2;
        while (workbook.getSheet(name) != null) {
            String suffix = "_" + i++;
            int max = 31 - suffix.length();
            name = desired.substring(0, Math.min(desired.length(), max)) + suffix;
        }
        return name;
    }

    private String sanitizeSheetName(String name) {
        String cleaned = name.replaceAll("[\\\\/?*\\[\\]:]", "_");
        if (cleaned.isBlank()) cleaned = "DATA";
        return cleaned.substring(0, Math.min(cleaned.length(), 31));
    }

    private String escapeIdentifier(String value) {
        return value.replace("]", "]]" );
    }

    private void writeHeader(Row row, ResultSetMetaData md, int columnCount) throws SQLException {
        for (int c = 1; c <= columnCount; c++) {
            Cell cell = row.createCell(c - 1);
            cell.setCellValue(md.getColumnLabel(c));
        }
    }

    private void writeValue(Cell cell, Object value, CellStyle dateStyle) {
        if (value == null) {
            cell.setBlank();
            return;
        }

        if (value instanceof Number number) {
            if (number instanceof BigDecimal decimal) {
                cell.setCellValue(decimal.doubleValue());
            } else {
                cell.setCellValue(number.doubleValue());
            }
            return;
        }

        if (value instanceof java.util.Date date) {
            cell.setCellValue(date);
            cell.setCellStyle(dateStyle);
            return;
        }

        if (value instanceof LocalDate date) {
            cell.setCellValue(date.toString());
            return;
        }

        if (value instanceof LocalDateTime dateTime) {
            cell.setCellValue(dateTime.toString());
            return;
        }

        if (value instanceof byte[] bytes) {
            cell.setCellValue(Base64.getEncoder().encodeToString(bytes));
            return;
        }

        cell.setCellValue(String.valueOf(value));
    }
}
