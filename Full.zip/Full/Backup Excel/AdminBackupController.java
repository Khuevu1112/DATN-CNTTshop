package com.fpoly.controller.admin;

import com.fpoly.service.ExcelBackupService;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class AdminBackupController {

    private final ExcelBackupService backupService;

    public AdminBackupController(ExcelBackupService backupService) {
        this.backupService = backupService;
    }

    @GetMapping("/admin/backup")
    public String backupPage() {
        return "admin/backup";
    }

    @GetMapping("/admin/api/backup/tables")
    @ResponseBody
    public List<String> tables() {
        return backupService.getTables();
    }

    @PostMapping("/admin/api/backup/excel")
    public ResponseEntity<?> backupExcel(
            @RequestParam(required = false) List<String> tables) {
        try {
            byte[] data = backupService.backup(tables);
            String timestamp = LocalDateTime.now()
                    .format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
            String filename = "CNTTShop_Backup_" + timestamp + ".xlsx";

            ContentDisposition disposition = ContentDisposition.attachment()
                    .filename(filename)
                    .build();

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, disposition.toString())
                    .contentType(MediaType.parseMediaType(
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    .contentLength(data.length)
                    .body(data);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(error(e.getMessage()));
        } catch (IOException e) {
            return ResponseEntity.internalServerError().body(error("Không thể tạo file Excel: " + e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(error("Backup thất bại: " + e.getMessage()));
        }
    }

    private Map<String, Object> error(String message) {
        Map<String, Object> result = new HashMap<>();
        result.put("success", false);
        result.put("message", message);
        return result;
    }
}
