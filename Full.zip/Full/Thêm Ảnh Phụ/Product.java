package com.fpoly.model;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.*;

@Entity
@Table(name = "PRODUCT")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;

    private String slug;

    @Column(columnDefinition = "NVARCHAR(MAX)")
    private String description;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private Category category;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "created_at")
    private LocalDateTime createdAt;


    // =========================================================
    // ẢNH SẢN PHẨM
    // =========================================================

    @OneToMany(
            mappedBy = "product",
            fetch = FetchType.EAGER,
            cascade = CascadeType.ALL
    )
    @OrderBy("sortOrder ASC")
    private List<ProductImage> images;


    // =========================================================
    // THÔNG SỐ
    // =========================================================

    @OneToMany(
            mappedBy = "product",
            fetch = FetchType.LAZY
    )
    private List<ProductSpec> specs;


    // =========================================================
    // VARIANT
    // =========================================================

    @OneToMany(
            mappedBy = "product",
            fetch = FetchType.LAZY
    )
    private List<ProductVariant> variants;


    // =========================================================
    // OPTION
    // =========================================================

    @OneToMany(
            mappedBy = "product",
            fetch = FetchType.LAZY
    )
    private List<ProductOption> options;


    // =========================================================
    // GETTER / SETTER
    // =========================================================

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }


    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }


    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }


    public List<ProductImage> getImages() {
        return images;
    }

    public void setImages(List<ProductImage> images) {
        this.images = images;
    }


    public List<ProductSpec> getSpecs() {
        return specs;
    }

    public void setSpecs(List<ProductSpec> specs) {
        this.specs = specs;
    }


    public List<ProductVariant> getVariants() {
        return variants;
    }

    public void setVariants(List<ProductVariant> variants) {
        this.variants = variants;
    }


    public List<ProductOption> getOptions() {
        return options;
    }

    public void setOptions(List<ProductOption> options) {
        this.options = options;
    }
}