package com.fpoly.service;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class TTGShopService {

    // =========================================================
    // CONFIG
    // =========================================================

    private static final String TTG_DOMAIN =
            "https://ttgshop.vn";

    private static final int MAX_IMAGES = 4;

    /*
     * Timeout cho mỗi HTTP request.
     *
     * Trước đây: 20 giây.
     * Bây giờ: 8 giây để tránh bị giữ quá lâu.
     */
    private static final int TIMEOUT = 8000;

    private static final double MIN_MATCH_SCORE = 0.70;


    /*
     * Giới hạn số category được mở.
     */
    private static final int MAX_CATEGORY_EXPANSIONS = 3;


    /*
     * Mỗi category chỉ lấy tối đa 50 candidate.
     */
    private static final int MAX_CATEGORY_PRODUCTS = 50;


    /*
     * Giới hạn tổng candidate.
     */
    private static final int MAX_CANDIDATES = 150;


    /*
     * Những URL này thường là CATEGORY,
     * không phải sản phẩm chi tiết.
     */
    private static final Set<String> CATEGORY_PATHS =
            new HashSet<>(Arrays.asList(

                    "/",
                    "/pc",
                    "/cpu",
                    "/cpu-intel",
                    "/cpu-amd",
                    "/ram",
                    "/nguon",
                    "/mainboard-1",
                    "/mainboard-amd",
                    "/mainboard-cho-cpu-intel",
                    "/vga-card-man-hinh",
                    "/vga-nvidia",
                    "/vga-amd",
                    "/vga-nvidia-rtx-5000-series",
                    "/o-cung-ssd-hdd",
                    "/o-cung-hdd",
                    "/o-cung-ssd",
                    "/tan-nhiet",
                    "/quat-tan-nhiet",
                    "/tan-nhiet-khi",
                    "/tan-nhiet-nuoc-aio",
                    "/vo-case",
                    "/man-hinh-van-phong",
                    "/man-hinh-do-hoa",
                    "/man-hinh-gaming",
                    "/man-hinh-theo-hang",
                    "/man-hinh-asus",
                    "/man-hinh-msi",
                    "/man-hinh-lg",
                    "/man-hinh-dell",
                    "/man-hinh-samsung",
                    "/man-hinh-aoc",
                    "/laptop",
                    "/laptop-gaming",
                    "/laptop-asus",
                    "/laptop-dell",
                    "/laptop-hp",
                    "/laptop-msi",
                    "/laptop-acer",
                    "/laptop-lenovo",
                    "/gaming-gear",
                    "/ban-phim",
                    "/chuot",
                    "/tai-nghe-gaming",
                    "/ghe-gaming",
                    "/micro",
                    "/phu-kien",
                    "/onsale"
            ));


    /*
     * Những từ cho thấy URL là trang danh mục.
     */
    private static final String[] CATEGORY_KEYWORDS = {

            "cpu",
            "ram",
            "mainboard",
            "vga",
            "card-man-hinh",
            "man-hinh",
            "laptop",
            "gaming-gear",
            "ban-phim",
            "chuot",
            "tai-nghe",
            "ghe-gaming",
            "micro",
            "phu-kien",
            "nguon",
            "o-cung",
            "ssd",
            "hdd",
            "tan-nhiet",
            "quat-tan-nhiet",
            "vo-case",
            "pc"
    };


    // =========================================================
    // PUBLIC API
    // =========================================================

    public ProductMatch findProduct(
            String sqlName) {

        System.out.println();
        System.out.println(
                "=========================================="
        );

        System.out.println(
                "TTG ĐANG TÌM:"
        );

        System.out.println(
                sqlName
        );

        System.out.println(
                "=========================================="
        );


        // =====================================================
        // CHECK NAME
        // =====================================================

        if (sqlName == null
                || sqlName.isBlank()) {

            return ProductMatch.notMatched();
        }


        String cleanName =
                cleanText(sqlName);


        // =====================================================
        // BƯỚC 1 - DIRECT SEARCH
        // =====================================================

        List<String> queries =
                buildQueries(
                        cleanName
                );

        List<Candidate> candidates =
                new ArrayList<>();


        for (String query :
                queries) {

            /*
             * Nếu đã đủ candidate
             * thì không search thêm.
             */
            if (candidates.size()
                    >= MAX_CANDIDATES) {

                break;
            }


            String searchUrl =
                    buildTTGSearchUrl(
                            query
                    );


            System.out.println();
            System.out.println(
                    "TTG DIRECT SEARCH:"
            );

            System.out.println(
                    searchUrl
            );


            Document doc =
                    fetch(searchUrl);


            if (doc == null) {

                continue;
            }


            collectCandidates(
                    doc,
                    candidates,
                    cleanName
            );
        }


        // =====================================================
        // BƯỚC 2 - EXPAND CATEGORY
        // =====================================================

        List<Candidate> expanded =
                expandCategoryCandidates(
                        candidates,
                        cleanName
                );

        candidates.addAll(
                expanded
        );


        limitCandidates(
                candidates
        );


        // =====================================================
        // BƯỚC 3 - GOOGLE FALLBACK
        // =====================================================

        if (candidates.isEmpty()
                || !hasGoodCandidate(
                        candidates,
                        cleanName
                )) {

            List<Candidate> google =
                    searchGoogle(
                            cleanName
                    );

            candidates.addAll(
                    google
            );

            limitCandidates(
                    candidates
            );
        }


        // =====================================================
        // BƯỚC 4 - BING FALLBACK
        // =====================================================

        if (candidates.isEmpty()
                || !hasGoodCandidate(
                        candidates,
                        cleanName
                )) {

            List<Candidate> bing =
                    searchBing(
                            cleanName
                    );

            candidates.addAll(
                    bing
            );

            limitCandidates(
                    candidates
            );
        }


        // =====================================================
        // BƯỚC 5 - REMOVE DUPLICATE
        // =====================================================

        candidates =
                removeDuplicateCandidates(
                        candidates
                );


        // =====================================================
        // BƯỚC 6 - FIND BEST
        // =====================================================

        Candidate best =
                findBestCandidate(
                        candidates,
                        cleanName
                );


        if (best == null) {

            System.out.println();
            System.out.println(
                    "=========================================="
            );

            System.out.println(
                    "TTG KHÔNG XÁC NHẬN ĐƯỢC SẢN PHẨM"
            );

            System.out.println(
                    "=========================================="
            );

            return ProductMatch.notMatched();
        }


        // =====================================================
        // BƯỚC 7 - KHÔNG CHẤP NHẬN CATEGORY
        // =====================================================

        if (isCategoryUrl(
                best.url
        )) {

            System.out.println();
            System.out.println(
                    "BEST MATCH VẪN LÀ CATEGORY -> BỎ"
            );

            System.out.println(
                    best.url
            );

            return ProductMatch.notMatched();
        }


        // =====================================================
        // BƯỚC 8 - VERIFY DETAIL
        // =====================================================

        Candidate verified =
                verifyProductPage(
                        best,
                        cleanName
                );


        if (verified == null) {

            System.out.println();
            System.out.println(
                    "KHÔNG VERIFY ĐƯỢC TRANG CHI TIẾT"
            );

            return ProductMatch.notMatched();
        }


        // =====================================================
        // BƯỚC 9 - FINAL SCORE
        // =====================================================

        double score =
                calculateScore(
                        cleanName,
                        verified.name
                );


        // =====================================================
        // REQUIRED MODEL
        // =====================================================

        if (!requiredModelsMatch(
                cleanName,
                verified.name
        )) {

            System.out.println();
            System.out.println(
                    "THIẾU CPU/GPU MODEL -> BỎ"
            );

            return ProductMatch.notMatched();
        }


        // =====================================================
        // SCORE
        // =====================================================

        if (score < MIN_MATCH_SCORE) {

            System.out.println();
            System.out.println(
                    "SCORE QUÁ THẤP -> BỎ"
            );

            System.out.println(
                    "BEST SCORE: "
                            + score
            );

            return ProductMatch.notMatched();
        }


        // =====================================================
        // SUCCESS
        // =====================================================

        System.out.println();
        System.out.println(
                "=========================================="
        );

        System.out.println(
                "XÁC NHẬN ĐÚNG SẢN PHẨM"
        );

        System.out.println(
                "=========================================="
        );

        System.out.println(
                "SQL: "
                        + sqlName
        );

        System.out.println(
                "TTG: "
                        + verified.name
        );

        System.out.println(
                "SCORE: "
                        + score
        );

        System.out.println(
                "URL: "
                        + verified.url
        );

        System.out.println(
                "=========================================="
        );


        return new ProductMatch(
                true,
                verified.name,
                verified.url,
                score
        );
    }


    // =========================================================
    // LẤY ẢNH SẢN PHẨM
    // =========================================================

    public List<String> getProductImages(
            String productUrl) {

        List<String> result =
                new ArrayList<>();


        if (productUrl == null
                || productUrl.isBlank()) {

            return result;
        }


        /*
         * Tuyệt đối không lấy ảnh từ category.
         */
        if (isCategoryUrl(
                productUrl
        )) {

            System.out.println(
                    "URL LÀ CATEGORY -> KHÔNG LẤY ẢNH:"
            );

            System.out.println(
                    productUrl
            );

            return result;
        }


        System.out.println();
        System.out.println(
                "ĐANG LẤY ẢNH TỪ TRANG CHI TIẾT:"
        );

        System.out.println(
                productUrl
        );


        Document doc =
                fetch(productUrl);


        if (doc == null) {

            return result;
        }


        // =====================================================
        // ƯU TIÊN GALLERY
        // =====================================================

        Elements galleryImages =
                doc.select(
                        ".product-gallery img, "
                                + ".product-detail img, "
                                + ".product-images img, "
                                + ".gallery img, "
                                + ".swiper-slide img, "
                                + ".product__media img"
                );


        for (Element img :
                galleryImages) {

            addImage(
                    result,
                    img
            );


            if (result.size()
                    >= MAX_IMAGES) {

                break;
            }
        }


        // =====================================================
        // FALLBACK TOÀN BỘ IMG
        // =====================================================

        if (result.size()
                < MAX_IMAGES) {

            Elements images =
                    doc.select("img");


            for (Element img :
                    images) {

                addImage(
                        result,
                        img
                );


                if (result.size()
                        >= MAX_IMAGES) {

                    break;
                }
            }
        }


        // =====================================================
        // CLEAN
        // =====================================================

        result =
                cleanImageList(
                        result
                );


        System.out.println();
        System.out.println(
                "ẢNH TTG HỢP LỆ: "
                        + result.size()
        );


        for (int i = 0;
             i < result.size();
             i++) {

            System.out.println(
                    (i + 1)
                            + ". "
                            + result.get(i)
            );
        }


        return result;
    }


    // =========================================================
    // BUILD QUERY
    // =========================================================

    private List<String> buildQueries(
            String name) {

        List<String> queries =
                new ArrayList<>();


        addUnique(
                queries,
                name
        );


        String normalized =
                normalizeForSearch(
                        name
                );


        addUnique(
                queries,
                normalized
        );


        String cpu =
                extractCpuModel(
                        name
                );


        String gpu =
                extractGpuModel(
                        name
                );


        if (!cpu.isBlank()
                && !gpu.isBlank()) {

            addUnique(
                    queries,
                    cpu + " " + gpu
            );
        }


        if (queries.size() < 4
                && !cpu.isBlank()) {

            addUnique(
                    queries,
                    cpu
            );
        }


        if (queries.size() < 4
                && !gpu.isBlank()) {

            addUnique(
                    queries,
                    gpu
            );
        }


        /*
         * Không quá 4 query.
         */
        if (queries.size() > 4) {

            return new ArrayList<>(
                    queries.subList(
                            0,
                            4
                    )
            );
        }


        return queries;
    }


    // =========================================================
    // TTG SEARCH URL
    // =========================================================

    private String buildTTGSearchUrl(
            String query) {

        return TTG_DOMAIN
                + "/tim?q="
                + URLEncoder.encode(
                        query,
                        StandardCharsets.UTF_8
                );
    }


    // =========================================================
    // COLLECT CANDIDATES
    // =========================================================

    private void collectCandidates(
            Document doc,
            List<Candidate> candidates,
            String sqlName) {

        if (doc == null) {
            return;
        }


        if (candidates.size()
                >= MAX_CANDIDATES) {

            return;
        }


        Elements links =
                doc.select("a[href]");


        for (Element link :
                links) {

            if (candidates.size()
                    >= MAX_CANDIDATES) {

                break;
            }


            String href =
                    link.attr("abs:href");


            String text =
                    cleanText(
                            link.text()
                    );


            if (href == null
                    || href.isBlank()) {

                continue;
            }


            if (!isTTGUrl(
                    href
            )) {

                continue;
            }


            if (isBlockedUrl(
                    href
            )) {

                continue;
            }


            String title =
                    text;


            if (title.isBlank()) {

                title =
                        link.attr("title");
            }


            if (title.isBlank()) {

                continue;
            }


            double score =
                    calculateScore(
                            sqlName,
                            title
                    );


            /*
             * Chỉ lấy candidate có một chút
             * khả năng match.
             */
            if (score < 0.20) {

                continue;
            }


            candidates.add(
                    new Candidate(
                            title,
                            href,
                            score
                    )
            );
        }
    }


    // =========================================================
    // EXPAND CATEGORY
    // =========================================================

    private List<Candidate> expandCategoryCandidates(
            List<Candidate> candidates,
            String sqlName) {

        List<Candidate> result =
                new ArrayList<>();


        Set<String> visited =
                new HashSet<>();


        int categoryCount =
                0;


        for (Candidate candidate :
                candidates) {

            if (categoryCount
                    >= MAX_CATEGORY_EXPANSIONS) {

                break;
            }


            if (candidate == null) {
                continue;
            }


            if (!isCategoryUrl(
                    candidate.url
            )) {

                continue;
            }


            String normalized =
                    normalizeUrl(
                            candidate.url
                    );


            if (!visited.add(
                    normalized
            )) {

                continue;
            }


            categoryCount++;


            System.out.println();
            System.out.println(
                    "MỞ CATEGORY "
                            + categoryCount
                            + "/"
                            + MAX_CATEGORY_EXPANSIONS
            );


            System.out.println(
                    candidate.url
            );


            Document doc =
                    fetch(
                            candidate.url
                    );


            if (doc == null) {

                continue;
            }


            Elements links =
                    doc.select("a[href]");


            int productCount =
                    0;


            for (Element link :
                    links) {

                if (productCount
                        >= MAX_CATEGORY_PRODUCTS) {

                    break;
                }


                String href =
                        link.attr(
                                "abs:href"
                        );


                if (!isTTGUrl(
                        href
                )) {

                    continue;
                }


                if (isCategoryUrl(
                        href
                )) {

                    continue;
                }


                if (isBlockedUrl(
                        href
                )) {

                    continue;
                }


                String text =
                        cleanText(
                                link.text()
                        );


                String title =
                        cleanText(
                                link.attr(
                                        "title"
                                )
                        );


                if (text.isBlank()) {

                    text =
                            title;
                }


                if (text.isBlank()) {

                    continue;
                }


                double score =
                        calculateScore(
                                sqlName,
                                text
                        );


                if (score < 0.25) {

                    continue;
                }


                result.add(
                        new Candidate(
                                text,
                                href,
                                score
                        )
                );


                productCount++;
            }


            System.out.println(
                    "CATEGORY TÌM ĐƯỢC: "
                            + productCount
                            + " CANDIDATE"
            );
        }


        return result;
    }


    // =========================================================
    // GOOGLE
    // =========================================================

    private List<Candidate> searchGoogle(
            String name) {

        List<Candidate> result =
                new ArrayList<>();


        String query =
                "site:ttgshop.vn "
                        + name;


        String url =
                "https://www.google.com/search?q="
                        + URLEncoder.encode(
                                query,
                                StandardCharsets.UTF_8
                        )
                        + "&num=10";


        System.out.println();
        System.out.println(
                "TTG GOOGLE SEARCH:"
        );


        System.out.println(
                url
        );


        Document doc =
                fetch(
                        url,
                        "https://www.google.com/"
                );


        if (doc == null) {

            return result;
        }


        Elements links =
                doc.select("a[href]");


        for (Element link :
                links) {

            if (result.size() >= 30) {

                break;
            }


            String href =
                    extractGoogleUrl(
                            link.attr("href")
                    );


            if (!isTTGUrl(
                    href
            )) {

                continue;
            }


            if (isCategoryUrl(
                    href
            )) {

                continue;
            }


            String text =
                    cleanText(
                            link.text()
                    );


            if (text.isBlank()) {

                continue;
            }


            double score =
                    calculateScore(
                            name,
                            text
                    );


            if (score < 0.20) {

                continue;
            }


            result.add(
                    new Candidate(
                            text,
                            href,
                            score
                    )
            );
        }


        return result;
    }


    // =========================================================
    // BING
    // =========================================================

    private List<Candidate> searchBing(
            String name) {

        List<Candidate> result =
                new ArrayList<>();


        String query =
                "site:ttgshop.vn "
                        + name;


        String url =
                "https://www.bing.com/search?q="
                        + URLEncoder.encode(
                                query,
                                StandardCharsets.UTF_8
                        );


        System.out.println();
        System.out.println(
                "TTG BING SEARCH:"
        );


        System.out.println(
                url
        );


        Document doc =
                fetch(
                        url,
                        "https://www.bing.com/"
                );


        if (doc == null) {

            return result;
        }


        Elements links =
                doc.select(
                        "li.b_algo h2 a"
                );


        for (Element link :
                links) {

            if (result.size() >= 30) {

                break;
            }


            String href =
                    link.attr("href");


            if (!isTTGUrl(
                    href
            )) {

                continue;
            }


            if (isCategoryUrl(
                    href
            )) {

                continue;
            }


            String text =
                    cleanText(
                            link.text()
                    );


            if (text.isBlank()) {

                continue;
            }


            double score =
                    calculateScore(
                            name,
                            text
                    );


            if (score < 0.20) {

                continue;
            }


            result.add(
                    new Candidate(
                            text,
                            href,
                            score
                    )
            );
        }


        return result;
    }


    // =========================================================
    // VERIFY PRODUCT PAGE
    // =========================================================

    private Candidate verifyProductPage(
            Candidate candidate,
            String sqlName) {

        if (candidate == null) {

            return null;
        }


        if (isCategoryUrl(
                candidate.url
        )) {

            return null;
        }


        System.out.println();
        System.out.println(
                "VERIFY PRODUCT:"
        );


        System.out.println(
                candidate.url
        );


        Document doc =
                fetch(
                        candidate.url
                );


        if (doc == null) {

            return null;
        }


        String title =
                extractProductTitle(
                        doc
                );


        if (title.isBlank()) {

            title =
                    candidate.name;
        }


        String body =
                cleanText(
                        doc.body().text()
                );


        String combined =
                title
                        + " "
                        + body;


        /*
         * Kiểm tra CPU/GPU model.
         */
        if (!requiredModelsMatch(
                sqlName,
                combined
        )) {

            System.out.println(
                    "VERIFY FAIL: THIẾU MODEL"
            );

            return null;
        }


        double score =
                calculateScore(
                        sqlName,
                        title
                );


        /*
         * Nếu title chưa đủ,
         * dùng body.
         */
        if (score < 0.70) {

            score =
                    calculateScore(
                            sqlName,
                            combined
                    );
        }


        return new Candidate(
                title,
                candidate.url,
                score
        );
    }


    // =========================================================
    // EXTRACT PRODUCT TITLE
    // =========================================================

    private String extractProductTitle(
            Document doc) {

        String[] selectors = {

                "h1",
                ".product-title",
                ".product_name",
                ".product-detail h1",
                "meta[property=og:title]",
                "title"

        };


        for (String selector :
                selectors) {

            Element element =
                    doc.selectFirst(
                            selector
                    );


            if (element == null) {

                continue;
            }


            String value;


            if (element.tagName()
                    .equalsIgnoreCase(
                            "meta"
                    )) {

                value =
                        element.attr(
                                "content"
                        );

            } else {

                value =
                        element.text();
            }


            value =
                    cleanText(
                            value
                    );


            if (!value.isBlank()) {

                return value;
            }
        }


        return "";
    }


    // =========================================================
    // SCORE
    // =========================================================

    private double calculateScore(
            String sql,
            String ttg) {

        if (sql == null
                || ttg == null) {

            return 0.0;
        }


        String a =
                normalizeForCompare(
                        sql
                );


        String b =
                normalizeForCompare(
                        ttg
                );


        if (a.isBlank()
                || b.isBlank()) {

            return 0.0;
        }


        /*
         * Exact.
         */
        if (a.equals(b)) {

            return 1.0;
        }


        Set<String> aTokens =
                tokenize(a);


        Set<String> bTokens =
                tokenize(b);


        if (aTokens.isEmpty()
                || bTokens.isEmpty()) {

            return 0.0;
        }


        int matched =
                0;


        for (String token :
                aTokens) {

            if (bTokens.contains(
                    token
            )) {

                matched++;
            }
        }


        double tokenScore =
                (double) matched
                        / aTokens.size();


        /*
         * Model bonus.
         */
        double modelBonus =
                0.0;


        String cpu =
                extractCpuModel(
                        sql
                );


        String gpu =
                extractGpuModel(
                        sql
                );


        if (!cpu.isBlank()
                && containsModel(
                        b,
                        cpu
                )) {

            modelBonus += 0.25;
        }


        if (!gpu.isBlank()
                && containsModel(
                        b,
                        gpu
                )) {

            modelBonus += 0.25;
        }


        return Math.min(
                1.0,
                tokenScore
                        + modelBonus
        );
    }


    // =========================================================
    // REQUIRED MODEL CHECK
    // =========================================================

    private boolean requiredModelsMatch(
            String sql,
            String ttg) {

        String cpu =
                extractCpuModel(
                        sql
                );


        String gpu =
                extractGpuModel(
                        sql
                );


        String normalized =
                normalizeForCompare(
                        ttg
                );


        /*
         * CPU.
         */
        if (!cpu.isBlank()) {

            if (!containsModel(
                    normalized,
                    cpu
            )) {

                System.out.println(
                        "Thiếu CPU: "
                                + cpu
                );

                return false;
            }
        }


        /*
         * GPU.
         */
        if (!gpu.isBlank()) {

            if (!containsModel(
                    normalized,
                    gpu
            )) {

                System.out.println(
                        "Thiếu GPU: "
                                + gpu
                );

                return false;
            }
        }


        return true;
    }


    // =========================================================
    // CPU MODEL
    // =========================================================

    private String extractCpuModel(
            String text) {

        if (text == null) {

            return "";
        }


        String upper =
                text.toUpperCase();


        /*
         * Ryzen 7 9800X3D
         */
        Pattern ryzen =
                Pattern.compile(
                        "RYZEN\\s+[3579]\\s+([0-9]{4,5}[A-Z0-9]*)",
                        Pattern.CASE_INSENSITIVE
                );


        Matcher m =
                ryzen.matcher(
                        upper
                );


        if (m.find()) {

            return m.group(1)
                    .toLowerCase();
        }


        /*
         * Core Ultra 7 270K
         */
        Pattern core =
                Pattern.compile(
                        "(?:CORE\\s+)?ULTRA\\s+[3579]\\s+([0-9]{3,5}[A-Z0-9]*)",
                        Pattern.CASE_INSENSITIVE
                );


        m =
                core.matcher(
                        upper
                );


        if (m.find()) {

            return m.group(1)
                    .toLowerCase();
        }


        /*
         * Intel i7-14700K
         */
        Pattern intel =
                Pattern.compile(
                        "I[3579][\\s-]*([0-9]{4,5}[A-Z0-9]*)",
                        Pattern.CASE_INSENSITIVE
                );


        m =
                intel.matcher(
                        upper
                );


        if (m.find()) {

            return m.group(1)
                    .toLowerCase();
        }


        return "";
    }


    // =========================================================
    // GPU MODEL
    // =========================================================

    private String extractGpuModel(
            String text) {

        if (text == null) {

            return "";
        }


        String upper =
                text.toUpperCase();


        /*
         * RTX 5080
         * RTX 5070 Ti
         * RTX 5060 Ti
         */
        Pattern rtx =
                Pattern.compile(
                        "RTX\\s+([0-9]{4})(?:\\s*TI)?",
                        Pattern.CASE_INSENSITIVE
                );


        Matcher m =
                rtx.matcher(
                        upper
                );


        if (m.find()) {

            String full =
                    m.group(0)
                            .replaceAll(
                                    "\\s+",
                                    " "
                            )
                            .trim();


            return full.toLowerCase();
        }


        /*
         * RX 7900 XTX
         */
        Pattern rx =
                Pattern.compile(
                        "RX\\s+([0-9]{4,5})(?:\\s*[A-Z]+)?",
                        Pattern.CASE_INSENSITIVE
                );


        m =
                rx.matcher(
                        upper
                );


        if (m.find()) {

            return m.group(0)
                    .replaceAll(
                            "\\s+",
                            " "
                    )
                    .trim()
                    .toLowerCase();
        }


        return "";
    }


    // =========================================================
    // MODEL CONTAINS
    // =========================================================

    private boolean containsModel(
            String text,
            String model) {

        if (text == null
                || model == null
                || model.isBlank()) {

            return false;
        }


        String a =
                normalizeForCompare(
                        text
                );


        String b =
                normalizeForCompare(
                        model
                );


        /*
         * Ví dụ:
         * 9800x3d
         */
        if (a.contains(b)) {

            return true;
        }


        /*
         * RTX 5080 / RTX5080
         */
        String compactA =
                a.replaceAll(
                        "[^a-z0-9]",
                        ""
                );


        String compactB =
                b.replaceAll(
                        "[^a-z0-9]",
                        ""
                );


        return compactA.contains(
                compactB
        );
    }


    // =========================================================
    // BEST CANDIDATE
    // =========================================================

    private Candidate findBestCandidate(
            List<Candidate> candidates,
            String sqlName) {

        Candidate best =
                null;


        double bestScore =
                0.0;


        for (Candidate candidate :
                candidates) {

            if (candidate == null) {

                continue;
            }


            if (isBlockedUrl(
                    candidate.url
            )) {

                continue;
            }


            if (isCategoryUrl(
                    candidate.url
            )) {

                continue;
            }


            double score =
                    calculateScore(
                            sqlName,
                            candidate.name
                    );


            /*
             * Kiểm tra model.
             */
            if (!requiredModelsMatch(
                    sqlName,
                    candidate.name
            )) {

                continue;
            }


            if (score > bestScore) {

                bestScore =
                        score;


                best =
                        new Candidate(
                                candidate.name,
                                candidate.url,
                                score
                        );
            }
        }


        return best;
    }


    // =========================================================
    // GOOD CANDIDATE
    // =========================================================

    private boolean hasGoodCandidate(
            List<Candidate> candidates,
            String sqlName) {

        for (Candidate candidate :
                candidates) {

            if (candidate == null) {

                continue;
            }


            if (isCategoryUrl(
                    candidate.url
            )) {

                continue;
            }


            if (!requiredModelsMatch(
                    sqlName,
                    candidate.name
            )) {

                continue;
            }


            double score =
                    calculateScore(
                            sqlName,
                            candidate.name
                    );


            if (score >= 0.70) {

                return true;
            }
        }


        return false;
    }


    // =========================================================
    // LIMIT CANDIDATES
    // =========================================================

    private void limitCandidates(
            List<Candidate> candidates) {

        if (candidates == null) {

            return;
        }


        if (candidates.size()
                <= MAX_CANDIDATES) {

            return;
        }


        /*
         * Giữ những candidate đầu tiên.
         */
        while (candidates.size()
                > MAX_CANDIDATES) {

            candidates.remove(
                    candidates.size() - 1
            );
        }
    }


    // =========================================================
    // URL CHECK
    // =========================================================

    private boolean isTTGUrl(
            String url) {

        if (url == null
                || url.isBlank()) {

            return false;
        }


        try {

            URI uri =
                    URI.create(url);


            String host =
                    uri.getHost();


            return host != null
                    && (
                    host.equalsIgnoreCase(
                            "ttgshop.vn"
                    )
                    || host.equalsIgnoreCase(
                            "www.ttgshop.vn"
                    )
            );


        } catch (Exception e) {

            return false;
        }
    }


    // =========================================================
    // CATEGORY URL
    // =========================================================

    private boolean isCategoryUrl(
            String url) {

        if (!isTTGUrl(url)) {

            return true;
        }


        try {

            URI uri =
                    URI.create(url);


            String path =
                    uri.getPath();


            if (path == null
                    || path.isBlank()) {

                return true;
            }


            path =
                    path.toLowerCase()
                            .replaceAll(
                                    "/+$",
                                    ""
                            );


            /*
             * Category chính xác.
             */
            if (CATEGORY_PATHS.contains(
                    path
            )) {

                return true;
            }


            /*
             * CDN/system.
             */
            if (path.startsWith(
                    "/cdn-cgi/"
            )) {

                return true;
            }


            /*
             * Search.
             */
            if (path.startsWith(
                    "/tim"
            )) {

                return true;
            }


            /*
             * Category keyword.
             */
            for (String keyword :
                    CATEGORY_KEYWORDS) {

                if (path.equals(
                        "/" + keyword
                )) {

                    return true;
                }
            }


            return false;


        } catch (Exception e) {

            return true;
        }
    }


    // =========================================================
    // BLOCK URL
    // =========================================================

    private boolean isBlockedUrl(
            String url) {

        if (url == null
                || url.isBlank()) {

            return true;
        }


        String lower =
                url.toLowerCase();


        if (lower.contains(
                "cdn-cgi"
        )) {

            return true;
        }


        if (lower.contains(
                "email-protection"
        )) {

            return true;
        }


        if (lower.contains(
                "/tim?"
        )) {

            return true;
        }


        if (lower.contains(
                "/search"
        )) {

            return true;
        }


        return false;
    }


    // =========================================================
    // FETCH
    // =========================================================

    private Document fetch(
            String url) {

        return fetch(
                url,
                TTG_DOMAIN
        );
    }


    private Document fetch(
            String url,
            String referer) {

        if (url == null
                || url.isBlank()) {

            return null;
        }


        try {

            return Jsoup.connect(
                            url
                    )

                    .userAgent(
                            "Mozilla/5.0 "
                                    + "(Windows NT 10.0; Win64; x64) "
                                    + "AppleWebKit/537.36 "
                                    + "(KHTML, like Gecko) "
                                    + "Chrome/128.0 Safari/537.36"
                    )

                    .referrer(
                            referer
                    )

                    .timeout(
                            TIMEOUT
                    )

                    .followRedirects(
                            true
                    )

                    .ignoreHttpErrors(
                            true
                    )

                    .ignoreContentType(
                            true
                    )

                    .get();


        } catch (Exception e) {

            System.out.println();
            System.out.println(
                    "LỖI FETCH:"
            );

            System.out.println(
                    url
            );

            System.out.println(
                    e.getClass()
                            .getSimpleName()
            );

            System.out.println(
                    e.getMessage()
            );

            return null;
        }
    }


    // =========================================================
    // IMAGE
    // =========================================================

    private void addImage(
            List<String> result,
            Element img) {

        if (img == null) {

            return;
        }


        String[] attributes = {

                "src",
                "data-src",
                "data-original",
                "data-lazy-src",
                "data-image",
                "data-fancybox"

        };


        for (String attr :
                attributes) {

            String url =
                    img.attr(
                            attr
                    );


            if (url == null
                    || url.isBlank()) {

                continue;
            }


            /*
             * Protocol relative.
             */
            if (url.startsWith(
                    "//"
            )) {

                url =
                        "https:"
                                + url;
            }


            /*
             * Relative URL.
             */
            if (url.startsWith(
                    "/"
            )) {

                url =
                        TTG_DOMAIN
                                + url;
            }


            if (!url.startsWith(
                    "http"
            )) {

                continue;
            }


            if (isValidProductImage(
                    url
            )) {

                if (!containsNormalizedUrl(
                        result,
                        url
                )) {

                    result.add(
                            url
                    );
                }


                return;
            }
        }
    }


    // =========================================================
    // VALID PRODUCT IMAGE
    // =========================================================

    private boolean isValidProductImage(
            String url) {

        if (url == null
                || url.isBlank()) {

            return false;
        }


        String lower =
                url.toLowerCase();


        /*
         * Facebook.
         */
        if (lower.contains(
                "facebook"
        )) {

            return false;
        }


        if (lower.contains(
                "fbcdn.net"
        )) {

            return false;
        }


        /*
         * Emoji.
         */
        if (lower.contains(
                "emoji"
        )) {

            return false;
        }


        /*
         * Icon.
         */
        if (lower.contains(
                "icon"
        )) {

            return false;
        }


        /*
         * Logo.
         */
        if (lower.contains(
                "logo"
        )) {

            return false;
        }


        /*
         * Banner.
         */
        if (lower.contains(
                "banner"
        )) {

            return false;
        }


        /*
         * Favicon.
         */
        if (lower.contains(
                "favicon"
        )) {

            return false;
        }


        /*
         * TTG product image.
         */
        if (lower.contains(
                "ttgshop.vn/media/product/"
        )) {

            return true;
        }


        /*
         * Không lấy domain ngoài TTG.
         */
        if (!lower.contains(
                "ttgshop.vn"
        )) {

            return false;
        }


        return lower.endsWith(
                ".jpg"
        )
                || lower.endsWith(
                ".jpeg"
        )
                || lower.endsWith(
                ".png"
        )
                || lower.endsWith(
                ".webp"
        );
    }


    // =========================================================
    // CLEAN IMAGE LIST
    // =========================================================

    private List<String> cleanImageList(
            List<String> images) {

        List<String> result =
                new ArrayList<>();


        if (images == null) {

            return result;
        }


        for (String url :
                images) {

            if (!isValidProductImage(
                    url
            )) {

                continue;
            }


            if (!containsNormalizedUrl(
                    result,
                    url
            )) {

                result.add(
                        url
                );
            }


            if (result.size()
                    >= MAX_IMAGES) {

                break;
            }
        }


        return result;
    }


    // =========================================================
    // NORMALIZED IMAGE URL
    // =========================================================

    private boolean containsNormalizedUrl(
            List<String> urls,
            String target) {

        String normalizedTarget =
                normalizeUrl(
                        target
                );


        for (String url :
                urls) {

            if (normalizeUrl(
                    url
            ).equals(
                    normalizedTarget
            )) {

                return true;
            }
        }


        return false;
    }


    // =========================================================
    // GOOGLE URL
    // =========================================================

    private String extractGoogleUrl(
            String href) {

        if (href == null
                || href.isBlank()) {

            return "";
        }


        if (href.startsWith(
                "/url?q="
        )) {

            int start =
                    "/url?q=".length();


            int end =
                    href.indexOf(
                            '&',
                            start
                    );


            if (end == -1) {

                end =
                        href.length();
            }


            return href.substring(
                    start,
                    end
            );
        }


        return href;
    }


    // =========================================================
    // REMOVE DUPLICATE
    // =========================================================

    private List<Candidate> removeDuplicateCandidates(
            List<Candidate> candidates) {

        Map<String, Candidate> map =
                new LinkedHashMap<>();


        for (Candidate candidate :
                candidates) {

            if (candidate == null) {

                continue;
            }


            String key =
                    normalizeUrl(
                            candidate.url
                    );


            Candidate old =
                    map.get(key);


            if (old == null
                    || candidate.score
                    > old.score) {

                map.put(
                        key,
                        candidate
                );
            }
        }


        return new ArrayList<>(
                map.values()
        );
    }


    // =========================================================
    // TEXT
    // =========================================================

    private String cleanText(
            String text) {

        if (text == null) {

            return "";
        }


        return text
                .replaceAll(
                        "\\s+",
                        " "
                )
                .trim();
    }


    private String normalizeForSearch(
            String text) {

        if (text == null) {

            return "";
        }


        return text
                .replace(
                        "|",
                        " "
                )
                .replaceAll(
                        "\\s+",
                        " "
                )
                .trim();
    }


    private String normalizeForCompare(
            String text) {

        if (text == null) {

            return "";
        }


        String result =
                java.text.Normalizer
                        .normalize(
                                text,
                                java.text.Normalizer.Form.NFD
                        )
                        .replaceAll(
                                "\\p{M}",
                                ""
                        );


        return result
                .toLowerCase()
                .replaceAll(
                        "[^a-z0-9]+",
                        " "
                )
                .trim();
    }


    // =========================================================
    // TOKENIZE
    // =========================================================

    private Set<String> tokenize(
            String text) {

        Set<String> result =
                new HashSet<>();


        String normalized =
                normalizeForCompare(
                        text
                );


        if (normalized.isBlank()) {

            return result;
        }


        String[] parts =
                normalized.split(
                        "\\s+"
                );


        for (String part :
                parts) {

            if (part.length() >= 2) {

                result.add(
                        part
                );
            }
        }


        return result;
    }


    // =========================================================
    // ADD UNIQUE
    // =========================================================

    private void addUnique(
            List<String> list,
            String value) {

        if (value == null
                || value.isBlank()) {

            return;
        }


        String normalized =
                value.trim()
                        .toLowerCase();


        for (String old :
                list) {

            if (old.trim()
                    .toLowerCase()
                    .equals(
                            normalized
                    )) {

                return;
            }
        }


        list.add(
                value.trim()
        );
    }


    // =========================================================
    // URL NORMALIZE
    // =========================================================

    private String normalizeUrl(
            String url) {

        if (url == null) {

            return "";
        }


        return url
                .trim()
                .replace(
                        "http://",
                        "https://"
                )
                .replaceAll(
                        "/+$",
                        ""
                )
                .toLowerCase();
    }


    // =========================================================
    // PRODUCT MATCH
    // =========================================================

    public static record ProductMatch(
            boolean matched,
            String ttgName,
            String productUrl,
            double score) {


        public static ProductMatch notMatched() {

            return new ProductMatch(
                    false,
                    "",
                    "",
                    0.0
            );
        }
    }


    // =========================================================
    // CANDIDATE
    // =========================================================

    private static class Candidate {

        private final String name;

        private final String url;

        private final double score;


        Candidate(
                String name,
                String url,
                double score) {

            this.name =
                    name == null
                            ? ""
                            : name;


            this.url =
                    url == null
                            ? ""
                            : url;


            this.score =
                    score;
        }
    }
}