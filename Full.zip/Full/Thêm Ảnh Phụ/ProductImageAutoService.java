package com.fpoly.service;

import com.fpoly.model.Product;
import com.fpoly.model.ProductImage;
import com.fpoly.repository.ProductImageRepository;
import com.fpoly.repository.ProductRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class ProductImageAutoService {

    @Autowired
    private ProductRepository productRepo;

    @Autowired
    private ProductImageRepository imageRepo;

    @Autowired
    private TTGShopService ttgShopService;


    // =========================================================
    // CONFIG
    // =========================================================

    private static final int MAX_IMAGES = 4;

    /*
     * Timeout kiểm tra URL ảnh.
     *
     * Không để quá cao vì có thể có rất nhiều sản phẩm.
     */
    private static final int IMAGE_CHECK_TIMEOUT = 5000;


    // =========================================================
    // CHẠY TOÀN BỘ
    // =========================================================

    public void generateAll() {

        List<Product> products =
                productRepo.findAll();

        int total =
                products.size();

        int current = 0;

        int completed = 0;
        int skipped = 0;
        int failed = 0;

        System.out.println();
        System.out.println(
                "=================================================="
        );

        System.out.println(
                "BẮT ĐẦU TỰ ĐỘNG LẤY ẢNH TTG"
        );

        System.out.println(
                "TỔNG SẢN PHẨM: "
                        + total
        );

        System.out.println(
                "=================================================="
        );


        for (Product product : products) {

            current++;

            System.out.println();
            System.out.println(
                    "=================================================="
            );

            System.out.println(
                    "[" + current + "/" + total + "]"
            );

            System.out.println(
                    "ID: "
                            + product.getId()
            );

            System.out.println(
                    "NAME: "
                            + product.getName()
            );

            System.out.println(
                    "=================================================="
            );


            try {

                GenerateResult result =
                        generateForProduct(
                                product
                        );

                switch (result) {

                    case COMPLETED:
                        completed++;
                        break;

                    case SKIPPED:
                        skipped++;
                        break;

                    case FAILED:
                        failed++;
                        break;
                }


            } catch (Exception e) {

                failed++;

                System.out.println(
                        "LỖI SẢN PHẨM ID = "
                                + product.getId()
                );

                System.out.println(
                        "MESSAGE = "
                                + e.getMessage()
                );

                e.printStackTrace();
            }


            /*
             * Nghỉ giữa các sản phẩm.
             */
            sleep(2000);
        }


        System.out.println();
        System.out.println(
                "=================================================="
        );

        System.out.println(
                "ĐÃ HOÀN TẤT GENERATE"
        );

        System.out.println(
                "TỔNG: "
                        + total
        );

        System.out.println(
                "THÀNH CÔNG: "
                        + completed
        );

        System.out.println(
                "BỎ QUA: "
                        + skipped
        );

        System.out.println(
                "FAILED: "
                        + failed
        );

        System.out.println(
                "=================================================="
        );
    }


    // =========================================================
    // GENERATE 1 SẢN PHẨM
    // =========================================================

    @Transactional
    public GenerateResult generateForProduct(
            Product product) {

        if (product == null) {

            return GenerateResult.FAILED;
        }


        if (product.getName() == null
                || product.getName().isBlank()) {

            System.out.println(
                    "SẢN PHẨM KHÔNG CÓ TÊN -> BỎ QUA"
            );

            return GenerateResult.SKIPPED;
        }


        System.out.println();
        System.out.println(
                "ĐANG KIỂM TRA ẢNH HIỆN TẠI..."
        );


        // =====================================================
        // LẤY ẢNH HIỆN TẠI
        // =====================================================

        List<ProductImage> existing =
                imageRepo.findByProduct(
                        product
                );

        if (existing == null) {

            existing =
                    new ArrayList<>();
        }


        /*
         * Danh sách ảnh hợp lệ sau khi lọc.
         */
        List<ProductImage> validImages =
                new ArrayList<>();


        /*
         * =====================================================
         * LỌC ẢNH
         * =====================================================
         */

        for (ProductImage image :
                new ArrayList<>(existing)) {

            if (image == null) {

                continue;
            }


            String url =
                    image.getUrl();


            /*
             * ---------------------------------------------
             * URL rỗng
             * ---------------------------------------------
             */

            if (url == null
                    || url.isBlank()) {

                System.out.println(
                        "ẢNH URL RỖNG -> XÓA"
                );

                imageRepo.delete(image);

                continue;
            }


            /*
             * ---------------------------------------------
             * PLACEHOLDER
             * ---------------------------------------------
             */

            if (isPlaceholder(image)) {

                System.out.println(
                        "XÓA PLACEHOLDER:"
                );

                System.out.println(
                        url
                );

                imageRepo.delete(image);

                continue;
            }


            /*
             * ---------------------------------------------
             * URL không phải dạng ảnh
             * ---------------------------------------------
             */

            if (!isImageUrl(url)) {

                System.out.println(
                        "URL KHÔNG PHẢI ẢNH -> XÓA:"
                );

                System.out.println(
                        url
                );

                imageRepo.delete(image);

                continue;
            }


            /*
             * ---------------------------------------------
             * Ảnh hợp lệ
             *
             * QUAN TRỌNG:
             *
             * Không gọi HTTP check ở đây.
             *
             * Vì TTG có thể chặn HEAD/GET hoặc cần
             * referer khiến ảnh bị đánh dấu sai.
             *
             * Chỉ kiểm tra format + placeholder.
             * ---------------------------------------------
             */

            validImages.add(image);
        }


        /*
         * =====================================================
         * ĐẾM ẢNH THẬT
         * =====================================================
         */

        int realCount =
                validImages.size();


        System.out.println(
                "ẢNH HỢP LỆ HIỆN TẠI: "
                        + realCount
                        + "/"
                        + MAX_IMAGES
        );


        /*
         * =====================================================
         * ĐÃ ĐỦ 4
         * =====================================================
         */

        if (realCount >= MAX_IMAGES) {

            System.out.println(
                    "ĐÃ ĐỦ 4 ẢNH -> BỎ QUA"
            );

            return GenerateResult.SKIPPED;
        }


        /*
         * =====================================================
         * CÒN THIẾU ẢNH
         * =====================================================
         */

        int need =
                MAX_IMAGES - realCount;

        System.out.println(
                "CÒN THIẾU "
                        + need
                        + " ẢNH"
        );


        // =====================================================
        // TÌM SẢN PHẨM TTG
        // =====================================================

        TTGShopService.ProductMatch match =
                ttgShopService.findProduct(
                        product.getName()
                );


        if (!match.matched()) {

            System.out.println();
            System.out.println(
                    "KHÔNG XÁC NHẬN ĐƯỢC SẢN PHẨM TTG"
            );

            System.out.println(
                    "SQL: "
                            + product.getName()
            );

            System.out.println(
                    "=> CHƯA THỂ THÊM ẢNH"
            );

            return GenerateResult.FAILED;
        }


        // =====================================================
        // MATCH
        // =====================================================

        System.out.println();
        System.out.println(
                "SẢN PHẨM TTG ĐÃ KHỚP:"
        );

        System.out.println(
                "SQL: "
                        + product.getName()
        );

        System.out.println(
                "TTG: "
                        + match.ttgName()
        );

        System.out.println(
                "URL: "
                        + match.productUrl()
        );

        System.out.println(
                "SCORE: "
                        + match.score()
        );


        // =====================================================
        // LẤY ẢNH TTG
        // =====================================================

        List<String> ttgImages =
                ttgShopService.getProductImages(
                        match.productUrl()
                );


        if (ttgImages == null
                || ttgImages.isEmpty()) {

            System.out.println(
                    "TTG KHÔNG TRẢ VỀ ẢNH"
            );

            return GenerateResult.FAILED;
        }


        System.out.println(
                "TTG TRẢ VỀ: "
                        + ttgImages.size()
                        + " ẢNH"
        );


        // =====================================================
        // URL ĐÃ CÓ
        // =====================================================

        Set<String> existingUrls =
                new HashSet<>();


        for (ProductImage image :
                validImages) {

            if (image == null) {
                continue;
            }

            String url =
                    image.getUrl();

            if (url == null
                    || url.isBlank()) {

                continue;
            }

            existingUrls.add(
                    normalizeUrl(url)
            );
        }


        // =====================================================
        // SORT ORDER
        // =====================================================

        int nextSortOrder = 0;


        for (ProductImage image :
                validImages) {

            if (image == null) {
                continue;
            }

            Integer sortOrder =
                    image.getSortOrder();

            if (sortOrder != null) {

                nextSortOrder =
                        Math.max(
                                nextSortOrder,
                                sortOrder + 1
                        );
            }
        }


        // =====================================================
        // THÊM ẢNH
        // =====================================================

        int added = 0;


        for (String imageUrl :
                ttgImages) {

            /*
             * Đã đủ 4.
             */
            if (realCount >= MAX_IMAGES) {

                break;
            }


            if (imageUrl == null
                    || imageUrl.isBlank()) {

                continue;
            }


            /*
             * Kiểm tra URL có phải ảnh không.
             */
            if (!isImageUrl(imageUrl)) {

                System.out.println(
                        "URL KHÔNG PHẢI ẢNH -> SKIP:"
                );

                System.out.println(
                        imageUrl
                );

                continue;
            }


            String normalizedUrl =
                    normalizeUrl(
                            imageUrl
                    );


            /*
             * Trùng URL.
             */
            if (existingUrls.contains(
                    normalizedUrl
            )) {

                System.out.println(
                        "ẢNH ĐÃ TỒN TẠI -> SKIP:"
                );

                System.out.println(
                        imageUrl
                );

                continue;
            }


            // =================================================
            // TẠO PRODUCT IMAGE
            // =================================================

            ProductImage image =
                    new ProductImage();

            image.setProduct(product);

            image.setUrl(
                    imageUrl
            );

            image.setSortOrder(
                    nextSortOrder
            );


            /*
             * Nếu sản phẩm chưa có ảnh,
             * ảnh đầu tiên sẽ là primary.
             */
            image.setIsPrimary(
                    realCount == 0
            );


            imageRepo.save(image);


            /*
             * Thêm vào danh sách URL đã tồn tại.
             */
            existingUrls.add(
                    normalizedUrl
            );


            realCount++;

            added++;

            nextSortOrder++;


            System.out.println();
            System.out.println(
                    "ĐÃ THÊM ẢNH "
                            + realCount
                            + "/"
                            + MAX_IMAGES
            );

            System.out.println(
                    imageUrl
            );
        }


        // =====================================================
        // KẾT QUẢ
        // =====================================================

        System.out.println();
        System.out.println(
                "=================================================="
        );

        System.out.println(
                "HOÀN TẤT SẢN PHẨM ID = "
                        + product.getId()
        );

        System.out.println(
                "ẢNH HIỆN TẠI = "
                        + realCount
                        + "/"
                        + MAX_IMAGES
        );

        System.out.println(
                "ẢNH MỚI THÊM = "
                        + added
        );

        System.out.println(
                "=================================================="
        );


        if (added > 0) {

            return GenerateResult.COMPLETED;
        }


        /*
         * Không thêm được ảnh nào.
         */
        return GenerateResult.FAILED;
    }


    // =========================================================
    // TEST TTG
    // =========================================================

    public List<String> testTTG(
            Product product) {

        if (product == null) {

            return new ArrayList<>();
        }


        System.out.println();
        System.out.println(
                "=================================================="
        );

        System.out.println(
                "ĐANG TEST TTG"
        );

        System.out.println(
                "ID: "
                        + product.getId()
        );

        System.out.println(
                "NAME: "
                        + product.getName()
        );

        System.out.println(
                "=================================================="
        );


        TTGShopService.ProductMatch match =
                ttgShopService.findProduct(
                        product.getName()
                );


        if (!match.matched()) {

            System.out.println(
                    "KHÔNG XÁC NHẬN ĐƯỢC SẢN PHẨM"
            );

            return new ArrayList<>();
        }


        System.out.println(
                "MATCH THÀNH CÔNG"
        );

        System.out.println(
                "TTG NAME: "
                        + match.ttgName()
        );

        System.out.println(
                "TTG URL: "
                        + match.productUrl()
        );

        System.out.println(
                "SCORE: "
                        + match.score()
        );


        return ttgShopService.getProductImages(
                match.productUrl()
        );
    }


    // =========================================================
    // KIỂM TRA ẢNH THẬT
    // =========================================================

    private boolean isRealImage(
            ProductImage image) {

        if (image == null) {

            return false;
        }


        String url =
                image.getUrl();


        if (url == null
                || url.isBlank()) {

            return false;
        }


        if (isPlaceholder(image)) {

            return false;
        }


        return isImageUrl(url);
    }


    // =========================================================
    // KIỂM TRA URL ẢNH
    // =========================================================

    private boolean isImageUrl(
            String url) {

        if (url == null
                || url.isBlank()) {

            return false;
        }


        String lower =
                url.trim()
                        .toLowerCase();


        /*
         * Placeholder.
         */
        if (lower.contains(
                "placehold.co"
        )) {

            return false;
        }


        if (lower.contains(
                "placeholder"
        )) {

            return false;
        }


        /*
         * Facebook.
         */
        if (lower.contains(
                "facebook"
        )) {

            return false;
        }


        if (lower.contains(
                "fbcdn.net"
        )) {

            return false;
        }


        /*
         * Icon / logo / banner.
         */
        if (lower.contains(
                "favicon"
        )) {

            return false;
        }

        if (lower.contains(
                "emoji"
        )) {

            return false;
        }


        /*
         * Không cần bắt buộc phải có extension
         * ở cuối URL vì URL có thể có:
         *
         * image.jpg?v=123
         *
         * image.webp?width=800
         */
        String cleanUrl =
                lower;


        int queryIndex =
                cleanUrl.indexOf("?");


        if (queryIndex >= 0) {

            cleanUrl =
                    cleanUrl.substring(
                            0,
                            queryIndex
                    );
        }


        int fragmentIndex =
                cleanUrl.indexOf("#");


        if (fragmentIndex >= 0) {

            cleanUrl =
                    cleanUrl.substring(
                            0,
                            fragmentIndex
                    );
        }


        /*
         * Các extension ảnh.
         */
        if (cleanUrl.endsWith(".jpg")
                || cleanUrl.endsWith(".jpeg")
                || cleanUrl.endsWith(".png")
                || cleanUrl.endsWith(".webp")
                || cleanUrl.endsWith(".gif")) {

            return true;
        }


        /*
         * TTG media/product.
         *
         * Một số URL có thể không có extension
         * rõ ràng nhưng vẫn là ảnh sản phẩm.
         */
        if (lower.contains(
                "ttgshop.vn/media/product/"
        )) {

            return true;
        }


        return false;
    }


    // =========================================================
    // PLACEHOLDER
    // =========================================================

    private boolean isPlaceholder(
            ProductImage image) {

        if (image == null) {

            return false;
        }


        String url =
                image.getUrl();


        if (url == null
                || url.isBlank()) {

            return false;
        }


        String lower =
                url.toLowerCase();


        return lower.contains(
                "placehold.co"
        )
                || lower.contains(
                "placeholder"
        );
    }


    // =========================================================
    // NORMALIZE URL
    // =========================================================

    private String normalizeUrl(
            String url) {

        if (url == null) {

            return "";
        }


        return url
                .trim()
                .replace(
                        "http://",
                        "https://"
                )
                .replaceAll(
                        "/+$",
                        ""
                )
                .toLowerCase();
    }


    // =========================================================
    // DELAY
    // =========================================================

    private void sleep(
            long millis) {

        try {

            Thread.sleep(
                    millis
            );

        } catch (InterruptedException e) {

            Thread.currentThread()
                    .interrupt();
        }
    }


    // =========================================================
    // RESULT
    // =========================================================

    private enum GenerateResult {

        COMPLETED,

        SKIPPED,

        FAILED
    }
}