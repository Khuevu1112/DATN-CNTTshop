package com.fpoly.repository;

import com.fpoly.model.Product;
import com.fpoly.model.ProductImage;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductImageRepository
        extends JpaRepository<ProductImage, Integer> {

    List<ProductImage> findByProduct(Product product);

    boolean existsByProductAndIsPrimaryTrue(Product product);
}