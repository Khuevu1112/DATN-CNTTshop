package com.fpoly.controller.admin;

import com.fpoly.model.Product;
import com.fpoly.repository.ProductRepository;
import com.fpoly.service.ProductImageAutoService;
import com.fpoly.service.TTGShopService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin/product-images")
public class ProductImageAutoController {

    @Autowired
    private ProductImageAutoService autoService;

    @Autowired
    private ProductRepository productRepo;

    @Autowired
    private TTGShopService ttgShopService;


    // =========================================================
    // TEST 1 SẢN PHẨM - CÓ GHI DATABASE
    // =========================================================

    /*
     * Ví dụ:
     *
     * /admin/product-images/test/1
     */

    @GetMapping("/test/{id}")
    @ResponseBody
    public String test(
            @PathVariable Integer id) {

        Product product =
                productRepo.findById(id)
                        .orElseThrow(
                                () -> new RuntimeException(
                                        "Không tìm thấy sản phẩm ID = "
                                                + id
                                )
                        );

        autoService.generateForProduct(
                product
        );

        return """
                <h3>Đã xử lý sản phẩm</h3>
                <p>ID: %d</p>
                <p>Tên: %s</p>
                """.formatted(
                product.getId(),
                product.getName()
        );
    }


    // =========================================================
    // CHECK TTG - KHÔNG GHI DATABASE
    // =========================================================

    /*
     * Đây là URL NÊN TEST TRƯỚC.
     *
     * Ví dụ:
     *
     * /admin/product-images/check-ttg/1
     *
     * Nó chỉ:
     *
     * SQL Product
     *       ↓
     * Tìm Google/Bing
     *       ↓
     * Tìm trang TTG
     *       ↓
     * Đối chiếu tên
     *       ↓
     * Nếu đúng -> hiển thị ảnh
     *
     * KHÔNG lưu database.
     */

    @GetMapping("/check-ttg/{id}")
    @ResponseBody
    public String checkTTG(
            @PathVariable Integer id) {

        Product product =
                productRepo.findById(id)
                        .orElseThrow(
                                () -> new RuntimeException(
                                        "Không tìm thấy sản phẩm ID = "
                                                + id
                                )
                        );

        TTGShopService.ProductMatch match =
                ttgShopService.findProduct(
                        product.getName()
                );

        /*
         * Không match.
         */
        if (!match.matched()) {

            return """
                    <html>
                    <body>

                    <h2>❌ KHÔNG XÁC NHẬN ĐƯỢC SẢN PHẨM TTG</h2>

                    <p><b>ID:</b> %d</p>

                    <p><b>Sản phẩm SQL:</b><br>
                    %s
                    </p>

                    <p>
                    Không lấy ảnh vì không xác định chắc chắn
                    đây là đúng sản phẩm.
                    </p>

                    </body>
                    </html>
                    """.formatted(
                    product.getId(),
                    escapeHtml(
                            product.getName()
                    )
            );
        }

        /*
         * Match thành công.
         */
        List<String> images =
                ttgShopService.getProductImages(
                        match.productUrl()
                );

        StringBuilder html =
                new StringBuilder();

        html.append(
                """
                <html>
                <body>

                <h2>✅ XÁC NHẬN ĐÚNG SẢN PHẨM</h2>
                """
        );

        html.append(
                "<p><b>ID:</b> "
        ).append(
                product.getId()
        ).append(
                "</p>"
        );

        html.append(
                "<p><b>Tên SQL:</b><br>"
        ).append(
                escapeHtml(
                        product.getName()
                )
        ).append(
                "</p>"
        );

        html.append(
                "<p><b>Tên TTG:</b><br>"
        ).append(
                escapeHtml(
                        match.ttgName()
                )
        ).append(
                "</p>"
        );

        html.append(
                "<p><b>Score:</b> "
        ).append(
                match.score()
        ).append(
                "</p>"
        );

        html.append(
                "<p><b>URL TTG:</b><br>"
        ).append(
                "<a href='"
        ).append(
                escapeHtml(
                        match.productUrl()
                )
        ).append(
                "' target='_blank'>"
        ).append(
                escapeHtml(
                        match.productUrl()
                )
        ).append(
                "</a></p>"
        );

        html.append(
                "<h3>Ảnh lấy từ chính trang TTG:</h3>"
        );

        if (images.isEmpty()) {

            html.append(
                    "<p>Không lấy được ảnh.</p>"
            );

        } else {

            for (String image :
                    images) {

                html.append(
                        "<div style='margin-bottom:30px;'>"
                );

                html.append(
                        "<img src='"
                ).append(
                        escapeHtml(image)
                ).append(
                        "' style='max-width:400px;max-height:400px;'>"
                );

                html.append(
                        "<br>"
                );

                html.append(
                        "<a href='"
                ).append(
                        escapeHtml(image)
                ).append(
                        "' target='_blank'>"
                ).append(
                        escapeHtml(image)
                ).append(
                        "</a>"
                );

                html.append(
                        "</div>"
                );
            }
        }

        html.append(
                """
                </body>
                </html>
                """
        );

        return html.toString();
    }


    // =========================================================
    // TEST TTG CŨ - GIỮ LẠI ĐỂ TƯƠNG THÍCH
    // =========================================================

    @GetMapping("/test-ttg/{id}")
    @ResponseBody
    public String testTTG(
            @PathVariable Integer id) {

        Product product =
                productRepo.findById(id)
                        .orElseThrow(
                                () -> new RuntimeException(
                                        "Không tìm thấy sản phẩm ID = "
                                                + id
                                )
                        );

        List<String> images =
                autoService.testTTG(
                        product
                );

        if (images.isEmpty()) {

            return """
                    <h3>Không tìm thấy ảnh TTG</h3>
                    <p>ID: %d</p>
                    <p>%s</p>
                    """.formatted(
                    product.getId(),
                    escapeHtml(
                            product.getName()
                    )
            );
        }

        StringBuilder html =
                new StringBuilder();

        html.append(
                "<h3>Sản phẩm: "
        );

        html.append(
                escapeHtml(
                        product.getName()
                )
        );

        html.append(
                "</h3>"
        );

        html.append(
                "<p>Tìm được "
        );

        html.append(
                images.size()
        );

        html.append(
                " ảnh:</p>"
        );

        for (String url :
                images) {

            html.append(
                    "<p>"
            );

            html.append(
                    "<img src='"
            );

            html.append(
                    escapeHtml(url)
            );

            html.append(
                    "' width='300'>"
            );

            html.append(
                    "<br>"
            );

            html.append(
                    escapeHtml(url)
            );

            html.append(
                    "</p>"
            );
        }

        return html.toString();
    }


    // =========================================================
    // GENERATE TOÀN BỘ
    // =========================================================

    /*
     * /admin/product-images/generate
     */

    @GetMapping("/generate")
    @ResponseBody
    public String generateAll() {

        Thread thread =
                new Thread(
                        () -> {

                            autoService.generateAll();

                        }
                );

        thread.setName(
                "ttg-product-image-generator"
        );

        thread.start();

        return """
                <html>
                <body>

                <h2>✅ Đã bắt đầu xử lý ảnh</h2>

                <p>
                Hệ thống đang chạy toàn bộ sản phẩm
                ở background.
                </p>

                <p>
                Hãy xem Console Spring Boot để theo dõi.
                </p>

                <p>
                <b>Lưu ý:</b>
                Chỉ sản phẩm xác nhận đúng trên TTG
                mới được lấy ảnh.
                </p>

                </body>
                </html>
                """;
    }


    // =========================================================
    // ESCAPE HTML
    // =========================================================

    private String escapeHtml(
            String text) {

        if (text == null) {
            return "";
        }

        return text
                .replace(
                        "&",
                        "&amp;"
                )
                .replace(
                        "<",
                        "&lt;"
                )
                .replace(
                        ">",
                        "&gt;"
                )
                .replace(
                        "\"",
                        "&quot;"
                )
                .replace(
                        "'",
                        "&#39;"
                );
    }
}