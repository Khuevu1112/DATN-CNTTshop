Các file đã sửa cho nhiệm vụ Pop-up xác nhận:

main/resources/templates/account/address-form.html
main/resources/templates/account/profile.html
main/resources/templates/account/address-list.html
main/resources/templates/order/detail.html
main/resources/templates/order/checkout.html
main/resources/templates/admin/category-form.html
main/resources/templates/admin/warranty-request-detail.html
main/resources/templates/admin/user-edit.html
main/resources/templates/admin/warranty-detail.html
main/resources/templates/admin/user-form.html
main/resources/templates/admin/dashboard.html
main/resources/templates/admin/backup.html
main/resources/templates/admin/product-form.html
main/resources/templates/admin/returns/detail.html
main/resources/templates/warranty/detail.html
main/resources/templates/wishlist/index.html
