package com.fpoly.controller.cilent;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.fpoly.model.Category;
import com.fpoly.model.Product;
import com.fpoly.repository.CategoryRepository;
import com.fpoly.repository.ProductRepository;

@Controller
public class ClientProductController {

    private static final int PRODUCTS_PER_PAGE = 24;

    @Autowired
    private ProductRepository productRepo;

    @Autowired
    private CategoryRepository categoryRepo;

    @GetMapping("/products")
    public String products(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String sort,
            @RequestParam(defaultValue = "0") int page,
            Model model
    ) {
        Page<Product> productPage = loadProducts(null, keyword, sort, page);

        model.addAttribute("products", productPage.getContent());
        model.addAttribute("productPage", productPage);
        model.addAttribute("keyword", keyword);
        model.addAttribute("sort", sort);
        model.addAttribute("basePath", "/products");
        model.addAttribute("content", "product/list");

        return "layout/Base";
    }

    @GetMapping("/category/{slug}")
    public String productsByCategory(
            @PathVariable String slug,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String sort,
            @RequestParam(defaultValue = "0") int page,
            Model model
    ) {
        Category category = categoryRepo.findBySlug(slug)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy danh mục"));

        Page<Product> productPage = loadProducts(category, keyword, sort, page);

        model.addAttribute("category", category);
        model.addAttribute("products", productPage.getContent());
        model.addAttribute("productPage", productPage);
        model.addAttribute("keyword", keyword);
        model.addAttribute("sort", sort);
        model.addAttribute("basePath", "/category/" + category.getSlug());
        model.addAttribute("content", "product/list");

        return "layout/Base";
    }

    @GetMapping("/product/{slug}")
    public String detail(
            @PathVariable String slug,
            Model model
    ) {
        Product product = productRepo.findBySlug(slug)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy sản phẩm"));

        model.addAttribute("product", product);
        model.addAttribute("content", "product/detail");
        model.addAttribute("variants", product.getVariants());
        return "layout/Base";
    }

    private Page<Product> loadProducts(
            Category category,
            String keyword,
            String sort,
            int page
    ) {
        int safePage = Math.max(page, 0);
        Pageable pageable = PageRequest.of(
                safePage,
                PRODUCTS_PER_PAGE,
                buildSort(sort)
        );

        boolean hasKeyword = keyword != null && !keyword.isBlank();

        if (category != null) {
            if (hasKeyword) {
                return productRepo.findByCategoryAndNameContainingIgnoreCaseAndIsActiveTrue(
                        category, keyword.trim(), pageable);
            }
            return productRepo.findByCategoryAndIsActiveTrue(category, pageable);
        }

        if (hasKeyword) {
            return productRepo.findByNameContainingIgnoreCaseAndIsActiveTrue(
                    keyword.trim(), pageable);
        }

        return productRepo.findByIsActiveTrue(pageable);
    }

    private Sort buildSort(String sort) {
        if ("name_asc".equals(sort)) {
            return Sort.by(Sort.Direction.ASC, "name");
        }

        if ("name_desc".equals(sort)) {
            return Sort.by(Sort.Direction.DESC, "name");
        }

        // Mặc định và "newest": sản phẩm mới nhất trước.
        return Sort.by(Sort.Direction.DESC, "createdAt");
    }
}
