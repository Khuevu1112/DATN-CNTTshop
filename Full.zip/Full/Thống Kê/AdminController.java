package com.fpoly.controller.admin;

import com.fpoly.service.AIStatisticService;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import org.springframework.beans.factory.annotation.Autowired;

@Controller
@Transactional
public class AdminController {

    @Autowired
    @PersistenceContext
    private EntityManager em;

    // ==========================================
    // TRANG DASHBOARD
    // ==========================================
    @GetMapping("/admin/dashboard")
    public String dashboard() {
        return "admin/dashboard";
    }

    private final AIStatisticService aiStatisticService;

    public AdminController(AIStatisticService aiStatisticService) {
        this.aiStatisticService = aiStatisticService;
    }
    
    // ==========================================
    // API: THỐNG KÊ TỔNG QUAN
    // ==========================================
    @GetMapping("/admin/api/stats")
    @ResponseBody
    public Map<String, Object> getStats() {
        Map<String, Object> result = new HashMap<>();

        result.put("todayOrders",
            em.createNativeQuery(
                "SELECT COUNT(*) FROM [ORDER] WHERE CAST(created_at AS DATE)=CAST(GETDATE() AS DATE)"
            ).getSingleResult());

        result.put("todayRevenue",
            em.createNativeQuery(
                "SELECT ISNULL(SUM(total_amount),0) FROM [ORDER] " +
                "WHERE CAST(created_at AS DATE)=CAST(GETDATE() AS DATE) AND status!='cancelled'"
            ).getSingleResult());

        result.put("newCustomers",
            em.createNativeQuery(
                "SELECT COUNT(*) FROM [USER] WHERE CAST(created_at AS DATE)=CAST(GETDATE() AS DATE)"
            ).getSingleResult());

        result.put("totalCustomers",
            em.createNativeQuery(
                "SELECT COUNT(*) FROM [USER] WHERE role='customer'"
            ).getSingleResult());

        result.put("recentOrders",
            em.createNativeQuery(
                "SELECT TOP 10 o.order_code, u.full_name, o.total_amount, o.status, " +
                "CONVERT(VARCHAR,o.created_at,103) " +
                "FROM [ORDER] o JOIN [USER] u ON o.user_id=u.id " +
                "ORDER BY o.created_at DESC"
            ).getResultList());

        result.put("last7Days",
            em.createNativeQuery(
                "SELECT CONVERT(VARCHAR,CAST(created_at AS DATE),103), COUNT(*) " +
                "FROM [ORDER] " +
                "WHERE created_at>=DATEADD(DAY,-6,CAST(GETDATE() AS DATE)) " +
                "GROUP BY CAST(created_at AS DATE) ORDER BY CAST(created_at AS DATE) ASC"
            ).getResultList());

        result.put("aiInsights", aiStatisticService.analyze());
        return result;
    }

    // ==========================================
    // API: DOANH THU
    // ==========================================
    @GetMapping("/admin/api/revenue")
    @ResponseBody
    public Map<String, Object> getRevenue(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {

        Map<String, Object> result = new HashMap<>();

        Query q1 = em.createNativeQuery(
            "SELECT ISNULL(SUM(total_amount),0) FROM [ORDER] " +
            "WHERE CAST(created_at AS DATE) BETWEEN :from AND :to AND status!='cancelled'");
        q1.setParameter("from", from); q1.setParameter("to", to);
        result.put("totalRevenue", q1.getSingleResult());

        Query q2 = em.createNativeQuery(
            "SELECT COUNT(*) FROM [ORDER] " +
            "WHERE CAST(created_at AS DATE) BETWEEN :from AND :to AND status='delivered'");
        q2.setParameter("from", from); q2.setParameter("to", to);
        result.put("successOrders", q2.getSingleResult());

        Query q3 = em.createNativeQuery(
            "SELECT ISNULL(AVG(total_amount),0) FROM [ORDER] " +
            "WHERE CAST(created_at AS DATE) BETWEEN :from AND :to AND status!='cancelled'");
        q3.setParameter("from", from); q3.setParameter("to", to);
        result.put("avgOrder", q3.getSingleResult());

        Query q4 = em.createNativeQuery(
            "SELECT COUNT(*) FROM [ORDER] " +
            "WHERE CAST(created_at AS DATE) BETWEEN :from AND :to AND status='refunded'");
        q4.setParameter("from", from); q4.setParameter("to", to);
        result.put("refundedOrders", q4.getSingleResult());

        Query q5 = em.createNativeQuery(
            "SELECT 'Tuần '+CAST(ROW_NUMBER() OVER(ORDER BY MIN(CAST(created_at AS DATE))) AS VARCHAR), " +
            "ISNULL(SUM(total_amount),0) " +
            "FROM [ORDER] " +
            "WHERE CAST(created_at AS DATE) BETWEEN :from AND :to AND status!='cancelled' " +
            "GROUP BY DATEPART(WEEK,created_at) ORDER BY MIN(CAST(created_at AS DATE)) ASC");
        q5.setParameter("from", from); q5.setParameter("to", to);
        result.put("weeklyRevenue", q5.getResultList());

        Query q6 = em.createNativeQuery(
            "SELECT c.name, ISNULL(SUM(oi.unit_price*oi.quantity),0) " +
            "FROM ORDER_ITEM oi " +
            "JOIN PRODUCT_VARIANT pv ON oi.variant_id=pv.id " +
            "JOIN PRODUCT p ON pv.product_id=p.id " +
            "JOIN CATEGORY c ON p.category_id=c.id " +
            "JOIN [ORDER] o ON oi.order_id=o.id " +
            "WHERE CAST(o.created_at AS DATE) BETWEEN :from AND :to AND o.status!='cancelled' " +
            "GROUP BY c.name ORDER BY 2 DESC");
        q6.setParameter("from", from); q6.setParameter("to", to);
        result.put("categoryRevenue", q6.getResultList());

        return result;
    }

    // ==========================================
    // API: THỐNG KÊ NÂNG CAO
    // Bộ lọc + nhiều biểu đồ + chi tiết sản phẩm
    // ==========================================
    @GetMapping("/admin/api/advanced-statistics")
    @ResponseBody
    public Map<String, Object> getAdvancedStatistics(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
            @RequestParam(required = false) Integer categoryId,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) Integer paymentMethodId) {

        Map<String, Object> result = new HashMap<>();

        StringBuilder filter = new StringBuilder();
        filter.append(" CAST(o.created_at AS DATE) BETWEEN :from AND :to ");
        Map<String, Object> params = new HashMap<>();
        params.put("from", from);
        params.put("to", to);

        if (status != null && !status.isBlank() && !"all".equalsIgnoreCase(status)) {
            filter.append(" AND o.status = :status ");
            params.put("status", status);
        }

        if (categoryId != null) {
            filter.append(" AND EXISTS (SELECT 1 FROM ORDER_ITEM xoi " +
                    "JOIN PRODUCT_VARIANT xpv ON xoi.variant_id=xpv.id " +
                    "JOIN PRODUCT xp ON xpv.product_id=xp.id " +
                    "WHERE xoi.order_id=o.id AND xp.category_id=:categoryId) ");
            params.put("categoryId", categoryId);
        }

        if (paymentMethodId != null) {
            filter.append(" AND EXISTS (SELECT 1 FROM PAYMENT xpmt " +
                    "WHERE xpmt.order_id=o.id AND xpmt.payment_method_id=:paymentMethodId) ");
            params.put("paymentMethodId", paymentMethodId);
        }

        // Tổng quan
        Query summary = em.createNativeQuery(
                "SELECT COUNT(*) AS total_orders, " +
                "ISNULL(SUM(o.total_amount),0) AS revenue, " +
                "ISNULL(AVG(o.total_amount),0) AS avg_order, " +
                "SUM(CASE WHEN o.status='refunded' THEN 1 ELSE 0 END) AS refunded_orders " +
                "FROM [ORDER] o WHERE " + filter.toString());
        params.forEach(summary::setParameter);
        Object[] sm = (Object[]) summary.getSingleResult();

        Query soldQuery = em.createNativeQuery(
                "SELECT ISNULL(SUM(oi.quantity),0) " +
                "FROM ORDER_ITEM oi JOIN [ORDER] o ON oi.order_id=o.id " +
                "WHERE " + filter.toString());
        params.forEach(soldQuery::setParameter);

        Map<String,Object> summaryMap = new HashMap<>();
        summaryMap.put("orders", sm[0]);
        summaryMap.put("revenue", sm[1]);
        summaryMap.put("avgOrder", sm[2]);
        summaryMap.put("soldQty", soldQuery.getSingleResult());
        summaryMap.put("refundedOrders", sm[3]);
        result.put("summary", summaryMap);

        // Doanh thu theo ngày
        Query byDate = em.createNativeQuery(
                "SELECT CONVERT(VARCHAR,CAST(o.created_at AS DATE),103), " +
                "COUNT(*), ISNULL(SUM(o.total_amount),0) " +
                "FROM [ORDER] o WHERE " + filter.toString() +
                " GROUP BY CAST(o.created_at AS DATE) ORDER BY CAST(o.created_at AS DATE)");
        params.forEach(byDate::setParameter);
        result.put("revenueByDate", byDate.getResultList());

        // Đơn hàng theo trạng thái
        Query byStatus = em.createNativeQuery(
                "SELECT o.status, COUNT(*), ISNULL(SUM(o.total_amount),0) " +
                "FROM [ORDER] o WHERE " + filter.toString() +
                " GROUP BY o.status ORDER BY COUNT(*) DESC");
        params.forEach(byStatus::setParameter);
        result.put("ordersByStatus", byStatus.getResultList());

        // Doanh thu theo danh mục
        Query byCategory = em.createNativeQuery(
                "SELECT ISNULL(c.name,N'Không danh mục'), " +
                "ISNULL(SUM(oi.unit_price*oi.quantity),0), ISNULL(SUM(oi.quantity),0) " +
                "FROM ORDER_ITEM oi " +
                "JOIN PRODUCT_VARIANT pv ON oi.variant_id=pv.id " +
                "JOIN PRODUCT p ON pv.product_id=p.id " +
                "LEFT JOIN CATEGORY c ON p.category_id=c.id " +
                "JOIN [ORDER] o ON oi.order_id=o.id " +
                "WHERE " + filter.toString() +
                " GROUP BY c.name ORDER BY 2 DESC");
        params.forEach(byCategory::setParameter);
        result.put("revenueByCategory", byCategory.getResultList());

        // Doanh thu theo phương thức thanh toán
        Query byPayment = em.createNativeQuery(
                "SELECT ISNULL(pm.name,N'Chưa xác định'), COUNT(DISTINCT o.id), ISNULL(SUM(o.total_amount),0) " +
                "FROM [ORDER] o LEFT JOIN PAYMENT pay ON pay.order_id=o.id " +
                "LEFT JOIN PAYMENT_METHOD pm ON pm.id=pay.payment_method_id " +
                "WHERE " + filter.toString() +
                " GROUP BY pm.name ORDER BY 3 DESC");
        params.forEach(byPayment::setParameter);
        result.put("revenueByPayment", byPayment.getResultList());

        // Top sản phẩm
        Query topProducts = em.createNativeQuery(
                "SELECT TOP 10 p.id, p.name, ISNULL(c.name,N'Không danh mục'), " +
                "SUM(oi.quantity), ISNULL(SUM(oi.unit_price*oi.quantity),0) " +
                "FROM ORDER_ITEM oi " +
                "JOIN PRODUCT_VARIANT pv ON oi.variant_id=pv.id " +
                "JOIN PRODUCT p ON pv.product_id=p.id " +
                "LEFT JOIN CATEGORY c ON p.category_id=c.id " +
                "JOIN [ORDER] o ON oi.order_id=o.id " +
                "WHERE " + filter.toString() +
                " GROUP BY p.id,p.name,c.name ORDER BY SUM(oi.quantity) DESC, SUM(oi.unit_price*oi.quantity) DESC");
        params.forEach(topProducts::setParameter);
        result.put("topProducts", topProducts.getResultList());

        // Chi tiết tất cả sản phẩm có bán trong kỳ + tồn kho hiện tại
        Query details = em.createNativeQuery(
                "SELECT p.id, p.name, ISNULL(c.name,N'Không danh mục'), " +
                "ISNULL(SUM(oi.quantity),0), ISNULL(SUM(oi.unit_price*oi.quantity),0), " +
                "ISNULL((SELECT SUM(v2.stock) FROM PRODUCT_VARIANT v2 WHERE v2.product_id=p.id),0), " +
                "CASE WHEN p.is_active=1 THEN N'Đang bán' ELSE N'Ngừng bán' END " +
                "FROM PRODUCT p LEFT JOIN CATEGORY c ON p.category_id=c.id " +
                "LEFT JOIN PRODUCT_VARIANT pv ON pv.product_id=p.id " +
                "LEFT JOIN ORDER_ITEM oi ON oi.variant_id=pv.id " +
                "LEFT JOIN [ORDER] o ON oi.order_id=o.id " +
                "AND " + filter.toString() +
                " GROUP BY p.id,p.name,c.name,p.is_active " +
                "HAVING ISNULL(SUM(oi.quantity),0) > 0 " +
                "ORDER BY ISNULL(SUM(oi.unit_price*oi.quantity),0) DESC");
        params.forEach(details::setParameter);
        result.put("details", details.getResultList());

        // Danh sách sản phẩm sắp hết hàng (không phụ thuộc bộ lọc ngày)
        Query lowStock = em.createNativeQuery(
                "SELECT TOP 10 p.id,p.name,ISNULL(SUM(v.stock),0) " +
                "FROM PRODUCT p LEFT JOIN PRODUCT_VARIANT v ON v.product_id=p.id " +
                "WHERE p.is_active=1 GROUP BY p.id,p.name " +
                "HAVING ISNULL(SUM(v.stock),0) <= 10 ORDER BY ISNULL(SUM(v.stock),0) ASC,p.name ASC");
        result.put("lowStock", lowStock.getResultList());

        return result;
    }

    @GetMapping("/admin/api/statistics/categories")
    @ResponseBody
    public List getStatisticsCategories() {
        return em.createNativeQuery("SELECT id,name FROM CATEGORY ORDER BY name ASC").getResultList();
    }

    @GetMapping("/admin/api/statistics/payment-methods")
    @ResponseBody
    public List getStatisticsPaymentMethods() {
        return em.createNativeQuery("SELECT id,name FROM PAYMENT_METHOD WHERE ISNULL(is_active,1)=1 ORDER BY name ASC").getResultList();
    }

    // ==========================================
    // API: SHIPPING ZONE — Lấy danh sách
    // ==========================================
    @GetMapping("/admin/api/shipping")
    @ResponseBody
    public List getShippingZones() {
        return em.createNativeQuery(
            "SELECT id, name, zone_key, base_fee, kg_fee, free_from, is_active " +
            "FROM SHIPPING_ZONE ORDER BY id ASC"
        ).getResultList();
    }

    // API: SHIPPING ZONE — Thêm mới
    @PostMapping("/admin/api/shipping")
    @ResponseBody
    public Map<String, Object> addShippingZone(@RequestBody Map<String, Object> body) {
        Map<String, Object> result = new HashMap<>();
        try {
            Query q = em.createNativeQuery(
                "INSERT INTO SHIPPING_ZONE (name, zone_key, base_fee, kg_fee, free_from) " +
                "VALUES (:name, :key, :base, :kg, :free)");
            q.setParameter("name", body.get("name").toString());
            q.setParameter("key",  body.get("key").toString());
            q.setParameter("base", Integer.parseInt(body.get("base").toString()));
            q.setParameter("kg",   Integer.parseInt(body.get("kg").toString()));
            q.setParameter("free", Integer.parseInt(body.get("free").toString()));
            q.executeUpdate();
            result.put("success", true);
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }

    // API: SHIPPING ZONE — Sửa
    @PutMapping("/admin/api/shipping/{id}")
    @ResponseBody
    public Map<String, Object> updateShippingZone(
            @PathVariable int id,
            @RequestBody Map<String, Object> body) {
        Map<String, Object> result = new HashMap<>();
        try {
            Query q = em.createNativeQuery(
                "UPDATE SHIPPING_ZONE SET name=:name, base_fee=:base, kg_fee=:kg, free_from=:free " +
                "WHERE id=:id");
            q.setParameter("name", body.get("name").toString());
            q.setParameter("base", Integer.parseInt(body.get("base").toString()));
            q.setParameter("kg",   Integer.parseInt(body.get("kg").toString()));
            q.setParameter("free", Integer.parseInt(body.get("free").toString()));
            q.setParameter("id",   id);
            q.executeUpdate();
            result.put("success", true);
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }

    // API: SHIPPING ZONE — Xóa
    @DeleteMapping("/admin/api/shipping/{id}")
    @ResponseBody
    public Map<String, Object> deleteShippingZone(@PathVariable int id) {
        Map<String, Object> result = new HashMap<>();
        try {
            em.createNativeQuery("DELETE FROM SHIPPING_ZONE WHERE id=:id")
              .setParameter("id", id)
              .executeUpdate();
            result.put("success", true);
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }

    // ==========================================
    // API: COUPON — Lấy danh sách
    // ==========================================
    @GetMapping("/admin/api/coupon")
    @ResponseBody
    public List getCoupons() {
        return em.createNativeQuery(
            "SELECT id, code, discount_type, discount_value, min_order_value, " +
            "max_uses, used_count, expires_at, is_active, " +
            "condition_all_product, condition_new_product, " +
            "condition_new_customer, condition_no_sale " +
            "FROM COUPON ORDER BY id DESC"
        ).getResultList();
    }

    // API: COUPON — Thêm mới
    @PostMapping("/admin/api/coupon")
    @ResponseBody
    public Map<String, Object> addCoupon(@RequestBody Map<String, Object> body) {
        Map<String, Object> result = new HashMap<>();
        try {
            Query q = em.createNativeQuery(
                "INSERT INTO COUPON (code, discount_type, discount_value, min_order_value, " +
                "max_uses, expires_at, is_active, " +
                "condition_all_product, condition_new_product, condition_new_customer, condition_no_sale) " +
                "VALUES (:code, :type, :val, :min, :max, :exp, 1, :ca, :cn, :cc, :cs)");
            q.setParameter("code", body.get("code").toString().toUpperCase());
            q.setParameter("type", body.get("type").toString());
            q.setParameter("val",  Double.parseDouble(body.get("value").toString()));
            q.setParameter("min",  Double.parseDouble(body.get("min").toString()));
            q.setParameter("max",  body.get("maxUse") != null && !body.get("maxUse").toString().isEmpty()
                                   ? Integer.parseInt(body.get("maxUse").toString()) : null);
            q.setParameter("exp",  body.get("expiry") != null && !body.get("expiry").toString().isEmpty()
                                   ? LocalDate.parse(body.get("expiry").toString()) : null);
            q.setParameter("ca",   body.getOrDefault("condAll",    true));
            q.setParameter("cn",   body.getOrDefault("condNew",    false));
            q.setParameter("cc",   body.getOrDefault("condCust",   false));
            q.setParameter("cs",   body.getOrDefault("condNoSale", false));
            q.executeUpdate();
            result.put("success", true);
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }

    // API: COUPON — Xóa
    @DeleteMapping("/admin/api/coupon/{id}")
    @ResponseBody
    public Map<String, Object> deleteCoupon(@PathVariable int id) {
        Map<String, Object> result = new HashMap<>();
        try {
            em.createNativeQuery("DELETE FROM COUPON WHERE id=:id")
              .setParameter("id", id)
              .executeUpdate();
            result.put("success", true);
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
    
    // ==========================================
    // API AI
    // ==========================================
    @GetMapping("/admin/api/ai-insight")
    @ResponseBody
    public List<String> aiInsight() {
        return aiStatisticService.analyze();
    }
}