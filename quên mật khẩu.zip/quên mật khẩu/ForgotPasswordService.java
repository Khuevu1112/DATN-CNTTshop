package com.fpoly.service;

import java.time.LocalDateTime;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.fpoly.model.NguoiDung;
import com.fpoly.repository.NguoiDungRepository;

import jakarta.servlet.http.HttpSession;

@Service
public class ForgotPasswordService {

    @Autowired
    private NguoiDungRepository repo;

    @Autowired
    private PasswordEncoder encoder;

    @Autowired
    private MailService mailService;

    public String sendOtp(String email, HttpSession session) {

        NguoiDung user = repo.findByEmail(email)
                .orElse(null);

        if (user == null) {
            return "Email không tồn tại trong hệ thống";
        }

        String otp = String.valueOf(
                100000 + new Random().nextInt(900000)
        );

        session.setAttribute("resetEmail", email);
        session.setAttribute("resetOtp", otp);
        session.setAttribute("otpExpireTime", LocalDateTime.now().plusMinutes(5));
        session.setAttribute("otpVerified", false);

        try {
            mailService.sendOtp(email, otp);
        } catch (Exception e) {
            return "Không gửi được email. Vui lòng kiểm tra cấu hình Gmail App Password.";
        }

        return null;
    }

    public String verifyOtp(String otp, HttpSession session) {

        String sessionOtp = (String) session.getAttribute("resetOtp");
        LocalDateTime expireTime =
                (LocalDateTime) session.getAttribute("otpExpireTime");

        if (sessionOtp == null || expireTime == null) {
            return "Mã xác nhận không tồn tại. Vui lòng gửi lại mã";
        }

        if (LocalDateTime.now().isAfter(expireTime)) {
            return "Mã xác nhận đã hết hạn";
        }

        if (!sessionOtp.equals(otp)) {
            return "Mã xác nhận không đúng";
        }

        session.setAttribute("otpVerified", true);

        return null;
    }

    public String resetPassword(
            String matKhauMoi,
            String nhapLaiMatKhau,
            HttpSession session
    ) {

        Boolean verified =
                (Boolean) session.getAttribute("otpVerified");

        String email =
                (String) session.getAttribute("resetEmail");

        if (verified == null || !verified) {
            return "Bạn chưa xác nhận mã OTP";
        }

        if (email == null) {
            return "Không tìm thấy email cần đổi mật khẩu";
        }

        if (!matKhauMoi.equals(nhapLaiMatKhau)) {
            return "Mật khẩu nhập lại không khớp";
        }

        if (matKhauMoi.length() < 3) {
            return "Mật khẩu phải có ít nhất 3 ký tự";
        }

        NguoiDung user = repo.findByEmail(email)
                .orElse(null);

        if (user == null) {
            return "Tài khoản không tồn tại";
        }

        user.setMatKhau(
                encoder.encode(matKhauMoi)
        );

        repo.save(user);

        session.removeAttribute("resetEmail");
        session.removeAttribute("resetOtp");
        session.removeAttribute("otpExpireTime");
        session.removeAttribute("otpVerified");

        return null;
    }
}