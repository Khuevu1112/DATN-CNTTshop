package com.fpoly.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fpoly.service.ForgotPasswordService;

import jakarta.servlet.http.HttpSession;

@Controller
public class ForgotPasswordController {

    @Autowired
    private ForgotPasswordService service;

    @GetMapping("/DustNovel/forgot-password")
    public String forgotPasswordForm() {
        return "auth/forgot-password";
    }

    @PostMapping("/DustNovel/forgot-password")
    public String sendOtp(
            @RequestParam String email,
            HttpSession session,
            Model model
    ) {

        String error = service.sendOtp(email, session);

        if (error != null) {
            model.addAttribute("error", error);
            model.addAttribute("email", email);
            return "auth/forgot-password";
        }

        return "redirect:/DustNovel/verify-otp";
    }

    @GetMapping("/DustNovel/verify-otp")
    public String verifyOtpForm() {
        return "auth/verify-otp";
    }

    @PostMapping("/DustNovel/verify-otp")
    public String verifyOtp(
            @RequestParam String otp,
            HttpSession session,
            Model model
    ) {

        String error = service.verifyOtp(otp, session);

        if (error != null) {
            model.addAttribute("error", error);
            return "auth/verify-otp";
        }

        return "redirect:/DustNovel/reset-password";
    }

    @GetMapping("/DustNovel/reset-password")
    public String resetPasswordForm() {
        return "auth/reset-password";
    }

    @PostMapping("/DustNovel/reset-password")
    public String resetPassword(
            @RequestParam String matKhauMoi,
            @RequestParam String nhapLaiMatKhau,
            HttpSession session,
            Model model,
            RedirectAttributes redirectAttributes
    ) {

        String error =
                service.resetPassword(
                        matKhauMoi,
                        nhapLaiMatKhau,
                        session
                );

        if (error != null) {
            model.addAttribute("error", error);
            return "auth/reset-password";
        }

        redirectAttributes.addFlashAttribute(
                "success",
                "Đổi mật khẩu thành công, vui lòng đăng nhập"
        );

        return "redirect:/DustNovel/login";
    }
}