/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.fpoly.controller;

import com.fpoly.model.Payment;
import com.fpoly.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
/**
 *
 * @author Asus
 */
@Controller
public class PaymentController {

    @Autowired
    private PaymentRepository paymentRepo;
        @PostMapping("/payment/upload-proof")
public String uploadProof(

        @RequestParam Integer paymentId,

        @RequestParam("image")
        MultipartFile image,

        RedirectAttributes ra

) {
    try {

        Payment payment =
                paymentRepo.findById(paymentId)
                        .orElseThrow();

        String fileName =
                System.currentTimeMillis()
                + "_"
                + image.getOriginalFilename();

        Path uploadPath =
                Paths.get(
                        "src/main/resources/static/uploads/payment");

        Files.createDirectories(uploadPath);

        Files.copy(
                image.getInputStream(),
                uploadPath.resolve(fileName),
                StandardCopyOption.REPLACE_EXISTING);

        payment.setProofImage(
                "/uploads/payment/" + fileName);

        payment.setStatus(
                "waiting_verify");

        paymentRepo.save(payment);

        ra.addFlashAttribute(
                "success",
                "Đã gửi biên lai thành công");

        return "redirect:/orders/"
                + payment.getOrder().getId();

    } catch (Exception e) {

        ra.addFlashAttribute(
                "error",
                e.getMessage());

        return "redirect:/orders";
    }
}
}