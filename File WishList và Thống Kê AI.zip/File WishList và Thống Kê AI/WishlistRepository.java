package com.fpoly.repository;

import com.fpoly.model.NguoiDung;
import com.fpoly.model.Product;
import com.fpoly.model.Wishlist;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

public interface WishlistRepository
        extends JpaRepository<Wishlist, Integer> {

    List<Wishlist> findByNguoiDungOrderByCreatedAtDesc(
            NguoiDung nguoiDung);

    Optional<Wishlist> findByNguoiDungAndProduct(
            NguoiDung nguoiDung,
            Product product);

    boolean existsByNguoiDungAndProduct(
            NguoiDung nguoiDung,
            Product product);

    @Modifying
    @Transactional
    void deleteByNguoiDungAndProduct(
            NguoiDung nguoiDung,
            Product product);
}