package com.fpoly.service;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.math.RoundingMode;

import org.springframework.stereotype.Service;

import com.fpoly.model.Order;
import com.fpoly.model.ProductVariant;
import com.fpoly.repository.OrderItemRepository;
import com.fpoly.repository.OrderRepository;
import com.fpoly.repository.ProductRepository;
import com.fpoly.repository.ProductVariantRepository;

@Service
public class AIStatisticService {

    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;
    private final OrderItemRepository orderItemRepository;
    private final ProductVariantRepository productVariantRepository;

    public AIStatisticService(OrderRepository orderRepository,
                              ProductRepository productRepository,
                              OrderItemRepository orderItemRepository,
                              ProductVariantRepository productVariantRepository) {

        this.orderRepository = orderRepository;
        this.productRepository = productRepository;
        this.orderItemRepository = orderItemRepository;
        this.productVariantRepository = productVariantRepository;
    }

    public List<String> analyze() {

        List<String> insights = new ArrayList<>();

        NumberFormat vn = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));

        List<Order> orders = orderRepository.findAll();

        BigDecimal revenueToday = BigDecimal.ZERO;
        BigDecimal revenueAll = BigDecimal.ZERO;

        LocalDate today = LocalDate.now();

        int delivered = 0;
        int cancelled = 0;

        // =============================
        // Phân tích doanh thu
        // =============================
        for (Order order : orders) {

            if ("cancelled".equalsIgnoreCase(order.getTrangThai())) {
                cancelled++;
                continue;
            }

            revenueAll = revenueAll.add(order.getTongTien());

            if (today.equals(order.getCreatedAt().toLocalDate())) {
                revenueToday = revenueToday.add(order.getTongTien());
            }

            if ("delivered".equalsIgnoreCase(order.getTrangThai())) {
                delivered++;
            }
        }

        insights.add("💰 Tổng doanh thu đạt " + vn.format(revenueAll));

        insights.add("📅 Doanh thu hôm nay đạt " + vn.format(revenueToday));

        insights.add("📦 Đã hoàn thành " + delivered + " đơn hàng.");

        insights.add("❌ Có " + cancelled + " đơn hàng đã bị hủy.");

        insights.add("🖥️ Hệ thống hiện có " + productRepository.count() + " sản phẩm.");

        // =============================
        // Tỷ lệ hoàn thành đơn
        // =============================

        int totalOrders = delivered + cancelled;

        if (totalOrders > 0) {

            BigDecimal rate = BigDecimal.valueOf(delivered * 100.0 / totalOrders)
                    .setScale(1, RoundingMode.HALF_UP);

            insights.add("✅ Tỷ lệ giao hàng thành công đạt "
                    + rate + "%.");

        }
        
        // =============================
        // Top sản phẩm bán chạy
        // =============================
        List<Object[]> topProducts = orderItemRepository.getTopSellingProducts();

        if (!topProducts.isEmpty()) {

            Object[] top = topProducts.get(0);

            String productName = top[0].toString();

            Long quantity = ((Number) top[1]).longValue();

            insights.add("🔥 Sản phẩm bán chạy nhất là " + productName +
                    " (" + quantity + " sản phẩm).");
        }
        
        if (topProducts.size() >= 3) {

            insights.add("🏆 Top 3 sản phẩm bán chạy:");

            for (int i = 0; i < 3; i++) {

                Object[] row = topProducts.get(i);

                insights.add(
                        "   " + (i + 1) + ". "
                                + row[0]
                                + " (" + row[1] + " sản phẩm)");

            }

        }

        // =============================
        // Tồn kho thấp
        // =============================

        List<ProductVariant> lowStocks =
                productVariantRepository.findByStockLessThanEqual(5);

        if (lowStocks.isEmpty()) {

            insights.add("✅ Không có sản phẩm nào sắp hết hàng.");

        } else {

            insights.add("📦 Có " + lowStocks.size() + " sản phẩm sắp hết hàng.");

            for (ProductVariant pv : lowStocks) {

                if (pv.getStock() == 0) {

                    insights.add("❌ "
                            + pv.getProduct().getName()
                            + " đã hết hàng.");

                } else if (pv.getStock() <= 2) {

                    insights.add("🚨 "
                            + pv.getProduct().getName()
                            + " chỉ còn "
                            + pv.getStock()
                            + " sản phẩm.");

                } else {

                    insights.add("⚠ "
                            + pv.getProduct().getName()
                            + " còn "
                            + pv.getStock()
                            + " sản phẩm.");

                }

            }

        }

        // =============================
        // Đánh giá doanh thu
        // =============================
        if (revenueToday.compareTo(BigDecimal.valueOf(50_000_000)) >= 0) {

            insights.add("📈 Doanh thu hôm nay rất tốt.");

        } else if (revenueToday.compareTo(BigDecimal.valueOf(20_000_000)) >= 0) {

            insights.add("📊 Doanh thu hôm nay ở mức ổn định.");

        } else {

            insights.add("📉 Doanh thu hôm nay còn thấp, nên cân nhắc triển khai khuyến mãi.");

        }
        
        // =============================
        // Đánh giá đơn hàng
        // =============================
        if (cancelled > delivered / 2) {

            insights.add("⚠ Tỷ lệ hủy đơn khá cao, nên kiểm tra lại quy trình bán hàng.");

        }

        
        if (!orders.isEmpty()) {

            BigDecimal avgRevenue =
                    revenueAll.divide(
                            BigDecimal.valueOf(orders.size()),
                            0,
                            RoundingMode.HALF_UP);

            insights.add("💳 Giá trị trung bình mỗi đơn là "
                    + vn.format(avgRevenue));

        }
        
        // =============================
        // AI Recommendation
        // =============================

        // Khuyến nghị doanh thu
        if (revenueToday.compareTo(BigDecimal.valueOf(10_000_000)) < 0) {

            insights.add("💡 AI khuyến nghị triển khai Flash Sale hoặc mã giảm giá để kích cầu.");

        } else if (revenueToday.compareTo(BigDecimal.valueOf(30_000_000)) >= 0) {

            insights.add("💡 AI khuyến nghị tiếp tục duy trì các chương trình bán hàng hiện tại.");

        }

        // Khuyến nghị tồn kho
        if (!lowStocks.isEmpty()) {

            insights.add("💡 AI khuyến nghị nhập thêm hàng cho "
                    + lowStocks.size()
                    + " sản phẩm sắp hết kho.");

        }

        // Chất lượng đơn hàng
        if (cancelled == 0) {

            insights.add("🎉 AI đánh giá quy trình bán hàng hôm nay rất tốt, không có đơn bị hủy.");

        } else if (cancelled >= 5) {

            insights.add("⚠ AI phát hiện số lượng đơn hủy khá cao, nên kiểm tra lại vận chuyển hoặc chăm sóc khách hàng.");

        }


        // =============================
        // AI Forecast
        // =============================

        // Dự báo tồn kho
        if (lowStocks.size() >= 5) {

            insights.add("📦 AI dự đoán trong 3-5 ngày tới sẽ thiếu hàng ở nhiều sản phẩm nếu không nhập thêm.");

        } else if (lowStocks.size() > 0) {

            insights.add("📦 AI dự đoán sẽ cần bổ sung hàng cho một số sản phẩm trong vài ngày tới.");

        }


        // Dự báo xu hướng bán hàng
        if (delivered >= 20) {

            insights.add("📈 AI dự đoán xu hướng bán hàng sẽ tiếp tục tăng.");

        } else if (delivered >= 10) {

            insights.add("📊 AI dự đoán doanh số sẽ giữ ổn định.");

        } else {

            insights.add("📉 AI dự đoán doanh số có xu hướng giảm nếu không triển khai chương trình khuyến mãi.");

        }


        // Dự báo doanh thu ngày mai
        BigDecimal forecastRevenue;

        if (revenueToday.compareTo(BigDecimal.ZERO) == 0) {

            forecastRevenue = BigDecimal.valueOf(5_000_000);

        } else if (delivered >= 20) {

            // tăng khoảng 15%
            forecastRevenue = revenueToday.multiply(BigDecimal.valueOf(1.15));

        } else if (delivered >= 10) {

            // tăng khoảng 5%
            forecastRevenue = revenueToday.multiply(BigDecimal.valueOf(1.05));

        } else {

            // giảm khoảng 5%
            forecastRevenue = revenueToday.multiply(BigDecimal.valueOf(0.95));

        }

        forecastRevenue = forecastRevenue.setScale(0, RoundingMode.HALF_UP);

        insights.add("🔮 AI dự đoán doanh thu ngày mai khoảng "
                + vn.format(forecastRevenue) + ".");


        // Đánh giá sức khỏe kinh doanh
        if (delivered >= 20 && cancelled == 0 && lowStocks.size() <= 2) {

            insights.add("🟢 AI đánh giá tình hình kinh doanh đang ở mức RẤT TỐT.");

        } else if (delivered >= 10) {

            insights.add("🟡 AI đánh giá tình hình kinh doanh ở mức ỔN ĐỊNH.");

        } else {

            insights.add("🔴 AI đánh giá hoạt động kinh doanh cần được cải thiện.");

        }

        return insights;
    }
}