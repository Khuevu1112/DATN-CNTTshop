package com.fpoly.controller.admin;

import com.fpoly.model.Warranty;
import com.fpoly.service.WarrantyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin/warranty")
public class AdminWarrantyController {

    @Autowired
    private WarrantyService warrantyService;

    @GetMapping
    public String list(

            @RequestParam(required = false)
            String status,

            Model model){

        List<Warranty> list;

        if(status==null || status.isBlank()){

            list = warrantyService.getAllWarranty();

        }else{

            list = warrantyService.getWarrantyByStatus(status);

        }

        model.addAttribute("list",list);

        model.addAttribute("status",status);

        model.addAttribute("title","Quản lý bảo hành");

        model.addAttribute("content","admin/warranty-list");

        return "layout/Base";
    }

    @GetMapping("/{id}")
    public String detail(
            @PathVariable Integer id,
            Model model){

        model.addAttribute(
                "warranty",
                warrantyService.getById(id));

        model.addAttribute(
                "requests",
                warrantyService.getRequests(id));

        model.addAttribute(
                "title",
                "Chi tiết bảo hành");

        model.addAttribute(
                "content",
                "admin/warranty-detail");

        return "layout/Base";
    }

    @PostMapping("/{id}/status")

    public String update(

            @PathVariable Integer id,

            @RequestParam String status){

        warrantyService.updateStatus(id,status);

        return "redirect:/admin/warranty/"+id;
    }

    @GetMapping("/requests")
    public String requestList(Model model){

        model.addAttribute(
                "list",
                warrantyService.getAllRequest());

        model.addAttribute(
                "title",
                "Yêu cầu bảo hành");

        model.addAttribute(
                "content",
                "admin/warranty-request-list");

        return "layout/Base";
    }
    
    @GetMapping("/requests/{id}")
    public String requestDetail(
            @PathVariable Integer id,
            Model model){

        model.addAttribute(
                "request",
                warrantyService.getRequest(id));

        model.addAttribute(
                "title",
                "Chi tiết yêu cầu");

        model.addAttribute(
                "content",
                "admin/warranty-request-detail");

        return "layout/Base";
    }
    
    @PostMapping("/requests/{id}/status")
    public String updateRequest(

            @PathVariable Integer id,

            @RequestParam String status,

            @RequestParam(required = false)
            String note){

        warrantyService.updateRequestStatus(
                id,
                status,
                note);

        return "redirect:/admin/warranty/requests/" + id;
    }   
}