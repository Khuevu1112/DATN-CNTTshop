package com.fpoly.service;

import com.fpoly.model.NguoiDung;
import com.fpoly.model.Order;
import com.fpoly.model.OrderItem;
import com.fpoly.model.Warranty;
import com.fpoly.model.WarrantyHistory;
import com.fpoly.model.WarrantyRequest;
import com.fpoly.repository.NguoiDungRepository;
import com.fpoly.repository.WarrantyHistoryRepository;
import com.fpoly.repository.WarrantyRepository;
import com.fpoly.repository.WarrantyRequestRepository;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class WarrantyService {

    @Autowired
    private NguoiDungRepository nguoiDungRepo;
    
    @Autowired
    private MailService mailService;
    
    @Autowired
    private WarrantyHistoryRepository historyRepo;
    
    @Autowired
    private WarrantyRepository warrantyRepo;

    @Autowired
    private WarrantyRequestRepository requestRepo;
    /**
     * Tạo phiếu bảo hành cho toàn bộ sản phẩm trong đơn
     */
    public void createWarranty(Order order){

        for (OrderItem item : order.getChiTiet()) {

        if (warrantyRepo.existsByOrderItem(item)) {
            continue;
        }

        Warranty w = new Warranty();

        w.setOrderItem(item);

        w.setNguoiDung(order.getNguoiDung());

        w.setSerialNumber(null);

        w.setStartDate(LocalDate.now());

        w.setEndDate(LocalDate.now().plusMonths(12));

        w.setStatus("active");

        warrantyRepo.save(w);

    }

    }

    public List<Warranty> getAllWarranty(){

        return warrantyRepo.findAllByOrderByIdDesc();

    }

    public List<Warranty> getWarrantyByStatus(String status){

        return warrantyRepo.findByStatusOrderByIdDesc(status);

    }

public Warranty getById(Integer id){
    return warrantyRepo.findById(id).orElse(null);
}
    
    @Transactional
    public void updateStatus(Integer id,String status){

        Warranty w = getById(id);

        w.setStatus(status);

        warrantyRepo.save(w);

    }
    
    @Transactional
    public void createRequest(Integer warrantyId, String issue){

        Warranty warranty = getById(warrantyId);

        WarrantyRequest request = new WarrantyRequest();

        request.setWarranty(warranty);

        request.setIssueDescription(issue);

        request.setRequestStatus("pending");

        request.setCreatedAt(LocalDateTime.now());

        requestRepo.save(request);
    }
        
    public List<WarrantyRequest> getRequests(Integer warrantyId){

    Warranty warranty = getById(warrantyId);

    return requestRepo.findByWarrantyOrderByCreatedAtDesc(warranty);

}
    public List<Warranty> findByNguoiDungEmailOrderByIdDesc(String email){

    return warrantyRepo.findByNguoiDungEmailOrderByIdDesc(email);

}
    public List<WarrantyRequest> getAllRequest(){

    return requestRepo.findAllByOrderByCreatedAtDesc();

}
    public WarrantyRequest getRequest(Integer id){

    return requestRepo.findById(id)
            .orElseThrow(()->
                    new RuntimeException("Không tìm thấy yêu cầu"));

}
    @Transactional
    public void updateRequestStatus(

        Integer requestId,

        String status,

        String note){

    WarrantyRequest request =
            getRequest(requestId);

    request.setRequestStatus(status);

    requestRepo.save(request);
    try {

        mailService.sendWarrantyStatusEmail(request);

    } catch (Exception e) {

        e.printStackTrace();

    }    
    
    WarrantyHistory history = new WarrantyHistory();

    history.setRequest(request);
    history.setStatus(status);
    history.setNote(note);

    // thêm
    history.setCreatedAt(LocalDateTime.now());

    historyRepo.save(history);

}
    public List<Warranty> getWarrantyOfUser(String email){

    NguoiDung user = nguoiDungRepo.findByEmail(email)
            .orElseThrow(() -> new RuntimeException("Không tìm thấy user"));

    return warrantyRepo.findByNguoiDung(user);
    }
    
    @Transactional
    public void acceptRequest(Integer id) {

        WarrantyRequest request = getRequest(id);

        request.setRequestStatus("accepted"); // hoặc "processing"

        requestRepo.save(request);

        // log history
        WarrantyHistory history = new WarrantyHistory();
        history.setRequest(request);
        history.setStatus("accepted");
        history.setNote("Admin đã tiếp nhận yêu cầu");
        history.setCreatedAt(LocalDateTime.now());

        historyRepo.save(history);

        // gửi mail
        try {
            mailService.sendWarrantyStatusEmail(request);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}