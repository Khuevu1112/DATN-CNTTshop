package com.fpoly.service;

import com.fpoly.model.Payment;
import com.fpoly.model.WarrantyRequest;
import org.springframework.beans.factory.annotation.Autowired;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class MailService {

    @Autowired
    private JavaMailSender mailSender;

    public void sendOtp(String to, String otp) {

        SimpleMailMessage message = new SimpleMailMessage();

        message.setTo(to);
        message.setSubject("Mã xác nhận đặt lại mật khẩu CNTTShop");
        message.setText(
                "Xin chào,\n\n"
                + "Mã xác nhận đặt lại mật khẩu của bạn là: " + otp + "\n\n"
                + "Mã này có hiệu lực trong 5 phút.\n"
                + "Nếu bạn không yêu cầu đặt lại mật khẩu, vui lòng bỏ qua email này.\n\n"
                + "CNTTShop"
        );

        mailSender.send(message);
    }
    
    public void sendTransferWaitingEmail(Payment payment) throws MessagingException {

        MimeMessage message = mailSender.createMimeMessage();

        MimeMessageHelper helper =
                new MimeMessageHelper(message, true, "UTF-8");

        helper.setTo(payment.getOrder().getNguoiDung().getEmail());

        helper.setSubject("CNTTShop - Đã nhận biên lai chuyển khoản");

        String html =
                """
                <div style="font-family:Arial;background:#f5f5f5;padding:30px;">

                    <div style="max-width:650px;
                                margin:auto;
                                background:white;
                                border-radius:12px;
                                overflow:hidden;
                                box-shadow:0 0 15px rgba(0,0,0,.15);">

                        <div style="background:#dc3545;
                                    color:white;
                                    padding:25px;
                                    text-align:center;">

                            <h2 style="margin:0">
                                CNTTShop
                            </h2>

                            <p style="margin-top:8px">
                                Xác nhận chuyển khoản
                            </p>

                        </div>

                        <div style="padding:30px">

                            <h3>
                                Xin chào %s
                            </h3>

                            <p>

                                Chúng tôi đã nhận được
                                <b>biên lai chuyển khoản</b>
                                của bạn.

                            </p>

                            <table style="width:100%%;
                                          border-collapse:collapse">

                                <tr>

                                    <td><b>Mã đơn hàng</b></td>

                                    <td>%s</td>

                                </tr>

                                <tr>

                                    <td><b>Số tiền</b></td>

                                    <td style="color:#dc3545;font-weight:bold">

                                        %,.0f VNĐ

                                    </td>

                                </tr>

                                <tr>

                                    <td><b>Trạng thái</b></td>

                                    <td style="color:orange">

                                        Đang chờ xác minh

                                    </td>

                                </tr>

                            </table>

                            <br>

                            <p>

                                Nhân viên CNTTShop sẽ kiểm tra
                                và xác nhận thanh toán
                                trong thời gian sớm nhất.

                            </p>

                        </div>

                        <div style="background:#f2f2f2;
                                    padding:15px;
                                    text-align:center;
                                    color:#777;">

                            © 2025 CNTTShop

                        </div>

                    </div>

                </div>
                """.formatted(
                        payment.getOrder().getNguoiDung().getHoTen(),
                        payment.getOrder().getMaDonHang(),
                        payment.getAmount());

        helper.setText(html, true);

        mailSender.send(message);
    }
    
    public void sendPaymentSuccessEmail(Payment payment) throws MessagingException {

    MimeMessage message = mailSender.createMimeMessage();

    MimeMessageHelper helper =
            new MimeMessageHelper(message, true, "UTF-8");

    helper.setTo(payment.getOrder().getNguoiDung().getEmail());

    helper.setSubject("CNTTShop - Thanh toán thành công");

    String html =
            """
            <div style="font-family:Arial;background:#f5f5f5;padding:30px;">

                <div style="max-width:650px;
                            margin:auto;
                            background:white;
                            border-radius:12px;
                            overflow:hidden;
                            box-shadow:0 0 15px rgba(0,0,0,.15);">

                    <div style="background:#198754;
                                color:white;
                                padding:25px;
                                text-align:center;">

                        <h2 style="margin:0">

                            ✔ Thanh toán thành công

                        </h2>

                    </div>

                    <div style="padding:30px">

                        <h3>
                            Xin chào %s
                        </h3>

                        <p>

                            Chúng tôi đã xác nhận
                            thanh toán của bạn.

                        </p>

                        <table style="width:100%%">

                            <tr>

                                <td><b>Mã đơn hàng</b></td>

                                <td>%s</td>

                            </tr>

                            <tr>

                                <td><b>Số tiền</b></td>

                                <td style="color:#dc3545;
                                           font-weight:bold">

                                    %,.0f VNĐ

                                </td>

                            </tr>

                            <tr>

                                <td><b>Trạng thái</b></td>

                                <td style="color:green">

                                    Đã thanh toán

                                </td>

                            </tr>

                        </table>

                        <br>

                        <a href="http://localhost:8080/orders/%d"
                           style="background:#dc3545;
                                  color:white;
                                  padding:12px 25px;
                                  text-decoration:none;
                                  border-radius:6px;">

                            Xem đơn hàng

                        </a>

                    </div>

                    <div style="background:#f2f2f2;
                                padding:15px;
                                text-align:center">

                        Cảm ơn bạn đã mua sắm tại CNTTShop ❤️

                    </div>

                </div>

            </div>
            """.formatted(
                    payment.getOrder().getNguoiDung().getHoTen(),
                    payment.getOrder().getMaDonHang(),
                    payment.getAmount(),
                    payment.getOrder().getId());

    helper.setText(html, true);

    mailSender.send(message);
}
    public void sendWarrantyStatusEmail(WarrantyRequest request)
        throws MessagingException {

    String email =
            request.getWarranty()
                    .getNguoiDung()
                    .getEmail();

    String tenKhach =
            request.getWarranty()
                    .getNguoiDung()
                    .getHoTen();

    String sanPham =
            request.getWarranty()
                    .getOrderItem()
                    .getTenSanPham();

    String trangThai =
            request.getRequestStatus();

    String mauTrangThai = "#0d6efd";
    String textTrangThai = "Đã tiếp nhận";

    switch (trangThai) {

        case "processing":
            textTrangThai = "Đang xử lý";
            mauTrangThai = "#fd7e14";
            break;

        case "resolved":
            textTrangThai = "Đã hoàn thành";
            mauTrangThai = "#198754";
            break;

        case "rejected":
            textTrangThai = "Từ chối";
            mauTrangThai = "#dc3545";
            break;
    }

    MimeMessage message =
            mailSender.createMimeMessage();

    MimeMessageHelper helper =
            new MimeMessageHelper(message, true, "UTF-8");

    helper.setTo(email);

    helper.setSubject("📦 Cập nhật yêu cầu bảo hành - CNTTShop");

    String html =
            """
            <html>

            <body style="font-family:Arial;background:#f5f5f5;padding:30px;">

            <table width="650"
                   align="center"
                   style="background:white;border-radius:10px;
                          overflow:hidden;
                          box-shadow:0 0 15px rgba(0,0,0,.08);">

                <tr>

                    <td style="background:#dc3545;
                               color:white;
                               padding:20px;
                               text-align:center;">

                        <h2>CNTTShop</h2>

                        <p>Cập nhật yêu cầu bảo hành</p>

                    </td>

                </tr>

                <tr>

                    <td style="padding:30px;">

                        <h3>Xin chào %s,</h3>

                        <p>

                        Yêu cầu bảo hành của bạn đã được cập nhật.

                        </p>

                        <table
                            style="width:100%%;
                                   border-collapse:collapse;">

                            <tr>

                                <td style="padding:8px">
                                    <b>Sản phẩm</b>
                                </td>

                                <td>%s</td>

                            </tr>

                            <tr>

                                <td style="padding:8px">
                                    <b>Trạng thái</b>
                                </td>

                                <td>

                                    <span
                                    style="background:%s;
                                    color:white;
                                    padding:6px 14px;
                                    border-radius:20px;">

                                    %s

                                    </span>

                                </td>

                            </tr>

                            <tr>

                                <td style="padding:8px">
                                    <b>Mô tả lỗi</b>
                                </td>

                                <td>%s</td>

                            </tr>

                        </table>

                        <br>

                        <a href="http://localhost:8080/warranty"

                           style="display:inline-block;
                                  padding:12px 22px;
                                  background:#dc3545;
                                  color:white;
                                  text-decoration:none;
                                  border-radius:6px;">

                           Xem chi tiết bảo hành

                        </a>

                        <hr>

                        <p style="font-size:13px;color:#777">

                            Email được gửi tự động từ hệ thống
                            <b>CNTTShop</b>.

                        </p>

                    </td>

                </tr>

            </table>

            </body>

            </html>
            """.formatted(
                    tenKhach,
                    sanPham,
                    mauTrangThai,
                    textTrangThai,
                    request.getIssueDescription()
            );

    helper.setText(html, true);

    mailSender.send(message);

}
}