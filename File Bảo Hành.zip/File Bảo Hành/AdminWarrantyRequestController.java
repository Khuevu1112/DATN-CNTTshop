/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.fpoly.controller.admin;

import com.fpoly.service.WarrantyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 *
 * @author Asus
 */
@Controller
@RequestMapping("/admin/warranty-request")
public class AdminWarrantyRequestController {

    @Autowired
    private WarrantyService warrantyService;

    @GetMapping
    public String list(Model model){

        model.addAttribute(
                "list",
                warrantyService.getAllRequest());

        model.addAttribute(
                "title",
                "Yêu cầu bảo hành");

        model.addAttribute(
                "content",
                "admin/warranty-request-list");

        return "layout/Base";
    }

    @GetMapping("/{id}")
    public String detail(

            @PathVariable Integer id,

            Model model){

        model.addAttribute(
                "request",
                warrantyService.getRequest(id));

        model.addAttribute(
                "title",
                "Chi tiết yêu cầu");

        model.addAttribute(
                "content",
                "admin/warranty-request-detail");

        return "layout/Base";
    }

    @PostMapping("/{id}/status")
    public String update(

            @PathVariable Integer id,

            @RequestParam String status,

            @RequestParam String note){

        warrantyService.updateRequestStatus(
                id,
                status,
                note);

        return "redirect:/admin/warranty-request/"+id;

    }

}
