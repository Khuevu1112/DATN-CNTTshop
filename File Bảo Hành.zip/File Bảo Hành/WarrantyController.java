/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.fpoly.controller;

import com.fpoly.service.WarrantyService;
import java.security.Principal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 *
 * @author Asus
 */
@Controller
public class WarrantyController {
    @Autowired
    private WarrantyService warrantyService;
    
    @GetMapping("/warranty")

    public String myWarranty(

        Principal principal,

        Model model){

    model.addAttribute(
            "list",
            warrantyService.getWarrantyOfUser(
                    principal.getName()));

    model.addAttribute(
            "title",
            "Bảo hành của tôi");

    model.addAttribute(
            "content",
            "warranty/index");

    return "layout/Base";

}

@GetMapping("/warranty/{id}")

public String detail(

        @PathVariable Integer id,

        Model model){

    model.addAttribute(
            "warranty",
            warrantyService.getById(id));

    model.addAttribute(
            "requests",
            warrantyService.getRequests(id));

    model.addAttribute(
            "title",
            "Chi tiết bảo hành");

    model.addAttribute(
            "content",
            "warranty/detail");

    return "layout/Base";

}

@PostMapping("/warranty/request")

public String request(

        @RequestParam Integer warrantyId,

        @RequestParam String issue){

    warrantyService.createRequest(
            warrantyId,
            issue);

    return "redirect:/warranty/"+warrantyId;

}

@GetMapping("/requests/{id}/accept")
public String acceptRequest(@PathVariable Integer id) {

    warrantyService.acceptRequest(id);

    return "redirect:/admin/warranty/requests";
}
}
