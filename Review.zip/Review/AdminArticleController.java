package com.fpoly.controller.admin;

import com.fpoly.dto.ArticleDTO;
import com.fpoly.service.ArticleService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin/articles")
public class AdminArticleController {
    private final ArticleService articleService;

    public AdminArticleController(ArticleService articleService) {
        this.articleService = articleService;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("articles", articleService.findAllForAdmin());
        return "admin/article-list";
    }

    @GetMapping("/create")
    public String create(Model model) {
        model.addAttribute("article", articleService.getForm(null));
        return "admin/article-form";
    }

    @GetMapping("/{id}/edit")
    public String edit(@PathVariable Integer id, Model model) {
        model.addAttribute("article", articleService.getForm(id));
        return "admin/article-form";
    }

    @PostMapping("/save")
    public String save(@Valid @ModelAttribute("article") ArticleDTO form,
                       BindingResult result,
                       RedirectAttributes ra) {
        if (result.hasErrors()) return "admin/article-form";
        articleService.save(form);
        ra.addFlashAttribute("success", "Đã lưu bài viết thành công");
        return "redirect:/admin/articles";
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Integer id, RedirectAttributes ra) {
        articleService.delete(id);
        ra.addFlashAttribute("success", "Đã xóa bài viết");
        return "redirect:/admin/articles";
    }
}
