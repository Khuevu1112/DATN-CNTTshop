use shopDB



IF OBJECT_ID('Articles', 'U') IS NULL
BEGIN
    CREATE TABLE Articles (

        id INT IDENTITY(1,1) PRIMARY KEY,

        title NVARCHAR(250) NOT NULL,

        slug VARCHAR(260) NOT NULL UNIQUE,

        summary NVARCHAR(500),

        content NVARCHAR(MAX),

        thumbnail NVARCHAR(500),

        category NVARCHAR(50)
            NOT NULL DEFAULT N'Review',

        featured BIT
            NOT NULL DEFAULT 0,

        published BIT
            NOT NULL DEFAULT 1,

        viewCount BIGINT
            NOT NULL DEFAULT 0,

        createdAt DATETIME2
            NOT NULL DEFAULT SYSDATETIME(),

        updatedAt DATETIME2 NULL

    );
END
GO

INSERT INTO Articles
(
title,
slug,
summary,
content,
thumbnail,
category,
featured,
published
)

VALUES

(
N'5 ti�u ch� ch?n laptop h?c l?p tr�nh n?m 2026',

'5-tieu-chi-chon-laptop-hoc-lap-trinh-nam-2026',

N'Nh?ng ti�u ch� quan tr?ng gi�p sinh vi�n CNTT ch?n laptop ph� h?p.',

N'Laptop h?c l?p tr�nh c?n CPU m?nh, RAM t?i thi?u 16GB v� SSD.',

'https://images.unsplash.com/photo-1517336714731-489689fd1ca8',

N'H??ng d?n',

1,

1
),

(
N'Review PC Gaming 20 tri?u',

'review-pc-gaming-20-trieu',

N'C?u h�nh ch?i game Full HD.',

N'RTX 4060 + Ryzen 5 7500F l� l?a ch?n r?t t?t.',

'https://images.unsplash.com/photo-1593640408182-31c70c8268f5',

N'Review',

1,

1
),

(
N'Build PC c?n ?u ti�n g�?',

'build-pc-can-uu-tien-gi',

N'H??ng d?n build PC.',

N'?u ti�n VGA, CPU v� ngu?n ch?t l??ng.',

'https://images.unsplash.com/photo-1587202372634-32705e3bf49c',

N'C�ng ngh?',

0,

1
);