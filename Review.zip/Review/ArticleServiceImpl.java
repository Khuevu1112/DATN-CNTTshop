package com.fpoly.service;

import com.fpoly.dto.ArticleDTO;
import com.fpoly.model.Article;
import com.fpoly.repository.ArticleRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.Normalizer;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

@Service
@Transactional(readOnly = true)
public class ArticleServiceImpl implements ArticleService {
    private final ArticleRepository repository;

    public ArticleServiceImpl(ArticleRepository repository) {
        this.repository = repository;
    }

    @Override
    public Page<Article> findPublished(int page, int size, String category, String keyword) {
        var pageable = PageRequest.of(Math.max(page, 0), size,
                Sort.by(Sort.Direction.DESC, "createdAt"));
        if (keyword != null && !keyword.isBlank()) {
            return repository.searchPublished(keyword.trim(), pageable);
        }
        if (category != null && !category.isBlank()) {
            return repository.findByPublishedTrueAndCategoryIgnoreCase(category.trim(), pageable);
        }
        return repository.findByPublishedTrue(pageable);
    }

    @Override
    public List<Article> findFeatured() {
        return repository.findTop6ByPublishedTrueAndFeaturedTrueOrderByCreatedAtDesc();
    }

    @Override
    public List<Article> findPopular() {
        return repository.findTop5ByPublishedTrueOrderByViewCountDesc();
    }

    @Override
    public List<Article> findAllForAdmin() {
        return repository.findAll(Sort.by(Sort.Direction.DESC, "createdAt"));
    }

    @Override
    public List<Article> findRelated(Article article) {
        return repository.findTop4ByPublishedTrueAndCategoryIgnoreCaseAndIdNotOrderByCreatedAtDesc(
                article.getCategory(), article.getId());
    }

    @Override
    @Transactional
    public Article findPublishedBySlug(String slug) {
        Article article = repository.findBySlugAndPublishedTrue(slug)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy bài viết"));
        article.setViewCount(article.getViewCount() + 1);
        return repository.save(article);
    }

    @Override
    public Article findById(Integer id) {
        return repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy bài viết"));
    }

    @Override
    public ArticleDTO getForm(Integer id) {
        ArticleDTO dto = new ArticleDTO();
        if (id == null) return dto;

        Article article = findById(id);
        dto.setId(article.getId());
        dto.setTitle(article.getTitle());
        dto.setSummary(article.getSummary());
        dto.setContent(article.getContent());
        dto.setThumbnail(article.getThumbnail());
        dto.setCategory(article.getCategory());
        dto.setFeatured(article.isFeatured());
        dto.setPublished(article.isPublished());
        return dto;
    }

    @Override
    @Transactional
    public Article save(ArticleDTO form) {
        Article article = form.getId() == null ? new Article() : findById(form.getId());
        article.setTitle(form.getTitle().trim());
        article.setSlug(uniqueSlug(form.getTitle(), form.getId()));
        article.setSummary(trimToNull(form.getSummary()));
        article.setContent(form.getContent().trim());
        article.setThumbnail(trimToNull(form.getThumbnail()));
        article.setCategory(form.getCategory().trim());
        article.setFeatured(form.isFeatured());
        article.setPublished(form.isPublished());
        return repository.save(article);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        if (!repository.existsById(id)) {
            throw new IllegalArgumentException("Không tìm thấy bài viết");
        }
        repository.deleteById(id);
    }

    @Override
    public String uniqueSlug(String title, Integer currentId) {
        String base = toSlug(title);
        String slug = base;
        int index = 2;
        while (repository.existsBySlug(slug)) {
            Article found = repository.findBySlug(slug).orElse(null);
            if (found != null && currentId != null && found.getId().equals(currentId)) break;
            slug = base + "-" + index++;
        }
        return slug;
    }

    @Override
    public String toSlug(String value) {
        String normalized = Normalizer.normalize(value == null ? "" : value, Normalizer.Form.NFD);
        normalized = Pattern.compile("\\p{InCombiningDiacriticalMarks}+")
                .matcher(normalized).replaceAll("");
        normalized = normalized.replace('đ', 'd').replace('Đ', 'D').toLowerCase(Locale.ROOT);
        normalized = normalized.replaceAll("[^a-z0-9]+", "-").replaceAll("(^-|-$)", "");
        return normalized.isBlank() ? "bai-viet" : normalized;
    }

    private String trimToNull(String value) {
        if (value == null || value.isBlank()) return null;
        return value.trim();
    }
}
