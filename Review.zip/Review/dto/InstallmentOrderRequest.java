package com.fpoly.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class InstallmentOrderRequest {
    private Integer productId;
    private Integer variantId;
    private Integer quantity = 1;
    private Integer months;
    private BigDecimal downPayment = BigDecimal.ZERO;
    private List<Integer> optionValueIds = new ArrayList<>();
    private String customerName;
    private String customerPhone;
    private String customerEmail;
    private String customerAddress;
    private String identityNumber;
    private Boolean acceptedTerms;

    public Integer getProductId() { return productId; }
    public void setProductId(Integer productId) { this.productId = productId; }
    public Integer getVariantId() { return variantId; }
    public void setVariantId(Integer variantId) { this.variantId = variantId; }
    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }
    public Integer getMonths() { return months; }
    public void setMonths(Integer months) { this.months = months; }
    public BigDecimal getDownPayment() { return downPayment; }
    public void setDownPayment(BigDecimal downPayment) { this.downPayment = downPayment; }
    public List<Integer> getOptionValueIds() { return optionValueIds; }
    public void setOptionValueIds(List<Integer> optionValueIds) { this.optionValueIds = optionValueIds; }
    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }
    public String getCustomerPhone() { return customerPhone; }
    public void setCustomerPhone(String customerPhone) { this.customerPhone = customerPhone; }
    public String getCustomerEmail() { return customerEmail; }
    public void setCustomerEmail(String customerEmail) { this.customerEmail = customerEmail; }
    public String getCustomerAddress() { return customerAddress; }
    public void setCustomerAddress(String customerAddress) { this.customerAddress = customerAddress; }
    public String getIdentityNumber() { return identityNumber; }
    public void setIdentityNumber(String identityNumber) { this.identityNumber = identityNumber; }
    public Boolean getAcceptedTerms() { return acceptedTerms; }
    public void setAcceptedTerms(Boolean acceptedTerms) { this.acceptedTerms = acceptedTerms; }
}
