package com.fpoly.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ArticleDTO {
    private Integer id;

    @NotBlank(message = "Vui lòng nhập tiêu đề bài viết")
    @Size(max = 250, message = "Tiêu đề không được vượt quá 250 ký tự")
    private String title;

    @Size(max = 500, message = "Mô tả không được vượt quá 500 ký tự")
    private String summary;

    @NotBlank(message = "Vui lòng nhập nội dung bài viết")
    private String content;

    @Size(max = 500, message = "Đường dẫn ảnh không được vượt quá 500 ký tự")
    private String thumbnail;

    @NotBlank(message = "Vui lòng chọn danh mục")
    @Size(max = 50)
    private String category = "Review";

    private boolean featured;
    private boolean published = true;
}
