document.addEventListener('DOMContentLoaded', function () {
    const fileInput = document.querySelector('[data-thumbnail-file]');
    const preview = document.querySelector('[data-thumbnail-preview]');
    const emptyText = document.querySelector('[data-thumbnail-empty]');

    if (fileInput && preview) {
        fileInput.addEventListener('change', function () {
            const file = this.files && this.files[0];
            if (!file) return;

            if (!file.type.startsWith('image/')) {
                alert('Vui lòng chọn đúng file ảnh.');
                this.value = '';
                return;
            }

            if (file.size > 5 * 1024 * 1024) {
                alert('Ảnh đại diện không được vượt quá 5 MB.');
                this.value = '';
                return;
            }

            preview.src = URL.createObjectURL(file);
            preview.style.display = 'block';
            if (emptyText) emptyText.style.display = 'none';
        });
    }

    document.querySelectorAll('[data-confirm-delete]').forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (!confirm('Bạn chắc chắn muốn xóa bài viết này?')) {
                event.preventDefault();
            }
        });
    });
});
