document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-confirm-delete]').forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (!window.confirm('Bạn có chắc muốn xóa bài viết này?')) event.preventDefault();
        });
    });

    var thumbnailInput = document.querySelector('[data-thumbnail-input]');
    var thumbnailPreview = document.querySelector('[data-thumbnail-preview]');
    if (thumbnailInput && thumbnailPreview) {
        var updatePreview = function () {
            var url = thumbnailInput.value.trim();
            thumbnailPreview.src = url || 'https://placehold.co/700x450?text=Ảnh+bài+viết';
        };
        thumbnailInput.addEventListener('input', updatePreview);
        thumbnailPreview.addEventListener('error', function () {
            thumbnailPreview.src = 'https://placehold.co/700x450?text=Ảnh+không+hợp+lệ';
        });
        updatePreview();
    }

    var copyButton = document.querySelector('[data-copy-link]');
    if (copyButton) {
        copyButton.addEventListener('click', function () {
            navigator.clipboard.writeText(window.location.href).then(function () {
                var oldText = copyButton.innerHTML;
                copyButton.innerHTML = '<i class="bi bi-check2"></i> Đã sao chép';
                setTimeout(function () { copyButton.innerHTML = oldText; }, 1600);
            });
        });
    }
});
