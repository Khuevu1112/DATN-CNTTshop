// Tính toán và điều khiển cửa sổ đăng ký trả góp.
document.addEventListener("DOMContentLoaded", function () {
    const overlay = document.getElementById("installmentOverlay");
    const openButton = document.getElementById("openInstallment");
    const closeButton = document.getElementById("closeInstallment");
    const downPaymentInput = document.getElementById("downPayment");
    const quantityInput = document.getElementById("quantity");
    const basePriceElement = document.getElementById("basePrice");
    const titleElement = document.getElementById("productTitle");

    if (!overlay || !openButton || !closeButton || !downPaymentInput ||
        !quantityInput || !basePriceElement || !titleElement) return;

    const originalBasePrice = Number(basePriceElement.dataset.price || 0);
    const formatMoney = value => Math.round(value).toLocaleString("vi-VN") + " đ";

    function getCurrentTotal() {
        let extraPrice = 0;
        document.querySelectorAll(".option-btn.active").forEach(button => {
            extraPrice += Number(button.dataset.priceExtra || 0);
        });
        const quantity = Math.max(1, Number(quantityInput.value || 1));
        return (originalBasePrice + extraPrice) * quantity;
    }

    function refreshSummary() {
        const price = getCurrentTotal();
        let downPayment = Math.max(0, Number(downPaymentInput.value || 0));
        if (downPayment >= price) downPayment = Math.max(0, price - 1000);
        downPaymentInput.value = Math.round(downPayment);
        downPaymentInput.max = Math.max(0, price - 1);

        const selectedTerm = document.querySelector(".term-radio:checked");
        const months = Math.max(1, Number(selectedTerm?.value || 1));
        const rate = Math.max(0, Number(selectedTerm?.dataset.rate || 0));
        const loanAmount = price - downPayment;
        const totalInterest = loanAmount * rate / 100;
        const monthlyPayment = (loanAmount + totalInterest) / months;
        const totalPayment = downPayment + loanAmount + totalInterest;

        document.getElementById("interestRateText").value = rate.toLocaleString("vi-VN") + "% / toàn kỳ";
        document.getElementById("summaryPrice").innerText = formatMoney(price);
        document.getElementById("summaryDown").innerText = formatMoney(downPayment);
        document.getElementById("summaryLoan").innerText = formatMoney(loanAmount);
        document.getElementById("summaryInterest").innerText = formatMoney(totalInterest);
        document.getElementById("summaryMonthly").innerText = formatMoney(monthlyPayment);
        document.getElementById("summaryTotal").innerText = formatMoney(totalPayment);
        document.getElementById("installmentProductPrice").innerText = formatMoney(price);
        document.getElementById("installmentQtyText").innerText = quantityInput.value;
        document.getElementById("installmentQuantity").value = quantityInput.value;
        document.getElementById("installmentProductName").innerText = titleElement.innerText;

        const mainImage = document.getElementById("mainImage");
        if (mainImage) document.getElementById("installmentImage").src = mainImage.src;

        const selectedOptions = Array.from(document.querySelectorAll(".option-btn.active"));
        document.getElementById("installmentOptionsText").innerText = selectedOptions.length
            ? "Tùy chọn: " + selectedOptions.map(item => item.dataset.optionName).join(" - ")
            : "";
        document.getElementById("selectedOptionInputs").innerHTML = selectedOptions.map(item =>
            `<input type="hidden" name="optionValueIds" value="${item.dataset.optionValueId}">`
        ).join("");
    }

    function hideInstallment() {
        overlay.classList.remove("show");
        overlay.setAttribute("aria-hidden", "true");
        document.body.style.overflow = "";
    }

    function showInstallment() {
        refreshSummary();
        overlay.classList.add("show");
        overlay.setAttribute("aria-hidden", "false");
        document.body.style.overflow = "hidden";
    }

    // Nút có hàm inline dự phòng; listener này vẫn dùng khi JS hoạt động bình thường.
    openButton.addEventListener("click", function (event) {
        event.preventDefault();
        showInstallment();
    });
    document.addEventListener("installment:opened", refreshSummary);
    closeButton.addEventListener("click", hideInstallment);
    overlay.addEventListener("click", event => {
        if (event.target === overlay) hideInstallment();
    });
    document.addEventListener("keydown", event => {
        if (event.key === "Escape" && overlay.classList.contains("show")) hideInstallment();
    });
    downPaymentInput.addEventListener("input", refreshSummary);
    document.querySelectorAll(".term-radio").forEach(radio => radio.addEventListener("change", function () {
        document.querySelectorAll(".term-btn").forEach(item => item.classList.remove("active"));
        this.closest(".term-btn")?.classList.add("active");
        refreshSummary();
    }));
});
