package com.fpoly.service;

import com.fpoly.dto.ArticleDTO;
import com.fpoly.model.Article;
import org.springframework.data.domain.Page;

import java.util.List;
import org.springframework.web.multipart.MultipartFile;

public interface ArticleService {
    Page<Article> findPublished(int page, int size, String category, String keyword);
    List<Article> findFeatured();
    List<Article> findPopular();
    List<Article> findAllForAdmin();
    List<Article> findRelated(Article article);
    Article findPublishedBySlug(String slug);
    Article findById(Integer id);
    ArticleDTO getForm(Integer id);
    Article save(ArticleDTO form);
    String saveThumbnail(MultipartFile file);
    void delete(Integer id);
    String uniqueSlug(String title, Integer currentId);
    String toSlug(String value);
}
