package com.fpoly.controller.admin;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fpoly.model.InstallmentOrder;
import com.fpoly.model.ProductReview;
import com.fpoly.repository.CategoryRepository;
import com.fpoly.repository.InstallmentOrderRepository;
import com.fpoly.repository.ProductRepository;
import com.fpoly.repository.ProductReviewRepository;
import com.fpoly.service.ArticleService;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

@Controller
@Transactional
public class AdminController {

    private static final Set<String> VALID_INSTALLMENT_STATUSES = Set.of(
            "PENDING",
            "APPROVED",
            "REJECTED",
            "CANCELLED",
            "COMPLETED"
    );

    @PersistenceContext
    private EntityManager em;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private InstallmentOrderRepository installmentOrderRepository;

    @Autowired
    private ProductReviewRepository productReviewRepository;

    @Autowired
    private ArticleService articleService;

    // =====================================================
    // TRANG DASHBOARD ADMIN
    // =====================================================

    @GetMapping("/admin/dashboard")
    public String dashboard(Model model) {

        // Dữ liệu sản phẩm và danh mục
        model.addAttribute("products", productRepository.findAll());
        model.addAttribute("categories", categoryRepository.findAll());

        // Dữ liệu người dùng
        model.addAttribute("users", getUsers());

        // Dữ liệu hồ sơ trả góp
        loadInstallmentData(model);

        // Dữ liệu quản lý đánh giá sản phẩm
        loadReviewData(model);

        // Dữ liệu quản lý tin bài / review
        model.addAttribute("articles", articleService.findAllForAdmin());

        return "admin/dashboard";
    }

    /**
     * Đưa toàn bộ dữ liệu trả góp sang admin/dashboard.html.
     */
    private void loadInstallmentData(Model model) {

        model.addAttribute(
                "installmentOrders",
                installmentOrderRepository.findAllByOrderByCreatedAtDesc()
        );

        model.addAttribute(
                "recentInstallments",
                installmentOrderRepository.findTop10ByOrderByCreatedAtDesc()
        );

        model.addAttribute(
                "installmentTotal",
                installmentOrderRepository.count()
        );

        model.addAttribute(
                "installmentPending",
                installmentOrderRepository.countByStatus("PENDING")
        );

        model.addAttribute(
                "installmentApproved",
                installmentOrderRepository.countByStatus("APPROVED")
        );

        model.addAttribute(
                "installmentRejected",
                installmentOrderRepository.countByStatus("REJECTED")
        );

        model.addAttribute(
                "installmentCancelled",
                installmentOrderRepository.countByStatus("CANCELLED")
        );

        model.addAttribute(
                "installmentCompleted",
                installmentOrderRepository.countByStatus("COMPLETED")
        );
    }

    /**
     * Đưa dữ liệu đánh giá sản phẩm sang Dashboard Admin.
     */
    private void loadReviewData(Model model) {
        model.addAttribute("adminReviews", productReviewRepository.findAllByOrderByCreatedAtDesc());
        model.addAttribute("reviewTotal", productReviewRepository.count());
        model.addAttribute("reviewVisible", productReviewRepository.countByVisibleTrue());
        model.addAttribute("reviewHidden", productReviewRepository.countByVisibleFalse());
    }

    /**
     * Lấy danh sách người dùng từ bảng USER.
     */
    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> getUsers() {

        List<Object[]> rows = em.createNativeQuery(
                """
                SELECT
                    id,
                    full_name,
                    email,
                    role,
                    is_active
                FROM [USER]
                ORDER BY id DESC
                """
        ).getResultList();

        return rows.stream()
                .map(row -> {
                    Map<String, Object> user = new HashMap<>();

                    user.put("id", row[0]);
                    user.put("fullName", row[1]);
                    user.put("email", row[2]);
                    user.put("role", row[3]);
                    user.put("isActive", row[4]);

                    return user;
                })
                .toList();
    }

    // =====================================================
    // QUẢN LÝ HỒ SƠ TRẢ GÓP
    // =====================================================

    /**
     * Admin cập nhật trạng thái hồ sơ trả góp.
     *
     * Các trạng thái hợp lệ:
     * PENDING, APPROVED, REJECTED, CANCELLED, COMPLETED.
     */
    // =====================================================
    // QUẢN LÝ ĐÁNH GIÁ SẢN PHẨM
    // =====================================================

    @PostMapping("/admin/reviews/{id}/visibility")
    public String updateReviewVisibility(@PathVariable Integer id,
                                         @RequestParam boolean visible,
                                         RedirectAttributes redirectAttributes) {
        try {
            ProductReview review = productReviewRepository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy đánh giá."));
            review.setVisible(visible);
            productReviewRepository.save(review);
            redirectAttributes.addFlashAttribute(
                    "reviewAdminSuccess",
                    visible ? "Đã hiển thị đánh giá." : "Đã ẩn đánh giá."
            );
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("reviewAdminError", e.getMessage());
        }
        return "redirect:/admin/dashboard?section=reviews";
    }

    @PostMapping("/admin/reviews/{id}/delete")
    public String deleteReviewFromAdmin(@PathVariable Integer id,
                                        RedirectAttributes redirectAttributes) {
        try {
            ProductReview review = productReviewRepository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy đánh giá."));
            productReviewRepository.delete(review);
            redirectAttributes.addFlashAttribute("reviewAdminSuccess", "Đã xóa vĩnh viễn đánh giá.");
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("reviewAdminError", e.getMessage());
        }
        return "redirect:/admin/dashboard?section=reviews";
    }

    @PostMapping("/admin/installments/{id}/status")
    public String updateInstallmentStatus(
            @PathVariable Integer id,
            @RequestParam String status,
            RedirectAttributes redirectAttributes) {

        try {
            String newStatus = normalizeInstallmentStatus(status);

            InstallmentOrder order = installmentOrderRepository
                    .findById(id)
                    .orElseThrow(() -> new IllegalArgumentException(
                            "Không tìm thấy hồ sơ trả góp có mã TG" + id
                    ));

            validateStatusTransition(order.getStatus(), newStatus);

            order.setStatus(newStatus);
            installmentOrderRepository.save(order);

            redirectAttributes.addFlashAttribute(
                    "installmentSuccess",
                    "Đã cập nhật hồ sơ TG"
                            + order.getId()
                            + " thành: "
                            + getInstallmentStatusName(newStatus)
            );

        } catch (IllegalArgumentException e) {

            redirectAttributes.addFlashAttribute(
                    "installmentError",
                    e.getMessage()
            );

        } catch (Exception e) {

            redirectAttributes.addFlashAttribute(
                    "installmentError",
                    "Không thể cập nhật hồ sơ trả góp. Vui lòng thử lại."
            );
        }

        return "redirect:/admin/dashboard?section=installments";
    }

    /**
     * Chuẩn hóa và kiểm tra trạng thái gửi từ form.
     */
    private String normalizeInstallmentStatus(String status) {

        if (status == null || status.isBlank()) {
            throw new IllegalArgumentException(
                    "Bạn chưa chọn trạng thái hồ sơ."
            );
        }

        String normalizedStatus = status.trim().toUpperCase();

        if (!VALID_INSTALLMENT_STATUSES.contains(normalizedStatus)) {
            throw new IllegalArgumentException(
                    "Trạng thái hồ sơ không hợp lệ."
            );
        }

        return normalizedStatus;
    }

    /**
     * Kiểm tra quy trình chuyển trạng thái.
     */
    private void validateStatusTransition(
            String currentStatus,
            String newStatus) {

        if (currentStatus == null || currentStatus.isBlank()) {
            currentStatus = "PENDING";
        }

        currentStatus = currentStatus.trim().toUpperCase();

        if (currentStatus.equals(newStatus)) {
            throw new IllegalArgumentException(
                    "Hồ sơ đã ở trạng thái "
                            + getInstallmentStatusName(newStatus)
                            + "."
            );
        }

        // Hồ sơ đã hoàn tất không được thay đổi lại
        if ("COMPLETED".equals(currentStatus)) {
            throw new IllegalArgumentException(
                    "Hồ sơ đã hoàn tất nên không thể thay đổi trạng thái."
            );
        }

        // Hồ sơ đã bị từ chối không được duyệt lại trực tiếp
        if ("REJECTED".equals(currentStatus)
                && !"PENDING".equals(newStatus)) {

            throw new IllegalArgumentException(
                    "Hồ sơ bị từ chối chỉ có thể chuyển lại trạng thái chờ duyệt."
            );
        }

        // Hồ sơ đã hủy không được duyệt trực tiếp
        if ("CANCELLED".equals(currentStatus)
                && !"PENDING".equals(newStatus)) {

            throw new IllegalArgumentException(
                    "Hồ sơ đã hủy chỉ có thể chuyển lại trạng thái chờ duyệt."
            );
        }

        // Chỉ hồ sơ đã duyệt mới được hoàn tất
        if ("COMPLETED".equals(newStatus)
                && !"APPROVED".equals(currentStatus)) {

            throw new IllegalArgumentException(
                    "Chỉ hồ sơ đã duyệt mới có thể chuyển sang hoàn tất."
            );
        }
    }

    /**
     * Đổi tên trạng thái sang tiếng Việt.
     */
    private String getInstallmentStatusName(String status) {

        if (status == null) {
            return "Không xác định";
        }

        return switch (status.toUpperCase()) {
            case "PENDING" -> "Đang chờ duyệt";
            case "APPROVED" -> "Đã duyệt";
            case "REJECTED" -> "Đã từ chối";
            case "CANCELLED" -> "Đã hủy";
            case "COMPLETED" -> "Đã hoàn tất";
            default -> "Không xác định";
        };
    }

    // =====================================================
    // QUẢN LÝ NGƯỜI DÙNG
    // =====================================================

    @PostMapping("/admin/users/update-role/{id}")
    public String updateUserRole(
            @PathVariable Integer id,
            @RequestParam String role,
            RedirectAttributes redirectAttributes) {

        try {
            if (role == null || role.isBlank()) {
                throw new IllegalArgumentException(
                        "Vai trò người dùng không hợp lệ."
                );
            }

            String normalizedRole = role.trim().toLowerCase();

            if (!Set.of("admin", "staff", "customer")
                    .contains(normalizedRole)) {

                throw new IllegalArgumentException(
                        "Vai trò chỉ được phép là admin, staff hoặc customer."
                );
            }

            int updatedRows = em.createNativeQuery(
                    """
                    UPDATE [USER]
                    SET role = :role
                    WHERE id = :id
                    """
            )
            .setParameter("role", normalizedRole)
            .setParameter("id", id)
            .executeUpdate();

            if (updatedRows == 0) {
                throw new IllegalArgumentException(
                        "Không tìm thấy người dùng cần cập nhật."
                );
            }

            redirectAttributes.addFlashAttribute(
                    "successMessage",
                    "Cập nhật vai trò người dùng thành công."
            );

        } catch (Exception e) {

            redirectAttributes.addFlashAttribute(
                    "errorMessage",
                    e.getMessage()
            );
        }

        return "redirect:/admin/dashboard?section=users";
    }

    @GetMapping("/admin/users/toggle/{id}")
    public String toggleUserStatus(
            @PathVariable Integer id,
            RedirectAttributes redirectAttributes) {

        try {
            int updatedRows = em.createNativeQuery(
                    """
                    UPDATE [USER]
                    SET is_active =
                        CASE
                            WHEN is_active = 1 THEN 0
                            ELSE 1
                        END
                    WHERE id = :id
                    """
            )
            .setParameter("id", id)
            .executeUpdate();

            if (updatedRows == 0) {
                throw new IllegalArgumentException(
                        "Không tìm thấy người dùng."
                );
            }

            redirectAttributes.addFlashAttribute(
                    "successMessage",
                    "Đã cập nhật trạng thái người dùng."
            );

        } catch (Exception e) {

            redirectAttributes.addFlashAttribute(
                    "errorMessage",
                    e.getMessage()
            );
        }

        return "redirect:/admin/dashboard?section=users";
    }

    @GetMapping("/admin/users/delete/{id}")
    public String deleteUser(
            @PathVariable Integer id,
            RedirectAttributes redirectAttributes) {

        try {
            int deletedRows = em.createNativeQuery(
                    """
                    DELETE FROM [USER]
                    WHERE id = :id
                    """
            )
            .setParameter("id", id)
            .executeUpdate();

            if (deletedRows == 0) {
                throw new IllegalArgumentException(
                        "Không tìm thấy người dùng cần xóa."
                );
            }

            redirectAttributes.addFlashAttribute(
                    "successMessage",
                    "Xóa người dùng thành công."
            );

        } catch (Exception e) {

            redirectAttributes.addFlashAttribute(
                    "errorMessage",
                    "Không thể xóa người dùng. Người dùng có thể đang liên kết với đơn hàng."
            );
        }

        return "redirect:/admin/dashboard?section=users";
    }

    // =====================================================
    // API THỐNG KÊ TỔNG QUAN
    // =====================================================

    @GetMapping("/admin/api/stats")
    @ResponseBody
    public Map<String, Object> getStats() {

        Map<String, Object> result = new HashMap<>();

        result.put(
                "todayOrders",
                em.createNativeQuery(
                        """
                        SELECT COUNT(*)
                        FROM [ORDER]
                        WHERE CAST(created_at AS DATE)
                              = CAST(GETDATE() AS DATE)
                        """
                ).getSingleResult()
        );

        result.put(
                "todayRevenue",
                em.createNativeQuery(
                        """
                        SELECT ISNULL(SUM(total_amount), 0)
                        FROM [ORDER]
                        WHERE CAST(created_at AS DATE)
                              = CAST(GETDATE() AS DATE)
                          AND status != 'cancelled'
                        """
                ).getSingleResult()
        );

        result.put(
                "newCustomers",
                em.createNativeQuery(
                        """
                        SELECT COUNT(*)
                        FROM [USER]
                        WHERE CAST(created_at AS DATE)
                              = CAST(GETDATE() AS DATE)
                        """
                ).getSingleResult()
        );

        result.put(
                "totalCustomers",
                em.createNativeQuery(
                        """
                        SELECT COUNT(*)
                        FROM [USER]
                        WHERE role = 'customer'
                        """
                ).getSingleResult()
        );

        result.put(
                "recentOrders",
                em.createNativeQuery(
                        """
                        SELECT TOP 10
                            o.order_code,
                            u.full_name,
                            o.total_amount,
                            o.status,
                            CONVERT(VARCHAR, o.created_at, 103)
                        FROM [ORDER] o
                        JOIN [USER] u ON o.user_id = u.id
                        ORDER BY o.created_at DESC
                        """
                ).getResultList()
        );

        result.put(
                "last7Days",
                em.createNativeQuery(
                        """
                        SELECT
                            CONVERT(
                                VARCHAR,
                                CAST(created_at AS DATE),
                                103
                            ),
                            COUNT(*)
                        FROM [ORDER]
                        WHERE created_at >= DATEADD(
                            DAY,
                            -6,
                            CAST(GETDATE() AS DATE)
                        )
                        GROUP BY CAST(created_at AS DATE)
                        ORDER BY CAST(created_at AS DATE) ASC
                        """
                ).getResultList()
        );

        // Thống kê trả góp
        result.put(
                "installmentTotal",
                installmentOrderRepository.count()
        );

        result.put(
                "installmentPending",
                installmentOrderRepository.countByStatus("PENDING")
        );

        result.put(
                "installmentApproved",
                installmentOrderRepository.countByStatus("APPROVED")
        );

        result.put(
                "installmentRejected",
                installmentOrderRepository.countByStatus("REJECTED")
        );

        return result;
    }

    // =====================================================
    // API DOANH THU
    // =====================================================

    @GetMapping("/admin/api/revenue")
    @ResponseBody
    public Map<String, Object> getRevenue(
            @RequestParam
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate from,

            @RequestParam
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate to) {

        if (from == null || to == null) {
            throw new IllegalArgumentException(
                    "Ngày bắt đầu và ngày kết thúc không được để trống."
            );
        }

        if (from.isAfter(to)) {
            throw new IllegalArgumentException(
                    "Ngày bắt đầu không được lớn hơn ngày kết thúc."
            );
        }

        Map<String, Object> result = new HashMap<>();

        Query totalRevenueQuery = em.createNativeQuery(
                """
                SELECT ISNULL(SUM(total_amount), 0)
                FROM [ORDER]
                WHERE CAST(created_at AS DATE)
                      BETWEEN :from AND :to
                  AND status != 'cancelled'
                """
        );

        totalRevenueQuery.setParameter("from", from);
        totalRevenueQuery.setParameter("to", to);

        result.put(
                "totalRevenue",
                totalRevenueQuery.getSingleResult()
        );

        Query successfulOrdersQuery = em.createNativeQuery(
                """
                SELECT COUNT(*)
                FROM [ORDER]
                WHERE CAST(created_at AS DATE)
                      BETWEEN :from AND :to
                  AND status = 'delivered'
                """
        );

        successfulOrdersQuery.setParameter("from", from);
        successfulOrdersQuery.setParameter("to", to);

        result.put(
                "successOrders",
                successfulOrdersQuery.getSingleResult()
        );

        Query averageOrderQuery = em.createNativeQuery(
                """
                SELECT ISNULL(AVG(total_amount), 0)
                FROM [ORDER]
                WHERE CAST(created_at AS DATE)
                      BETWEEN :from AND :to
                  AND status != 'cancelled'
                """
        );

        averageOrderQuery.setParameter("from", from);
        averageOrderQuery.setParameter("to", to);

        result.put(
                "avgOrder",
                averageOrderQuery.getSingleResult()
        );

        Query refundedOrdersQuery = em.createNativeQuery(
                """
                SELECT COUNT(*)
                FROM [ORDER]
                WHERE CAST(created_at AS DATE)
                      BETWEEN :from AND :to
                  AND status = 'refunded'
                """
        );

        refundedOrdersQuery.setParameter("from", from);
        refundedOrdersQuery.setParameter("to", to);

        result.put(
                "refundedOrders",
                refundedOrdersQuery.getSingleResult()
        );

        Query weeklyRevenueQuery = em.createNativeQuery(
                """
                SELECT
                    'Tuần '
                    + CAST(
                        ROW_NUMBER() OVER (
                            ORDER BY MIN(CAST(created_at AS DATE))
                        ) AS VARCHAR
                    ),
                    ISNULL(SUM(total_amount), 0)
                FROM [ORDER]
                WHERE CAST(created_at AS DATE)
                      BETWEEN :from AND :to
                  AND status != 'cancelled'
                GROUP BY DATEPART(WEEK, created_at)
                ORDER BY MIN(CAST(created_at AS DATE)) ASC
                """
        );

        weeklyRevenueQuery.setParameter("from", from);
        weeklyRevenueQuery.setParameter("to", to);

        result.put(
                "weeklyRevenue",
                weeklyRevenueQuery.getResultList()
        );

        Query categoryRevenueQuery = em.createNativeQuery(
                """
                SELECT
                    c.name,
                    ISNULL(
                        SUM(oi.unit_price * oi.quantity),
                        0
                    )
                FROM ORDER_ITEM oi
                JOIN PRODUCT_VARIANT pv
                    ON oi.variant_id = pv.id
                JOIN PRODUCT p
                    ON pv.product_id = p.id
                JOIN CATEGORY c
                    ON p.category_id = c.id
                JOIN [ORDER] o
                    ON oi.order_id = o.id
                WHERE CAST(o.created_at AS DATE)
                      BETWEEN :from AND :to
                  AND o.status != 'cancelled'
                GROUP BY c.name
                ORDER BY 2 DESC
                """
        );

        categoryRevenueQuery.setParameter("from", from);
        categoryRevenueQuery.setParameter("to", to);

        result.put(
                "categoryRevenue",
                categoryRevenueQuery.getResultList()
        );

        return result;
    }

    // =====================================================
    // API SHIPPING ZONE
    // =====================================================

    @SuppressWarnings("rawtypes")
    @GetMapping("/admin/api/shipping")
    @ResponseBody
    public List getShippingZones() {

        return em.createNativeQuery(
                """
                SELECT
                    id,
                    name,
                    zone_key,
                    base_fee,
                    kg_fee,
                    free_from,
                    is_active
                FROM SHIPPING_ZONE
                ORDER BY id ASC
                """
        ).getResultList();
    }

    @PostMapping("/admin/api/shipping")
    @ResponseBody
    public Map<String, Object> addShippingZone(
            @RequestBody Map<String, Object> body) {

        Map<String, Object> result = new HashMap<>();

        try {
            Query query = em.createNativeQuery(
                    """
                    INSERT INTO SHIPPING_ZONE (
                        name,
                        zone_key,
                        base_fee,
                        kg_fee,
                        free_from
                    )
                    VALUES (
                        :name,
                        :key,
                        :base,
                        :kg,
                        :free
                    )
                    """
            );

            query.setParameter(
                    "name",
                    requireText(body, "name")
            );

            query.setParameter(
                    "key",
                    requireText(body, "key")
            );

            query.setParameter(
                    "base",
                    requireInteger(body, "base")
            );

            query.setParameter(
                    "kg",
                    requireInteger(body, "kg")
            );

            query.setParameter(
                    "free",
                    requireInteger(body, "free")
            );

            query.executeUpdate();

            result.put("success", true);
            result.put("message", "Thêm khu vực vận chuyển thành công.");

        } catch (Exception e) {

            result.put("success", false);
            result.put("error", e.getMessage());
        }

        return result;
    }

    @PutMapping("/admin/api/shipping/{id}")
    @ResponseBody
    public Map<String, Object> updateShippingZone(
            @PathVariable int id,
            @RequestBody Map<String, Object> body) {

        Map<String, Object> result = new HashMap<>();

        try {
            Query query = em.createNativeQuery(
                    """
                    UPDATE SHIPPING_ZONE
                    SET
                        name = :name,
                        base_fee = :base,
                        kg_fee = :kg,
                        free_from = :free
                    WHERE id = :id
                    """
            );

            query.setParameter(
                    "name",
                    requireText(body, "name")
            );

            query.setParameter(
                    "base",
                    requireInteger(body, "base")
            );

            query.setParameter(
                    "kg",
                    requireInteger(body, "kg")
            );

            query.setParameter(
                    "free",
                    requireInteger(body, "free")
            );

            query.setParameter("id", id);

            int updatedRows = query.executeUpdate();

            if (updatedRows == 0) {
                throw new IllegalArgumentException(
                        "Không tìm thấy khu vực vận chuyển."
                );
            }

            result.put("success", true);
            result.put("message", "Cập nhật khu vực thành công.");

        } catch (Exception e) {

            result.put("success", false);
            result.put("error", e.getMessage());
        }

        return result;
    }

    @DeleteMapping("/admin/api/shipping/{id}")
    @ResponseBody
    public Map<String, Object> deleteShippingZone(
            @PathVariable int id) {

        Map<String, Object> result = new HashMap<>();

        try {
            int deletedRows = em.createNativeQuery(
                    """
                    DELETE FROM SHIPPING_ZONE
                    WHERE id = :id
                    """
            )
            .setParameter("id", id)
            .executeUpdate();

            if (deletedRows == 0) {
                throw new IllegalArgumentException(
                        "Không tìm thấy khu vực vận chuyển."
                );
            }

            result.put("success", true);
            result.put("message", "Xóa khu vực vận chuyển thành công.");

        } catch (Exception e) {

            result.put("success", false);
            result.put("error", e.getMessage());
        }

        return result;
    }

    // =====================================================
    // API COUPON
    // =====================================================

    @SuppressWarnings("rawtypes")
    @GetMapping("/admin/api/coupon")
    @ResponseBody
    public List getCoupons() {

        return em.createNativeQuery(
                """
                SELECT
                    id,
                    code,
                    discount_type,
                    discount_value,
                    min_order_value,
                    max_uses,
                    used_count,
                    expires_at,
                    is_active,
                    condition_all_product,
                    condition_new_product,
                    condition_new_customer,
                    condition_no_sale
                FROM COUPON
                ORDER BY id DESC
                """
        ).getResultList();
    }

    @PostMapping("/admin/api/coupon")
    @ResponseBody
    public Map<String, Object> addCoupon(
            @RequestBody Map<String, Object> body) {

        Map<String, Object> result = new HashMap<>();

        try {
            Query query = em.createNativeQuery(
                    """
                    INSERT INTO COUPON (
                        code,
                        discount_type,
                        discount_value,
                        min_order_value,
                        max_uses,
                        expires_at,
                        is_active,
                        condition_all_product,
                        condition_new_product,
                        condition_new_customer,
                        condition_no_sale
                    )
                    VALUES (
                        :code,
                        :type,
                        :value,
                        :min,
                        :max,
                        :expiry,
                        1,
                        :conditionAll,
                        :conditionNew,
                        :conditionCustomer,
                        :conditionNoSale
                    )
                    """
            );

            query.setParameter(
                    "code",
                    requireText(body, "code").toUpperCase()
            );

            query.setParameter(
                    "type",
                    requireText(body, "type")
            );

            query.setParameter(
                    "value",
                    requireDouble(body, "value")
            );

            query.setParameter(
                    "min",
                    requireDouble(body, "min")
            );

            query.setParameter(
                    "max",
                    parseNullableInteger(body.get("maxUse"))
            );

            query.setParameter(
                    "expiry",
                    parseNullableDate(body.get("expiry"))
            );

            query.setParameter(
                    "conditionAll",
                    parseBoolean(body.getOrDefault("condAll", true))
            );

            query.setParameter(
                    "conditionNew",
                    parseBoolean(body.getOrDefault("condNew", false))
            );

            query.setParameter(
                    "conditionCustomer",
                    parseBoolean(body.getOrDefault("condCust", false))
            );

            query.setParameter(
                    "conditionNoSale",
                    parseBoolean(body.getOrDefault("condNoSale", false))
            );

            query.executeUpdate();

            result.put("success", true);
            result.put("message", "Thêm mã giảm giá thành công.");

        } catch (Exception e) {

            result.put("success", false);
            result.put("error", e.getMessage());
        }

        return result;
    }

    @DeleteMapping("/admin/api/coupon/{id}")
    @ResponseBody
    public Map<String, Object> deleteCoupon(
            @PathVariable int id) {

        Map<String, Object> result = new HashMap<>();

        try {
            int deletedRows = em.createNativeQuery(
                    """
                    DELETE FROM COUPON
                    WHERE id = :id
                    """
            )
            .setParameter("id", id)
            .executeUpdate();

            if (deletedRows == 0) {
                throw new IllegalArgumentException(
                        "Không tìm thấy mã giảm giá."
                );
            }

            result.put("success", true);
            result.put("message", "Xóa mã giảm giá thành công.");

        } catch (Exception e) {

            result.put("success", false);
            result.put("error", e.getMessage());
        }

        return result;
    }

    // =====================================================
    // API SẢN PHẨM THEO DANH MỤC
    // =====================================================

    @GetMapping("/admin/api/categories/{id}/products")
    @ResponseBody
    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> getProductsByCategory(
            @PathVariable Integer id) {

        List<Object[]> rows = em.createNativeQuery(
                """
                SELECT
                    id,
                    name,
                    slug,
                    is_active
                FROM PRODUCT
                WHERE category_id = :id
                ORDER BY id DESC
                """
        )
        .setParameter("id", id)
        .getResultList();

        return rows.stream()
                .map(row -> {
                    Map<String, Object> product = new HashMap<>();

                    product.put("id", row[0]);
                    product.put("name", row[1]);
                    product.put("slug", row[2]);
                    product.put("isActive", row[3]);

                    return product;
                })
                .toList();
    }

    // =====================================================
    // HÀM HỖ TRỢ XỬ LÝ DỮ LIỆU REQUEST
    // =====================================================

    private String requireText(
            Map<String, Object> body,
            String key) {

        Object value = body.get(key);

        if (value == null || value.toString().isBlank()) {
            throw new IllegalArgumentException(
                    "Trường " + key + " không được để trống."
            );
        }

        return value.toString().trim();
    }

    private Integer requireInteger(
            Map<String, Object> body,
            String key) {

        Object value = body.get(key);

        if (value == null || value.toString().isBlank()) {
            throw new IllegalArgumentException(
                    "Trường " + key + " không được để trống."
            );
        }

        try {
            return Integer.parseInt(value.toString());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(
                    "Trường " + key + " phải là số nguyên."
            );
        }
    }

    private Double requireDouble(
            Map<String, Object> body,
            String key) {

        Object value = body.get(key);

        if (value == null || value.toString().isBlank()) {
            throw new IllegalArgumentException(
                    "Trường " + key + " không được để trống."
            );
        }

        try {
            return Double.parseDouble(value.toString());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(
                    "Trường " + key + " phải là số."
            );
        }
    }

    private Integer parseNullableInteger(Object value) {

        if (value == null || value.toString().isBlank()) {
            return null;
        }

        return Integer.parseInt(value.toString());
    }

    private LocalDate parseNullableDate(Object value) {

        if (value == null || value.toString().isBlank()) {
            return null;
        }

        return LocalDate.parse(value.toString());
    }

    private boolean parseBoolean(Object value) {

        if (value == null) {
            return false;
        }

        if (value instanceof Boolean booleanValue) {
            return booleanValue;
        }

        String text = value.toString().trim();

        return "true".equalsIgnoreCase(text)
                || "1".equals(text)
                || "on".equalsIgnoreCase(text);
    }
}