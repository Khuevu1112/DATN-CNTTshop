package com.fpoly.controller.cilent;

import com.fpoly.model.Article;
import com.fpoly.service.ArticleService;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ArticleController {
    private final ArticleService articleService;

    public ArticleController(ArticleService articleService) {
        this.articleService = articleService;
    }

    @GetMapping({"/tin-tuc", "/reviews"})
    public String index(@RequestParam(defaultValue = "0") int page,
                        @RequestParam(required = false) String category,
                        @RequestParam(required = false) String keyword,
                        Model model) {
        Page<Article> articles = articleService.findPublished(page, 9, category, keyword);
        model.addAttribute("title", "Tin bài - Review sản phẩm");
        model.addAttribute("content", "article/index");
        model.addAttribute("articles", articles);
        model.addAttribute("featuredArticles", articleService.findFeatured());
        model.addAttribute("popularArticles", articleService.findPopular());
        model.addAttribute("selectedCategory", category);
        model.addAttribute("keyword", keyword);
        return "layout/Base";
    }

    @GetMapping("/tin-tuc/{slug}")
    public String detail(@PathVariable String slug, Model model) {
        Article article = articleService.findPublishedBySlug(slug);
        model.addAttribute("title", article.getTitle());
        model.addAttribute("content", "article/detail");
        model.addAttribute("article", article);
        model.addAttribute("relatedArticles", articleService.findRelated(article));
        model.addAttribute("popularArticles", articleService.findPopular());
        return "layout/Base";
    }
}
