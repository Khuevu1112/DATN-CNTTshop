package com.fpoly.repository;

import com.fpoly.model.Article;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ArticleRepository extends JpaRepository<Article, Integer> {
    Optional<Article> findBySlugAndPublishedTrue(String slug);
    Optional<Article> findBySlug(String slug);
    boolean existsBySlug(String slug);

    Page<Article> findByPublishedTrue(Pageable pageable);
    Page<Article> findByPublishedTrueAndCategoryIgnoreCase(String category, Pageable pageable);

    @Query("""
        SELECT a FROM Article a
        WHERE a.published = true
          AND (LOWER(a.title) LIKE LOWER(CONCAT('%', :keyword, '%'))
            OR LOWER(COALESCE(a.summary, '')) LIKE LOWER(CONCAT('%', :keyword, '%'))
            OR LOWER(COALESCE(a.content, '')) LIKE LOWER(CONCAT('%', :keyword, '%')))
        """)
    Page<Article> searchPublished(@Param("keyword") String keyword, Pageable pageable);

    List<Article> findTop5ByPublishedTrueOrderByViewCountDesc();
    List<Article> findTop6ByPublishedTrueAndFeaturedTrueOrderByCreatedAtDesc();
    List<Article> findTop4ByPublishedTrueAndCategoryIgnoreCaseAndIdNotOrderByCreatedAtDesc(
            String category, Integer id);
}
