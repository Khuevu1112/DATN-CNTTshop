package com.fpoly.config;

import java.nio.file.Paths;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {

        registry.addResourceHandler("/uploads/products/**")
                .addResourceLocations(
                        Paths.get("uploads/products")
                                .toAbsolutePath()
                                .toUri()
                                .toString()
                );

        registry.addResourceHandler("/uploads/avatar/**")
                .addResourceLocations(
                        Paths.get("uploads/avatar")
                                .toAbsolutePath()
                                .toUri()
                                .toString()
                );

        registry.addResourceHandler("/uploads/articles/**")
                .addResourceLocations(
                        Paths.get("uploads/articles")
                                .toAbsolutePath()
                                .toUri()
                                .toString()
                );
    }
}