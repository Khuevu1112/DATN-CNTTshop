document.addEventListener('DOMContentLoaded', function () {
    initThumbnailPreview();
    initContentImagesPreview();
    initContentVideosPreview();
    initRichEditor();
    initCounters();
    initDeleteConfirm();
    initCopyLink();
    initArticleToc();
});

function initThumbnailPreview() {
    const input = document.querySelector('[data-thumbnail-file]');
    const preview = document.querySelector('[data-thumbnail-preview]');
    const empty = document.querySelector('[data-thumbnail-empty]');
    if (!input || !preview) return;

    input.addEventListener('change', function () {
        const file = input.files && input.files[0];
        if (!file) return;
        if (!validateImage(file)) { input.value = ''; return; }
        preview.src = URL.createObjectURL(file);
        preview.style.display = 'block';
        if (empty) empty.style.display = 'none';
    });
}

function initContentImagesPreview() {
    const input = document.querySelector('[data-content-images]');
    const box = document.querySelector('[data-content-images-preview]');
    const wrap = document.querySelector('[data-images-preview-wrap]');
    if (!input || !box) return;

    input.addEventListener('change', function () {
        box.innerHTML = '';
        if (wrap) wrap.hidden = true;

        const files = Array.from(input.files || []);
        if (files.length > 20) {
            alert('Mỗi lần chỉ được chọn tối đa 20 ảnh nội dung.');
            input.value = '';
            return;
        }

        const valid = files.filter(validateImage);
        if (valid.length && wrap) wrap.hidden = false;

        valid.forEach(function (file, index) {
            const item = document.createElement('div');
            item.className = 'selected-image';

            const img = document.createElement('img');
            img.src = URL.createObjectURL(file);
            img.alt = file.name;

            const info = document.createElement('div');
            info.className = 'media-file-info';

            const name = document.createElement('span');
            name.textContent = (index + 1) + '. ' + file.name;

            const size = document.createElement('small');
            size.className = 'media-size';
            size.textContent = formatFileSize(file.size);

            info.appendChild(name);
            info.appendChild(size);
            item.appendChild(img);
            item.appendChild(info);
            box.appendChild(item);
        });
    });
}

function initContentVideosPreview() {
    const input = document.querySelector('[data-content-videos]');
    const box = document.querySelector('[data-content-videos-preview]');
    const wrap = document.querySelector('[data-videos-preview-wrap]');
    if (!input || !box) return;

    input.addEventListener('change', function () {
        box.innerHTML = '';
        if (wrap) wrap.hidden = true;

        const files = Array.from(input.files || []);
        if (files.length > 8) {
            alert('Mỗi lần chỉ được chọn tối đa 8 video nội dung.');
            input.value = '';
            return;
        }

        const valid = files.filter(validateVideo);
        if (valid.length && wrap) wrap.hidden = false;

        valid.forEach(function (file, index) {
            const item = document.createElement('div');
            item.className = 'selected-video';

            const video = document.createElement('video');
            video.src = URL.createObjectURL(file);
            video.controls = true;
            video.preload = 'metadata';
            video.muted = true;

            const info = document.createElement('div');
            info.className = 'media-file-info';

            const name = document.createElement('span');
            name.textContent = (index + 1) + '. ' + file.name;

            const size = document.createElement('small');
            size.className = 'media-size';
            size.textContent = formatFileSize(file.size);

            info.appendChild(name);
            info.appendChild(size);
            item.appendChild(video);
            item.appendChild(info);
            box.appendChild(item);
        });
    });
}

function validateImage(file) {
    if (!file.type || !file.type.startsWith('image/')) {
        alert('Vui lòng chỉ chọn file ảnh.');
        return false;
    }
    if (file.size > 8 * 1024 * 1024) {
        alert('Mỗi ảnh không được vượt quá 8 MB: ' + file.name);
        return false;
    }
    return true;
}

function validateVideo(file) {
    const allowed = ['video/mp4', 'video/webm', 'video/ogg'];
    if (!file.type || !allowed.includes(file.type)) {
        alert('Chỉ hỗ trợ video MP4, WEBM hoặc OGG: ' + file.name);
        return false;
    }
    if (file.size > 80 * 1024 * 1024) {
        alert('Mỗi video không được vượt quá 80 MB: ' + file.name);
        return false;
    }
    return true;
}

function formatFileSize(bytes) {
    if (!Number.isFinite(bytes) || bytes <= 0) return '0 KB';
    const mb = bytes / (1024 * 1024);
    if (mb >= 1) return mb.toFixed(mb >= 10 ? 0 : 1) + ' MB';
    return Math.max(1, Math.round(bytes / 1024)) + ' KB';
}

function initRichEditor() {
    const editor = document.querySelector('[data-rich-editor]');
    const field = document.querySelector('[data-content-field]');
    const form = document.querySelector('[data-article-form]');
    if (!editor || !field) return;

    if (!editor.innerHTML.trim() && field.value.trim()) {
        editor.innerHTML = escapeHtml(field.value).replace(/\n/g, '<br>');
    }

    document.querySelectorAll('[data-editor-command]').forEach(function (button) {
        button.addEventListener('click', function () {
            editor.focus();
            const command = button.dataset.editorCommand;
            const value = button.dataset.editorValue || null;
            document.execCommand(command, false, value);
            syncEditor();
        });
    });

    editor.addEventListener('input', syncEditor);
    if (form) form.addEventListener('submit', syncEditor);

    function syncEditor() {
        field.value = editor.innerHTML.trim();
    }
}

function initCounters() {
    bindCounter('[data-title-input]', '[data-title-count]');
    bindCounter('[data-summary-input]', '[data-summary-count]');
}

function bindCounter(inputSelector, countSelector) {
    const input = document.querySelector(inputSelector);
    const count = document.querySelector(countSelector);
    if (!input || !count) return;
    const update = function () { count.textContent = input.value.length; };
    input.addEventListener('input', update);
    update();
}

function initDeleteConfirm() {
    document.querySelectorAll('[data-confirm-delete]').forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (!confirm('Bạn chắc chắn muốn xóa bài viết này?')) event.preventDefault();
        });
    });
}

function initCopyLink() {
    document.querySelectorAll('[data-copy-link]').forEach(function (button) {
        button.addEventListener('click', async function () {
            try {
                await navigator.clipboard.writeText(window.location.href);
                const old = button.innerHTML;
                button.innerHTML = '<i class="bi bi-check2"></i> Đã sao chép';
                setTimeout(function () { button.innerHTML = old; }, 1500);
            } catch (e) {
                alert('Không thể sao chép liên kết.');
            }
        });
    });
}

function initArticleToc() {
    const content = document.querySelector('[data-article-content]');
    const toc = document.querySelector('[data-article-toc]');
    const wrap = document.querySelector('[data-article-toc-wrap]');
    if (!content || !toc) return;

    const headings = content.querySelectorAll('h2, h3');
    if (!headings.length) {
        if (wrap) wrap.style.display = 'none';
        return;
    }

    headings.forEach(function (heading, index) {
        if (!heading.id) heading.id = 'noi-dung-' + (index + 1);
        const link = document.createElement('a');
        link.href = '#' + heading.id;
        link.textContent = heading.textContent;
        if (heading.tagName === 'H3') link.classList.add('level-3');
        toc.appendChild(link);
    });
}

function escapeHtml(value) {
    return value.replace(/[&<>'"]/g, function (char) {
        return ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'})[char];
    });
}
