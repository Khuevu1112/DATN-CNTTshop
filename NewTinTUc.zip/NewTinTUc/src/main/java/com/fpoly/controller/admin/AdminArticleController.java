package com.fpoly.controller.admin;

import com.fpoly.dto.ArticleDTO;
import com.fpoly.service.ArticleService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/admin/articles")
public class AdminArticleController {
    private final ArticleService articleService;

    public AdminArticleController(ArticleService articleService) {
        this.articleService = articleService;
    }

    @GetMapping
    public String list() {
        return "redirect:/admin/dashboard?section=articles";
    }

    @GetMapping("/create")
    public String create(Model model) {
        model.addAttribute("article", articleService.getForm(null));
        return "admin/article-form";
    }

    @GetMapping("/{id}/edit")
    public String edit(@PathVariable Integer id, Model model, RedirectAttributes ra) {
        try {
            model.addAttribute("article", articleService.getForm(id));
            return "admin/article-form";
        } catch (IllegalArgumentException ex) {
            ra.addFlashAttribute("error", ex.getMessage());
            return "redirect:/admin/dashboard?section=articles";
        }
    }

    @PostMapping("/save")
    public String save(@Valid @ModelAttribute("article") ArticleDTO form,
                       BindingResult result,
                       @RequestParam(value = "thumbnailFile", required = false) MultipartFile thumbnailFile,
                       @RequestParam(value = "contentImages", required = false) List<MultipartFile> contentImages,
                       @RequestParam(value = "contentVideos", required = false) List<MultipartFile> contentVideos,
                       RedirectAttributes ra) {
        if (result.hasErrors()) {
            return "admin/article-form";
        }

        try {
            String uploadedThumbnail = articleService.saveThumbnail(thumbnailFile);
            if (uploadedThumbnail != null && !uploadedThumbnail.isBlank()) {
                form.setThumbnail(uploadedThumbnail);
            }

            List<String> contentImagePaths = articleService.saveContentImages(contentImages);
            List<String> contentVideoPaths = articleService.saveContentVideos(contentVideos);
            if (!contentImagePaths.isEmpty() || !contentVideoPaths.isEmpty()) {
                form.setContent(articleService.appendMediaToContent(
                        form.getContent(), contentImagePaths, contentVideoPaths));
            }

            boolean creating = form.getId() == null;
            articleService.save(form);
            ra.addFlashAttribute("success", creating
                    ? "Đã đăng bài viết thành công"
                    : "Đã cập nhật bài viết thành công");
            return "redirect:/admin/dashboard?section=articles";
        } catch (IllegalArgumentException | IllegalStateException ex) {
            result.reject("article.save.error", ex.getMessage());
            return "admin/article-form";
        }
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Integer id, RedirectAttributes ra) {
        try {
            articleService.delete(id);
            ra.addFlashAttribute("success", "Đã xóa bài viết");
        } catch (IllegalArgumentException | IllegalStateException ex) {
            ra.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/admin/dashboard?section=articles";
    }
}
