package com.fpoly.service;

import com.fpoly.dto.ArticleDTO;
import com.fpoly.model.Article;
import com.fpoly.repository.ArticleRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.text.Normalizer;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

@Service
@Transactional(readOnly = true)
public class ArticleServiceImpl implements ArticleService {
    private final ArticleRepository repository;

    public ArticleServiceImpl(ArticleRepository repository) {
        this.repository = repository;
    }

    @Override
    public Page<Article> findPublished(int page, int size, String category, String keyword) {
        var pageable = PageRequest.of(Math.max(page, 0), size,
                Sort.by(Sort.Direction.DESC, "createdAt"));
        if (keyword != null && !keyword.isBlank()) {
            return repository.searchPublished(keyword.trim(), pageable);
        }
        if (category != null && !category.isBlank()) {
            return repository.findByPublishedTrueAndCategoryIgnoreCase(category.trim(), pageable);
        }
        return repository.findByPublishedTrue(pageable);
    }

    @Override
    public List<Article> findFeatured() {
        return repository.findTop6ByPublishedTrueAndFeaturedTrueOrderByCreatedAtDesc();
    }

    @Override
    public List<Article> findPopular() {
        return repository.findTop5ByPublishedTrueOrderByViewCountDesc();
    }

    @Override
    public List<Article> findAllForAdmin() {
        return repository.findAll(Sort.by(Sort.Direction.DESC, "createdAt"));
    }

    @Override
    public List<Article> findRelated(Article article) {
        return repository.findTop4ByPublishedTrueAndCategoryIgnoreCaseAndIdNotOrderByCreatedAtDesc(
                article.getCategory(), article.getId());
    }

    @Override
    @Transactional
    public Article findPublishedBySlug(String slug) {
        Article article = repository.findBySlugAndPublishedTrue(slug)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy bài viết"));
        article.setViewCount(article.getViewCount() + 1);
        return repository.save(article);
    }

    @Override
    public Article findById(Integer id) {
        return repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Không tìm thấy bài viết"));
    }

    @Override
    public ArticleDTO getForm(Integer id) {
        ArticleDTO dto = new ArticleDTO();
        if (id == null) return dto;

        Article article = findById(id);
        dto.setId(article.getId());
        dto.setTitle(article.getTitle());
        dto.setSummary(article.getSummary());
        dto.setContent(article.getContent());
        dto.setThumbnail(article.getThumbnail());
        dto.setCategory(article.getCategory());
        dto.setFeatured(article.isFeatured());
        dto.setPublished(article.isPublished());
        return dto;
    }

    @Override
    @Transactional
    public Article save(ArticleDTO form) {
        Article article = form.getId() == null ? new Article() : findById(form.getId());
        article.setTitle(form.getTitle().trim());
        article.setSlug(uniqueSlug(form.getTitle(), form.getId()));
        article.setSummary(trimToNull(form.getSummary()));
        article.setContent(form.getContent().trim());
        article.setThumbnail(trimToNull(form.getThumbnail()));
        article.setCategory(form.getCategory().trim());
        article.setFeatured(form.isFeatured());
        article.setPublished(form.isPublished());
        return repository.save(article);
    }

    @Override
    public String saveThumbnail(MultipartFile file) {
        return saveMediaFile(file, "Ảnh đại diện", MediaType.IMAGE);
    }

    @Override
    public List<String> saveContentImages(List<MultipartFile> files) {
        return saveMultipleMedia(files, "Ảnh nội dung", MediaType.IMAGE, 20);
    }

    @Override
    public List<String> saveContentVideos(List<MultipartFile> files) {
        return saveMultipleMedia(files, "Video nội dung", MediaType.VIDEO, 8);
    }

    @Override
    public String appendMediaToContent(String content, List<String> imagePaths, List<String> videoPaths) {
        String safeContent = content == null ? "" : content.trim();
        List<String> images = imagePaths == null ? List.of() : imagePaths;
        List<String> videos = videoPaths == null ? List.of() : videoPaths;

        if (images.isEmpty() && videos.isEmpty()) {
            return safeContent;
        }

        StringBuilder mediaItems = new StringBuilder();
        int imageNumber = 1;
        for (String path : images) {
            mediaItems.append("<figure class=\"article-media-item article-media-image\">")
                    .append("<img src=\"").append(path)
                    .append("\" alt=\"Hình ảnh bài viết ").append(imageNumber)
                    .append("\" loading=\"lazy\">")
                    .append("<figcaption>Hình ").append(imageNumber++)
                    .append("</figcaption></figure>");
        }

        int videoNumber = 1;
        for (String path : videos) {
            mediaItems.append("<figure class=\"article-media-item article-media-video\">")
                    .append("<video controls preload=\"metadata\" playsinline>")
                    .append("<source src=\"").append(path).append("\">")
                    .append("Trình duyệt của bạn không hỗ trợ video HTML5.")
                    .append("</video>")
                    .append("<figcaption>Video ").append(videoNumber++)
                    .append("</figcaption></figure>");
        }

        String markerStart = "<!--ARTICLE_MEDIA_START-->";
        String markerEnd = "<!--ARTICLE_MEDIA_END-->";
        int startIndex = safeContent.indexOf(markerStart);
        int endIndex = safeContent.indexOf(markerEnd);

        if (startIndex >= 0 && endIndex > startIndex) {
            String existing = safeContent.substring(startIndex + markerStart.length(), endIndex);
            int stackEnd = existing.lastIndexOf("</div>");
            if (stackEnd >= 0) {
                String updated = existing.substring(0, stackEnd) + mediaItems + existing.substring(stackEnd);
                return safeContent.substring(0, startIndex + markerStart.length())
                        + updated
                        + safeContent.substring(endIndex);
            }
        }

        return safeContent
                + "\n" + markerStart
                + "<section class=\"article-media-section\" aria-label=\"Ảnh và video bài viết\">"
                + "<h2>Ảnh &amp; video trong bài</h2>"
                + "<div class=\"article-media-stack\">"
                + mediaItems
                + "</div></section>"
                + markerEnd;
    }

    private List<String> saveMultipleMedia(List<MultipartFile> files, String label, MediaType type, int maxFiles) {
        List<String> paths = new ArrayList<>();
        if (files == null) {
            return paths;
        }

        long nonEmptyCount = files.stream()
                .filter(file -> file != null && !file.isEmpty())
                .count();
        if (nonEmptyCount > maxFiles) {
            throw new IllegalArgumentException("Mỗi lần chỉ được tải tối đa " + maxFiles + " " + label.toLowerCase());
        }

        for (MultipartFile file : files) {
            if (file == null || file.isEmpty()) {
                continue;
            }
            paths.add(saveMediaFile(file, label, type));
        }
        return paths;
    }

    private String saveMediaFile(MultipartFile file, String label, MediaType type) {
        if (file == null || file.isEmpty()) {
            return null;
        }

        String contentType = file.getContentType();
        String originalName = file.getOriginalFilename();
        String extension = extensionOf(originalName);

        if (type == MediaType.IMAGE) {
            if (contentType == null || !contentType.startsWith("image/")) {
                throw new IllegalArgumentException(label + " không hợp lệ");
            }
            if (!extension.matches("\\.(jpg|jpeg|png|gif|webp)")) {
                throw new IllegalArgumentException("Chỉ hỗ trợ ảnh JPG, JPEG, PNG, GIF hoặc WEBP");
            }
            if (file.getSize() > 8L * 1024 * 1024) {
                throw new IllegalArgumentException(label + " không được vượt quá 8 MB");
            }
        } else {
            if (contentType == null || !contentType.startsWith("video/")) {
                throw new IllegalArgumentException(label + " không hợp lệ");
            }
            if (!extension.matches("\\.(mp4|webm|ogg|ogv)")) {
                throw new IllegalArgumentException("Chỉ hỗ trợ video MP4, WEBM hoặc OGG");
            }
            if (file.getSize() > 80L * 1024 * 1024) {
                throw new IllegalArgumentException(label + " không được vượt quá 80 MB");
            }
        }

        try {
            Path uploadDir = Paths.get("uploads/articles").toAbsolutePath().normalize();
            Files.createDirectories(uploadDir);
            String fileName = UUID.randomUUID() + extension;
            Path target = uploadDir.resolve(fileName).normalize();
            if (!target.startsWith(uploadDir)) {
                throw new IllegalArgumentException("Tên file không hợp lệ");
            }
            Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);
            return "/uploads/articles/" + fileName;
        } catch (IOException ex) {
            throw new IllegalStateException("Không thể lưu " + label.toLowerCase(), ex);
        }
    }

    private String extensionOf(String originalName) {
        if (originalName == null || originalName.lastIndexOf('.') < 0) {
            return "";
        }
        return originalName.substring(originalName.lastIndexOf('.')).toLowerCase(Locale.ROOT);
    }

    private enum MediaType {
        IMAGE, VIDEO
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        if (!repository.existsById(id)) {
            throw new IllegalArgumentException("Không tìm thấy bài viết");
        }
        repository.deleteById(id);
    }

    @Override
    public String uniqueSlug(String title, Integer currentId) {
        String base = toSlug(title);
        String slug = base;
        int index = 2;
        while (repository.existsBySlug(slug)) {
            Article found = repository.findBySlug(slug).orElse(null);
            if (found != null && currentId != null && found.getId().equals(currentId)) break;
            slug = base + "-" + index++;
        }
        return slug;
    }

    @Override
    public String toSlug(String value) {
        String normalized = Normalizer.normalize(value == null ? "" : value, Normalizer.Form.NFD);
        normalized = Pattern.compile("\\p{InCombiningDiacriticalMarks}+")
                .matcher(normalized).replaceAll("");
        normalized = normalized.replace('đ', 'd').replace('Đ', 'D').toLowerCase(Locale.ROOT);
        normalized = normalized.replaceAll("[^a-z0-9]+", "-").replaceAll("(^-|-$)", "");
        return normalized.isBlank() ? "bai-viet" : normalized;
    }

    private String trimToNull(String value) {
        if (value == null || value.isBlank()) return null;
        return value.trim();
    }
}
